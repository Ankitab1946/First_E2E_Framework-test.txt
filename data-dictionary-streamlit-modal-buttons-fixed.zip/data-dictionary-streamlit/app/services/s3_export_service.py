from datetime import datetime, timezone
from io import StringIO
import pandas as pd

from app.core.config import get_settings
from app.core.database import create_db_engine
from app.utils.sample_data import get_sample_records


class S3ExportService:
    TABLES = [
        "master_dictionary",
        "prj_attribute",
        "prj_attr_business_logic",
        "prj_attr_business_logic_scope",
    ]

    def __init__(self):
        self.settings = get_settings()

    def export_four_files(self, user_id: str) -> dict:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        simulated_files = [f"{self.settings.s3_prefix}/{timestamp}/{name}_{timestamp}.csv" for name in self.TABLES]

        if not self.settings.s3_bucket_name:
            return {
                "status": "SIMULATED_SUCCESS",
                "message": "S3_BUCKET_NAME is not configured. Export was simulated so the UI button remains usable in local/dev mode.",
                "bucket": "NOT_CONFIGURED",
                "files": simulated_files,
                "exported_by": user_id,
            }

        if not self.settings.enable_db:
            return {
                "status": "SIMULATED_SUCCESS",
                "message": "ENABLE_DB=false. S3 export was simulated.",
                "bucket": self.settings.s3_bucket_name,
                "files": simulated_files,
                "exported_by": user_id,
            }

        try:
            import boto3
        except ImportError as exc:
            raise RuntimeError("boto3 is required for S3 export. Install requirements.txt again.") from exc

        engine = create_db_engine()
        s3 = boto3.client("s3", region_name=self.settings.aws_region)
        uploaded_files: list[str] = []

        with engine.connect() as connection:
            for table_name in self.TABLES:
                df = pd.read_sql(f"SELECT * FROM dbo.{table_name}", connection)
                csv_buffer = StringIO()
                df.to_csv(csv_buffer, index=False)
                key = f"{self.settings.s3_prefix}/{timestamp}/{table_name}_{timestamp}.csv"
                s3.put_object(
                    Bucket=self.settings.s3_bucket_name,
                    Key=key,
                    Body=csv_buffer.getvalue().encode("utf-8"),
                    ContentType="text/csv",
                    Metadata={"exported-by": user_id, "environment": self.settings.selected_environment},
                )
                uploaded_files.append(key)

        return {
            "status": "SUCCESS",
            "bucket": self.settings.s3_bucket_name,
            "files": uploaded_files,
            "exported_by": user_id,
            "exported_at": datetime.now(timezone.utc).isoformat(),
        }
