# Performance Upload Optimisation

## Changes
- Excel parsing uses OpenPyXL read-only streaming (`iter_rows(values_only=True)`).
- Master Dictionary upload prefetches existing master and target records in batches.
- Target tables are updated from in-memory lookup caches instead of querying three target tables per row.
- Portfolio-scope synchronisation occurs once in the same transaction for the complete batch, not once per PRJ ID.
- Large uploads show only the first 500 rows in Streamlit. The full validated workbook remains the DB upload source.
- `09_performance_indexes_and_upload_tuning.sql` adds safe lookup/audit indexes.

## Operational guidance
Run the SQL migration once before the next large upload. Restart Streamlit after replacing code. Do not click Upload more than once while an upload is processing.
