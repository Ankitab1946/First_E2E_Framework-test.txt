from DataDictionaryAdminApp.config import get_settings
from DataDictionaryAdminApp.core.database import get_session_factory
from DataDictionaryAdminApp.repositories.audit_repository import AuditRepository


class AuditService:
    def __init__(self):
        self.settings = get_settings()
        self.repository = AuditRepository()

    def search_audit(self, *, prj_id: str = "", attribute_name: str = "", section: str = "",
                     portfolio: str = "ALL", include_full_history: bool = False) -> list[dict]:
        if not self.settings.enable_db:
            return []
        SessionLocal = get_session_factory()
        with SessionLocal() as db:
            return self.repository.search_audit(
                db,
                prj_id=prj_id,
                attribute_name=attribute_name,
                section=section,
                portfolio=portfolio,
                include_full_history=include_full_history,
            )


    def filter_audit(self, filters: dict) -> list[dict]:
        if not self.settings.enable_db:
            return []
        SessionLocal = get_session_factory()
        with SessionLocal() as db:
            return self.repository.filter_audit(
                db,
                filters=filters,
                include_full_history=bool(filters.get("include_full_history", False)),
            )

    def get_prompts(self) -> list[dict]:
        if not self.settings.enable_db:
            return [
                {
                    "prompt_name": "Sample Data Dictionary Prompt",
                    "prompt_category": "Future Placeholder",
                    "prompt_text": "This tab will read prompts from dbo.prompt_library when ENABLE_DB=true.",
                    "created_at": None,
                }
            ]
        SessionLocal = get_session_factory()
        with SessionLocal() as db:
            return self.repository.get_prompts(db)
