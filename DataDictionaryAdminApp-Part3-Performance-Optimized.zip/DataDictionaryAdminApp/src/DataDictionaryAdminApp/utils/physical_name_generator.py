import re

ABBREVIATIONS = {'buildings':'bldgs','building':'bldg','gross':'gross','net':'net'}
def slugify_attribute_name(value: str) -> str:
    words = re.sub(r'[^a-zA-Z0-9]+', ' ', value or '').strip().lower().split()
    words = [ABBREVIATIONS.get(word, word) for word in words]
    return '_'.join(words)[:255].strip('_') or 'attribute'

def unique_physical_name(base: str, exists) -> str:
    candidate = slugify_attribute_name(base)
    n = 2
    root = candidate
    while exists(candidate):
        suffix = f'_{n}'
        candidate = f'{root[:255-len(suffix)]}{suffix}'
        n += 1
    return candidate
