# Internal Cloud Helm Deployment

This chart deploys two workloads from the same image:

- `api`: FastAPI and Swagger on port 8503, internal-only ClusterIP service.
- `ui`: Streamlit on port 8501, exposed by the optional Ingress.

## Build and publish

```bash
docker build --target api -t registry.internal.example/data-dictionary-admin:1.0.0 .
docker build --target ui  -t registry.internal.example/data-dictionary-admin:1.0.0 .
docker push registry.internal.example/data-dictionary-admin:1.0.0
```

Both targets use the same codebase and image layers. Your registry can store the image once with the same tag.

## Create runtime secret

```bash
kubectl -n <namespace> create secret generic data-dictionary-admin-secrets \
  --from-literal=ENV_PROD_SQLSERVER_SERVER='<server-or-listener>' \
  --from-literal=S3_BUCKET_NAME='<bucket>' \
  --from-literal=S3_ENDPOINT_URL='https://<internal-s3-endpoint>' \
  --from-literal=AWS_ACCESS_KEY_ID='<access-key>' \
  --from-literal=AWS_SECRET_ACCESS_KEY='<secret-key>'
```

## Windows / Integrated Authentication

Linux containers can use `Trusted_Connection=yes`, but the workload must receive a valid Kerberos identity. This is an infrastructure prerequisite, not an application-only setting. Configure your platform's approved AD/Kerberos workload identity method, then set the relevant environment variables and mount `krb5.conf` and a keytab. If the internal cloud does not support Kerberos-integrated workloads, use the platform-approved SQL authentication or managed identity approach.

## Install

```bash
helm upgrade --install data-dictionary-admin . \
  --namespace <namespace> --create-namespace \
  --set image.repository=registry.internal.example/data-dictionary-admin \
  --set image.tag=1.0.0 \
  --set ingress.enabled=true \
  --set ingress.hosts[0].host=data-dictionary.internal.example
```

Swagger is internal at `http://<api-service>:8503/docs`. The UI is served through Ingress.
