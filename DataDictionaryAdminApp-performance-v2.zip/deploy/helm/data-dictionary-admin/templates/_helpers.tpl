{{- define "dd.fullname" -}}
{{- if .Values.fullnameOverride }}{{ .Values.fullnameOverride }}{{ else }}{{ printf "%s-%s" .Release.Name "data-dictionary-admin" | trunc 63 | trimSuffix "-" }}{{ end -}}
{{- end }}
{{- define "dd.labels" -}}
app.kubernetes.io/name: {{ include "dd.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
