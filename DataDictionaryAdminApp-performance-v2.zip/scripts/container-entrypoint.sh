#!/usr/bin/env sh
set -eu

# Optional Linux Kerberos bootstrap for SQL Server Windows / Integrated Authentication.
# Supply KERBEROS_PRINCIPAL and mount a keytab at KERBEROS_KEYTAB_PATH when enabled.
if [ "${KERBEROS_ENABLED:-false}" = "true" ]; then
  : "${KERBEROS_PRINCIPAL:?KERBEROS_PRINCIPAL is required when KERBEROS_ENABLED=true}"
  : "${KERBEROS_KEYTAB_PATH:?KERBEROS_KEYTAB_PATH is required when KERBEROS_ENABLED=true}"
  export KRB5_KTNAME="${KERBEROS_KEYTAB_PATH}"
  kinit -kt "${KERBEROS_KEYTAB_PATH}" "${KERBEROS_PRINCIPAL}"
fi

exec "$@"
