# Performance Tuning

## What changed

- The Data Dictionary grid uses the paged API endpoint by default. It loads 200 rows per page instead of rendering every row during each Streamlit rerun.
- Master Dictionary finalization uses a set-oriented batch process. It preloads reference data and executes batched SQL Server writes instead of querying scopes, business rules and prompts for each Excel row.
- Prompt bulk finalization uses the same set-oriented approach.
- SQL Server connection pooling keeps a small number of warm Windows-auth connections. `pool_pre_ping` is disabled by default because it adds an extra query to every checkout.

## Recommended first-run values

```env
BULK_UPLOAD_BATCH_SIZE=250
SQLALCHEMY_POOL_SIZE=5
SQLALCHEMY_MAX_OVERFLOW=5
SQLALCHEMY_POOL_PRE_PING=false
DATA_DICTIONARY_DEFAULT_PAGE_SIZE=200
API_READ_TIMEOUT_SECONDS=90
API_WRITE_TIMEOUT_SECONDS=600
```

For a SQL Server that is distant from the application pod, use `BULK_UPLOAD_BATCH_SIZE=100`. For a local/internal low-latency SQL Server, use `250`.

Run `src/DataDictionaryAdminApp/sql/004_add_performance_indexes.sql` once in each target database.

## Safety

The interactive create/edit, soft delete/reactivate, audit, S3 export and role controls remain unchanged. Fast batch processing is used only for Master Dictionary and Prompt workbook finalization. If a Master batch fails, the API automatically falls back to row-level processing for that batch to return row-specific diagnostics.
