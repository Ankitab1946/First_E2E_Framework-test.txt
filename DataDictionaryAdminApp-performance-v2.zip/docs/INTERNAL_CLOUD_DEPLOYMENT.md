# Internal Cloud Deployment Checklist

## Build and security

1. Build the `api` and `ui` Docker targets from the same repository revision.
2. Scan the image using the internal container security scanner.
3. Push only signed/scanned images to the internal registry.
4. Store S3 credentials and database endpoint information in the platform secret manager, not in `.env` committed to Git.

## Runtime configuration

- UI service: port 8501.
- API service: port 8503.
- API is ClusterIP-only by default; Swagger remains internally reachable at `/docs`.
- Streamlit reaches FastAPI over the internal Kubernetes service URL.
- Configure the final SQL Server endpoint through `ENV_PROD_SQLSERVER_SERVER` in the runtime secret.
- Configure internal object storage endpoint and credentials in the runtime secret.

## SQL Server Windows Authentication

`Trusted_Connection=yes` inside Linux pods needs Kerberos. Confirm all of the following with the platform and database teams:

1. The Kubernetes workload has an approved AD/Kerberos identity.
2. A valid keytab and `krb5.conf` are mounted as a Kubernetes secret when `windowsAuthKerberos.enabled=true`.
3. The configured SQL Server service principal name, DNS, network policy, and firewall rules allow the identity to connect.
4. `SQLSERVER_DRIVER` is `ODBC Driver 18 for SQL Server` in the container deployment.

## Pre-go-live verification

1. `GET /api/v1/health` returns `UP`.
2. `GET /api/v1/system/environment` reports the expected environment/server/database.
3. Run `003_validate_final_schema.sql` against the target database.
4. Validate Master Dictionary upload, Prompt upload, audit, S3 export, and reactivation with non-production sample data.
5. Confirm the internal load balancer/Ingress routes only the Streamlit UI externally.
