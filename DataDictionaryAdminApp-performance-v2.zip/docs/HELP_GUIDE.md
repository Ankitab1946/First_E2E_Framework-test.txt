# Data Dictionary Admin App Help Guide

## Operational flow

```mermaid
flowchart LR
  A[Open Streamlit UI] --> B[Select environment and role]
  B --> C[View latest active Data Dictionary]
  C --> D[Create or edit attribute]
  D --> E[Master, scope, business-rule and prompt records synchronized]
  E --> F[Audit history captured]
  C --> G[Upload/compare Master Dictionary]
  G --> H[Preview delta]
  H --> I[Finalize valid rows]
  I --> F
```

## Prompt bulk-upload flow

```mermaid
flowchart LR
  A[Upload multi-tab Prompt workbook] --> B[Select worksheet]
  B --> C[Load preview and detect mappings]
  C --> D[Validate PRJ ID and scope]
  D --> E{Valid and unambiguous?}
  E -- Yes --> F[Insert or update the selected scope record]
  E -- No --> G[Show rejected row and reason]
  F --> H[Audit history]
```

## Support checklist

| Symptom | First check |
|---|---|
| API is unavailable | `http://<api-host>:8503/api/v1/health` |
| DB not connected | Sidebar Environment, Server, Database, then `/api/v1/system/database-diagnostic` |
| Master/Prompt upload fails | Use the returned row-level rejection details and FastAPI logs |
| S3 export fails | Bucket endpoint, path style, access key and secret configuration |
| Windows-auth connection fails in cloud | Kerberos workload identity/keytab and SQL Server SPN/network rules |

## Core routes

- Data Dictionary: `/api/v1/data-dictionary`
- Master upload: `/api/v1/master-upload`
- Prompts: `/api/v1/prompts`
- Prompt upload: `/api/v1/prompt-upload`
- Audit: `/api/v1/audit`
- S3 export: `/api/v1/s3`
- Swagger: `/docs`
