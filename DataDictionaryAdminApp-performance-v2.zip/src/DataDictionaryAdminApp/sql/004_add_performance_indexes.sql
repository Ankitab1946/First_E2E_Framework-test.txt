/*
  Performance indexes for Data Dictionary Admin App.
  Safe to run repeatedly. Uses only the six approved application tables.
*/
SET NOCOUNT ON;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.prj_attribute_master_test') AND name=N'IX_ddam_master_active_prj')
    CREATE INDEX IX_ddam_master_active_prj
      ON dbo.prj_attribute_master_test(is_active, prj_id)
      INCLUDE (prj_attribute_name, where_in_financial_statement, version_update);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.prj_attribute_portfolio_scope_test') AND name=N'IX_ddam_scope_prj_active')
    CREATE INDEX IX_ddam_scope_prj_active
      ON dbo.prj_attribute_portfolio_scope_test(prj_id, is_active, port_ref_id)
      INCLUDE (scope_id, description);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.prj_attribute_business_rules_test') AND name=N'IX_ddam_rules_scope_active')
    CREATE INDEX IX_ddam_rules_scope_active
      ON dbo.prj_attribute_business_rules_test(scope_id, is_active)
      INCLUDE (editable, symbol, source_abbr_name);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.prj_scanning_prompt_reference_test') AND name=N'IX_ddam_prompt_prj_scope_active')
    CREATE INDEX IX_ddam_prompt_prj_scope_active
      ON dbo.prj_scanning_prompt_reference_test(prj_id, scope_id, is_active)
      INCLUDE (prompt_id, port_ref_id, display_order);

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'dbo.audit_table_test') AND name=N'IX_ddam_audit_table_key_date')
    CREATE INDEX IX_ddam_audit_table_key_date
      ON dbo.audit_table_test(table_name, record_key, performed_at DESC)
      INCLUDE (action, performed_by, source_operation);
GO
