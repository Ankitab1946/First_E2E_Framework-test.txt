from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends, Query
from sqlalchemy import text
from sqlalchemy.orm import Session
from DataDictionaryAdminApp.service.excel_service import ExcelService
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminApp.api.schemas_api import PromptUpsert
from DataDictionaryAdminApp.utils.security import current_user
from DataDictionaryAdminApp.config import get_settings

router=APIRouter(prefix='/prompt-upload',tags=['Prompt Upload'])

def _load(content: bytes, sheet_name: str):
    raw=ExcelService().read_prompt_workbook(content,sheet_name)
    return ExcelService.normalise_prompt_columns(raw)[0]

@router.post('/sheets')
async def sheets(file:UploadFile=File(...)):
    return {'sheets':ExcelService().sheets(await file.read())}

@router.post('/preview')
async def preview(file:UploadFile=File(...),sheet_name:str=Form(...)):
    try:
        content = await file.read()
        raw = ExcelService().read_prompt_workbook(content, sheet_name)
        df, mapping = ExcelService.normalise_prompt_columns(raw)
        return {
            'sheet': sheet_name,
            'row_count': len(df),
            'columns': list(df.columns),
            'column_mapping': mapping,
            'preview': df.head(200).where(df.notna(), None).to_dict(orient='records'),
        }
    except Exception as e:
        raise HTTPException(400, f'Unable to parse Prompt workbook: {e}')

@router.post('/delta')
async def delta(file:UploadFile=File(...),sheet_name:str=Form(...),db:Session=Depends(get_db)):
    try:
        df=_load(await file.read(),sheet_name)
        valid={r[0] for r in db.execute(text('SELECT prj_id FROM dbo.prj_attribute_master_test')).all()}
        invalid=sorted(set(df.prj_id)-valid)
        existing={r[0] for r in db.execute(text('SELECT DISTINCT prj_id FROM dbo.prj_scanning_prompt_reference_test WHERE is_active=1')).all()}
        return {'sheet':sheet_name,'rows':len(df),'new':int((~df.prj_id.isin(existing)).sum()),'update_candidates':int(df.prj_id.isin(existing).sum()),'invalid_prj_ids':invalid,'valid_rows':int(df.prj_id.isin(valid).sum()),'preview':df.head(200).where(df.notna(),None).to_dict(orient='records')}
    except Exception as e: raise HTTPException(400,f'Unable to calculate prompt delta: {e}')

@router.post('/finalize')
async def finalize(file: UploadFile = File(...), sheet_name: str = Form(...), target_scope: str | None = Form(None), user: str | None = Query(None), db: Session = Depends(get_db)):
    """Set-oriented prompt bulk upsert.

    It preloads master IDs, scopes and prompt placeholders once, then uses
    executemany for INSERT/UPDATE. This avoids the former per-row scope lookup
    and transaction cost while retaining scope-specific behaviour.
    """
    try:
        df = _load(await file.read(), sheet_name)
        actor = current_user(user)
        clean_rows = []
        for excel_row, row in df.iterrows():
            def value(name):
                item = row.get(name)
                return None if item is None or str(item).strip().lower() in {'', 'nan', 'none'} else str(item).strip()
            prj = value('prj_id')
            if prj:
                clean_rows.append((int(excel_row) + 1, prj, {name: value(name) for name in df.columns}))
        prj_ids = sorted({prj for _, prj, _ in clean_rows})
        if not prj_ids:
            return {'status': 'completed_with_rejections', 'inserted': 0, 'updated': 0, 'rejected_count': 1, 'rejected': [{'reason': 'No valid PRJ ID values were found in the selected worksheet.'}]}
        bind = {f'id_{idx}': value for idx, value in enumerate(prj_ids)}
        names = ','.join(f':{key}' for key in bind)
        valid = {str(row[0]) for row in db.execute(text(f'SELECT prj_id FROM dbo.prj_attribute_master_test WHERE is_active=1 AND prj_id IN ({names})'), bind).all()}
        scopes = db.execute(text(f'''SELECT s.scope_id,s.prj_id,s.port_ref_id,p.port_name,p.sector_name
            FROM dbo.prj_attribute_portfolio_scope_test s
            JOIN dbo.prj_portfolio_reference_test p ON p.port_ref_id=s.port_ref_id
            WHERE s.is_active=1 AND s.prj_id IN ({names})'''), bind).mappings().all()
        scopes_by_prj = {}
        for scope in scopes:
            scopes_by_prj.setdefault(str(scope['prj_id']), []).append(dict(scope))
        prompt_rows = db.execute(text(f'''SELECT prompt_id,prj_id,scope_id
            FROM dbo.prj_scanning_prompt_reference_test
            WHERE prj_id IN ({names})'''), bind).mappings().all()
        prompt_by_pair = {(str(row['prj_id']), int(row['scope_id'])): int(row['prompt_id']) for row in prompt_rows if row['scope_id'] is not None}

        inserted, updated, rejected = [], [], []
        def scope_label(scope):
            p = str(scope['port_name'] or '').strip().lower(); sector = str(scope['sector_name'] or '').strip().lower()
            if p == 'fi' and sector == 'banks': return 'FI Banks'
            if p == 'fi' and sector == 'insurance': return 'FI Insurance'
            if p in {'corporate', 'corporates'}: return 'Corporates'
            if 'zeus' in p and ('downstream' in p or not sector): return 'Zeus Downstream'
            return str(scope['port_name'] or scope['sector_name'] or '')

        for row_no, prj, data in clean_rows:
            if prj not in valid:
                rejected.append({'row': row_no, 'prj_id': prj, 'reason': 'PRJ ID does not exist in active prj_attribute_master_test'})
                continue
            candidates = scopes_by_prj.get(prj, [])
            requested = data.get('required_by_scope') or (target_scope or '').strip() or None
            if requested:
                candidates = [scope for scope in candidates if scope_label(scope).lower() == requested.lower()]
            if not candidates:
                rejected.append({'row': row_no, 'prj_id': prj, 'reason': f"No active scope matched '{requested or 'selected scope'}'"})
                continue
            if len(candidates) > 1:
                rejected.append({'row': row_no, 'prj_id': prj, 'reason': 'PRJ ID has multiple active scopes. Select Target Portfolio/Scope or add Required By Scope in the workbook.'})
                continue
            scope = candidates[0]
            display = data.get('display_order')
            try:
                display_order = int(float(display)) if display else None
            except ValueError:
                rejected.append({'row': row_no, 'prj_id': prj, 'reason': f'Invalid Display Order: {display}'})
                continue
            values = {
                'prj_id': prj, 'scope_id': int(scope['scope_id']), 'port_ref_id': int(scope['port_ref_id']),
                'required_by_scope': data.get('required_by_scope') or scope_label(scope),
                'attribute_name': data.get('attribute_name'), 'display_order': display_order,
                'section': data.get('section'), 'sub_section': data.get('sub_section'), 'data_type': data.get('data_type'),
                'calculated_or_reported': data.get('calculated_or_reported'), 'calculation_logic': data.get('calculation_logic'),
                'segment': data.get('segment'), 'attribute_description': data.get('attribute_description'), 'user': actor,
            }
            prompt_id = prompt_by_pair.get((prj, int(scope['scope_id'])))
            if prompt_id:
                updated.append({**values, 'prompt_id': prompt_id})
            else:
                inserted.append(values)

        if inserted:
            db.execute(text('''INSERT INTO dbo.prj_scanning_prompt_reference_test
                (scope_id,prj_id,port_ref_id,required_by_scope,attribute_name,display_order,section,sub_section,data_type,
                 calculated_or_reported,calculation_logic,segment,attribute_description,is_active,created_at,updated_at,created_by,updated_by)
                VALUES (:scope_id,:prj_id,:port_ref_id,:required_by_scope,:attribute_name,:display_order,:section,:sub_section,:data_type,
                        :calculated_or_reported,:calculation_logic,:segment,:attribute_description,1,SYSUTCDATETIME(),SYSUTCDATETIME(),:user,:user)'''), inserted)
        if updated:
            db.execute(text('''UPDATE dbo.prj_scanning_prompt_reference_test
                SET port_ref_id=:port_ref_id,required_by_scope=:required_by_scope,attribute_name=:attribute_name,
                    display_order=:display_order,section=:section,sub_section=:sub_section,data_type=:data_type,
                    calculated_or_reported=:calculated_or_reported,calculation_logic=:calculation_logic,segment=:segment,
                    attribute_description=:attribute_description,is_active=1,updated_at=SYSUTCDATETIME(),updated_by=:user
                WHERE prompt_id=:prompt_id'''), updated)
        audits = []
        for values in inserted:
            audits.append({'table_name':'prj_scanning_prompt_reference_test','record_key':f"{values['prj_id']}:{values['scope_id']}",'action':'INSERT','after_value':str(values),'user':actor})
        for values in updated:
            audits.append({'table_name':'prj_scanning_prompt_reference_test','record_key':f"{values['prj_id']}:{values['scope_id']}",'action':'UPDATE','after_value':str(values),'user':actor})
        if audits:
            db.execute(text('''INSERT INTO dbo.audit_table_test
                (table_name,record_key,action,after_value,source_operation,performed_by,performed_at)
                VALUES (:table_name,:record_key,:action,:after_value,'PROMPT_BULK_UPLOAD',:user,SYSUTCDATETIME())'''), audits)
        db.commit()
        return {'status':'completed' if not rejected else 'completed_with_rejections','inserted':len(inserted),'updated':len(updated),'rejected':rejected,'rejected_count':len(rejected),'mode':'set_oriented_batch'}
    except Exception as exc:
        db.rollback()
        raise HTTPException(400, f'Prompt bulk commit failed: {type(exc).__name__}: {getattr(exc,"orig",exc)}')

@router.post('/generate-sql')
async def generate_sql(file: UploadFile = File(...), sheet_name: str = Form(...), mode: str = Query('INSERT_ONLY')):
    """Generate reviewable SQL only. It never executes the generated script."""
    try:
        df = _load(await file.read(), sheet_name)
        statements = ["-- Generated by Data Dictionary Admin App", f"-- Mode: {mode}", "SET NOCOUNT ON;", ""]
        for _, row in df.iterrows():
            prj = str(row.get('prj_id', '')).replace("'", "''")
            name = str(row.get('attribute_name', '') or '').replace("'", "''")
            description = str(row.get('attribute_description', '') or '').replace("'", "''")
            if mode.upper() == 'MERGE':
                statements.append("MERGE dbo.prj_scanning_prompt_reference_test AS target USING (SELECT '" + prj + "' AS prj_id, '" + name + "' AS attribute_name) AS source ON target.prj_id=source.prj_id AND ISNULL(target.attribute_name,'')=source.attribute_name WHEN MATCHED THEN UPDATE SET attribute_description='" + description + "', updated_at=GETDATE() WHEN NOT MATCHED THEN INSERT (prj_id,attribute_name,attribute_description,is_active,created_at,updated_at,created_by,updated_by) VALUES ('" + prj + "','" + name + "','" + description + "',1,GETDATE(),GETDATE(),'sysuser','sysuser');")
            else:
                statements.append("INSERT INTO dbo.prj_scanning_prompt_reference_test (prj_id,attribute_name,attribute_description,is_active,created_at,updated_at,created_by,updated_by) SELECT '" + prj + "','" + name + "','" + description + "',1,GETDATE(),GETDATE(),'sysuser','sysuser' WHERE NOT EXISTS (SELECT 1 FROM dbo.prj_scanning_prompt_reference_test WHERE prj_id='" + prj + "' AND ISNULL(attribute_name,'')='" + name + "' AND is_active=1);")
        from fastapi.responses import PlainTextResponse
        return PlainTextResponse('\n'.join(statements), media_type='text/sql', headers={'Content-Disposition': 'attachment; filename=prompt_upload.sql'})
    except Exception as exc:
        raise HTTPException(400, f'Unable to generate SQL: {exc}')
