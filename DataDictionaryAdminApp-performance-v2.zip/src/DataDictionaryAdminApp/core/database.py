"""Environment-aware SQL Server session factory with production pool tuning."""
from __future__ import annotations

from functools import lru_cache
from urllib.parse import quote_plus

from fastapi import HTTPException, Request
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from DataDictionaryAdminApp.config import get_settings


class Base(DeclarativeBase):
    pass


@lru_cache(maxsize=8)
def _session_factory(environment: str):
    settings = get_settings()
    cfg = settings.database_config(environment)
    if not cfg["enabled"]:
        raise RuntimeError(f"Database access is disabled for environment {cfg['environment']}.")

    # SQL Server connections are expensive, especially with Windows / Kerberos authentication.
    # Keep a warm pool per selected environment instead of reconnecting for every API call.
    engine = create_engine(
        f"mssql+pyodbc:///?odbc_connect={quote_plus(settings.connection_string(cfg['environment']))}",
        future=True,
        # Pre-ping doubles round trips on Windows-auth SQL Server; disabled by default.
        pool_pre_ping=settings.sqlalchemy_pool_pre_ping,
        pool_use_lifo=True,
        pool_size=settings.sqlalchemy_pool_size,
        max_overflow=settings.sqlalchemy_max_overflow,
        pool_timeout=settings.sqlalchemy_pool_timeout_seconds,
        pool_recycle=settings.sqlalchemy_pool_recycle_seconds,
        fast_executemany=True,
        connect_args={"timeout": settings.sqlserver_connect_timeout_seconds},
    )
    return sessionmaker(autocommit=False, autoflush=False, expire_on_commit=False, bind=engine)


def get_db(request: Request):
    settings = get_settings()
    environment = request.headers.get("X-App-Environment") or request.query_params.get("environment")
    selected = settings.resolve_environment(environment)
    try:
        session_local = _session_factory(selected)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    db = session_local()
    try:
        yield db
    finally:
        db.close()
