# Part 3 Master Dictionary Mapping Corrections

The revised implementation is aligned to the changed Master Data Dictionary. The Master Dictionary is the only PRJ ID authority.

| Changed master header | Internal / database field | Downstream use |
|---|---|---|
| PRJ ID | `prj_id` | Read-only PRJ ID and validation for all child tables |
| Calculated or Reported? | `calculated_or_reported` | Prompt reference and UI |
| Calculation Logic | `calculation_logic` | Rule and prompt mapping |
| Calculation Logic Details | `calculation_logic_details` | Master dictionary and compatibility business-rule table |
| Calculated in CFV? (Y/N) | `calculation_in_prj` | Existing target/compatibility mapping |
| S&P As-Reported dataitem ID / logic | `sp_as_reported_dataitem_id` | Master/compatibility mapping |
| Sign Flipping (multiply by) | `sign_flipping` | Stored as text multiplier such as `-1`, not Boolean |

The Excel import uses the exact changed headers and accepts the legacy compatible headers where supplied. Missing columns never clear existing persisted values during update.
