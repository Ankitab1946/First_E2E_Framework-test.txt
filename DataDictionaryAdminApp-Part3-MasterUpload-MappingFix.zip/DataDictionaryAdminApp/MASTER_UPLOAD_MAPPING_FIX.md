# Master Upload Mapping Fix

- Excel physical attribute name is retained exactly when supplied.
- Blank physical attribute names preserve any existing DB name.
- Only a new blank value gets a short unique generated name.
- Business-logic target writes are filtered against the actual SQLAlchemy model columns, preventing invalid keyword argument failures on legacy model variants.
- SQL script 10 adds the S&P mapping columns to the legacy business logic table if required.
