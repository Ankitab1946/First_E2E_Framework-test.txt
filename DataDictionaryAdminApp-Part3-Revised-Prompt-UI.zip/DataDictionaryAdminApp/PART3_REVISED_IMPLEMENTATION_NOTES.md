# Part 3 Revised Solution

## What changed
- Master Dictionary remains the authoritative PRJ ID source.
- Prompt Excel bulk upload validates each PRJ ID against `master_dictionary`; missing IDs are skipped and returned to the UI with sheet, row and PRJ ID.
- Prompt rows support display order-related UI metadata, attribute name, sections, data type, calculated/reported, calculation logic, segment, subcomponent/total, description and examples.
- Configuration tables use the requested `*_test` names.
- Insert, update, soft delete and reactivation are audited in `audit_log`.
- SQL indexes support responsive prompt and scope lookup.

## Deployment
1. Run `01_schema.sql` / existing schema scripts.
2. Run `04_part3_revised_prompt_ui_schema.sql`.
3. Bootstrap static portfolios from the Configuration API/UI once.
4. Load Master Dictionary before loading the Prompt workbook.

`prj_data_source` is treated as existing static reference data and is not created or modified.
