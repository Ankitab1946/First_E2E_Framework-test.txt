# Data Dictionary Part 3 Implementation Notes

## What changed
- Added normalized configuration models: portfolio reference, attribute portfolio scope, UI display configuration, business rules and prompt reference.
- Added APIs for bootstrap portfolios, UI display CRUD, business rules, prompts and prompt workbook upload.
- Added Streamlit tabs for UI Display Configuration, Business Rules and Prompt Management.
- Added master physical-name generation. It generates only when blank and preserves an existing physical name.
- Added portfolio-scope synchronization based on Required by Banks/Insurance/Corporates/Downstream flags.
- Added SQL schema and seed statements for the Part 3 tables.

## Deployment sequence
1. Run `infra/DataDictionaryAdminApp/sql/01_schema.sql`.
2. Run `infra/DataDictionaryAdminApp/sql/02_seed.sql`.
3. Run `poetry install`.
4. Start UI: `poetry run streamlit run DataDictionaryAdminApp/src/DataDictionaryAdminApp/streamlit_app.py`.
5. Start API: `poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --app-dir DataDictionaryAdminApp/src --reload`.

## Important data rule
Scope comes from Required by flags. It does not come from the financial statement column.
