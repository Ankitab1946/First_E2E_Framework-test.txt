"""Streamlit front end for the Data Dictionary Admin App."""
from __future__ import annotations
import os
from pathlib import Path
import pandas as pd
import requests
import streamlit as st


def load_env():
    for candidate in [Path.cwd()/'.env', *[p/'.env' for p in Path(__file__).resolve().parents]]:
        if candidate.exists():
            for raw in candidate.read_text(encoding='utf-8').splitlines():
                line=raw.strip()
                if line and not line.startswith('#') and '=' in line:
                    k,v=line.split('=',1); os.environ.setdefault(k.strip(),v.strip().strip('"').strip("'"))
            break
load_env()

def base_url():
    value=os.getenv('API_BASE_URL','http://localhost:8503/api/v1').rstrip('/')
    return value if value.endswith('/api/v1') else value+'/api/v1'
API=base_url()
ENVIRONMENTS=[x.strip().upper() for x in os.getenv('APP_ENVIRONMENTS','LOCAL,DEV,UAT,PROD').split(',') if x.strip()]
DEFAULT_ENV=os.getenv('SELECTED_ENVIRONMENT','LOCAL').upper()
SECTIONS=['Income Statement','Balance Sheet','Cash Flow','Ratios','Derivatives','Miscellaneous','Other']
PORTFOLIOS=['FI Banks','Corporates','FI Insurance','Zeus Downstream','ALL']
st.set_page_config(page_title='Data Dictionary Admin App',layout='wide')
st.title(os.getenv('APP_NAME','Data Dictionary Streamlit Admin'))
for key,value in {'attribute_mode':None,'selected_attribute':None,'latest_excel':None,'prompt_preview':None,'master_preview':None}.items(): st.session_state.setdefault(key,value)

def api(method,path,quiet=False,**kwargs):
    headers=kwargs.pop('headers',{})
    headers['X-App-Environment']=st.session_state.get('env',DEFAULT_ENV)
    try:
        response=requests.request(method,API+path,headers=headers,timeout=120,**kwargs)
    except requests.RequestException as exc:
        if not quiet: st.error(f'API connection failed: {exc}')
        return None
    if not response.ok:
        if not quiet:
            try: detail=response.json().get('detail',response.text)
            except Exception: detail=response.text
            st.error(f'API error ({response.status_code}): {detail}')
        return None
    return response

def jget(path,fallback):
    response=api('GET',path,quiet=True)
    return response.json() if response else fallback

with st.sidebar:
    st.subheader('Connection')
    st.selectbox('Environment',ENVIRONMENTS,index=ENVIRONMENTS.index(DEFAULT_ENV) if DEFAULT_ENV in ENVIRONMENTS else 0,key='env')
    env=api('GET','/system/environment',quiet=True)
    details=env.json() if env else {}
    status=api('GET','/system/connection-status',quiet=True)
    state=status.json() if status else {'connected':False,'message':'FastAPI endpoint unavailable'}
    st.caption(f"Server: {details.get('server',os.getenv('SQLSERVER_SERVER','Not configured'))}")
    st.caption(f"Database: {details.get('database',os.getenv('SQLSERVER_DATABASE','Not configured'))}")
    if state.get('connected'): st.success(f"DB Connected: {state.get('server')} / {state.get('database')}")
    else: st.error(f"DB Not Connected: {state.get('message')}")
    user=st.text_input('Current User',value=os.getenv('USERNAME',os.getenv('DEFAULT_USER','sysuser')))
    if st.button('Refresh connection'): st.rerun()

sections=jget('/lookups/sections',SECTIONS)
sources=jget('/lookups/sources',[{'source_name':'S&P CAPIQ AS REPORTED DATA','source_code':'SNPAR'}])
source_names=[x.get('source_name','S&P CAPIQ AS REPORTED DATA') for x in sources]

def choice(label, values, value=None, key=None, disabled=False):
    values=list(values)
    index=values.index(value) if value in values else 0
    return st.selectbox(label,values,index=index,key=key,disabled=disabled)

def attribute_form(initial=None, readonly=False):
    initial=initial or {}; prefix='attribute_form'
    with st.form('attribute_editor',clear_on_submit=False):
        r1=st.columns(3)
        prj_id=r1[0].text_input('PRJ ID *',value=str(initial.get('prj_id','')),disabled=readonly or bool(initial.get('prj_id')))
        name=r1[1].text_input('PRJ Attribute Name *',value=str(initial.get('prj_attribute_name','')),disabled=readonly)
        physical=r1[2].text_input('PRJ Physical Attribute Name',value=str(initial.get('prj_physical_attribute_name') or ''),disabled=readonly)
        description=st.text_area('PRJ Attribute Description',value=str(initial.get('prj_attribute_description') or ''),disabled=readonly)
        r2=st.columns(3)
        section=choice('Where in financial statement',sections,initial.get('where_in_financial_statement'),disabled=readonly)
        version=r2[1].text_input('Version Update',value=str(initial.get('version_update') or ''),disabled=readonly)
        calc=r2[2].selectbox('Calculated or Reported?',['','Calculated','Reported'],index=['','Calculated','Reported'].index(initial.get('calculated_or_reported')) if initial.get('calculated_or_reported') in ['','Calculated','Reported'] else 0,disabled=readonly)
        r3=st.columns(3)
        editable=r3[0].selectbox('Editable?',['','Y','N'],index=['','Y','N'].index(initial.get('editable')) if initial.get('editable') in ['','Y','N'] else 0,disabled=readonly)
        symbol=r3[1].text_input('Percentage (%) / Ratio (X)',value=str(initial.get('percent_ratio') or initial.get('symbol') or ''),disabled=readonly)
        source=r3[2].selectbox('Source Name',source_names,index=source_names.index(initial.get('source_name')) if initial.get('source_name') in source_names else 0,disabled=readonly)
        req=st.multiselect('Required By',PORTFOLIOS[:-1],default=initial.get('required_portfolios',[]),disabled=readonly)
        r4=st.columns(2); logic=r4[0].text_area('Calculation Logic',value=str(initial.get('calculation_logic') or ''),disabled=readonly); logic_details=r4[1].text_area('Calculation Logic Details',value=str(initial.get('calculation_logic_details') or ''),disabled=readonly)
        r5=st.columns(2); mapping=r5[0].text_input('Mapping Type',value=str(initial.get('mapping_type') or ''),disabled=readonly); sp_std=r5[1].text_input('S&P Standardisation Dataitem ID',value=str(initial.get('sp_standardisation_dataitem_id') or ''),disabled=readonly)
        r6=st.columns(2); sp_as=r6[0].text_area('S&P As-Reported Dataitem ID / Logic',value=str(initial.get('sp_as_reported_dataitem_logic') or ''),disabled=readonly); business=r6[1].text_area('Business Logic',value=str(initial.get('business_logic') or ''),disabled=readonly)
        r7=st.columns(3); cfv=r7[0].selectbox('Calculated in CFV?',['','Y','N'],index=0,disabled=readonly); hist=r7[1].selectbox('Editable in Historicals?',['','Y','N'],index=0,disabled=readonly); sign=r7[2].text_input('Sign Flipping (multiply by)',value=str(initial.get('sign_flipping_value') or ''),disabled=readonly)
        submit=st.form_submit_button('Create Attribute' if not initial else 'Upload Changes',disabled=readonly)
    if submit:
        payload={'prj_id':prj_id or initial.get('prj_id',''),'prj_attribute_name':name,'prj_attribute_description':description,'prj_physical_attribute_name':physical,'where_in_financial_statement':section,'version_update':version,'calculated_or_reported':calc,'calculation_logic':logic,'calculation_logic_details':logic_details,'sign_flipping_value':sign,'mapping_type':mapping,'sp_standardisation_dataitem_id':sp_std,'sp_as_reported_dataitem_logic':sp_as,'calculated_in_cfv':cfv,'editable_in_historicals':hist,'required_portfolios':req,'source_name':source,'editable':editable,'symbol':symbol,'business_logic':business}
        if not payload['prj_id'] or not payload['prj_attribute_name']: st.error('PRJ ID and PRJ Attribute Name are mandatory.')
        else:
            path='/data-dictionary/attributes' if not initial else f"/data-dictionary/attributes/{payload['prj_id']}?user={user}"
            response=api('POST' if not initial else 'PUT',path,json=payload)
            if response: st.success('Attribute saved successfully.'); st.session_state['attribute_mode']=None; st.rerun()

tab1, tab2, tab3 = st.tabs(['Data Dictionary','Prompt Management','Audit History'])
with tab1:
    st.subheader('View Latest Data Dictionary')
    c1,c2,c3,c4=st.columns(4)
    selected_portfolios=c1.multiselect('Portfolio/Sector',PORTFOLIOS)
    prj_filter=c2.text_input('PRJ ID filter'); name_filter=c3.text_input('Attribute Name filter'); section_filter=c4.selectbox('Section filter',['']+sections)
    c5,c6=st.columns(2); desc_filter=c5.text_input('Attribute Description filter'); include_deleted=c6.checkbox('View soft deleted records'); overlap=c6.checkbox('Overlapped Attribute only')
    filters={'portfolios':[] if 'ALL' in selected_portfolios else selected_portfolios,'prj_id':prj_filter or None,'attribute_name':name_filter or None,'attribute_description':desc_filter or None,'section':section_filter or None,'include_deleted':include_deleted,'overlapped_only':overlap}
    result=api('POST','/data-dictionary/filter',json=filters)
    rows=result.json() if result else []
    st.dataframe(pd.DataFrame(rows),use_container_width=True,hide_index=True)
    x1,x2,x3,x4=st.columns(4)
    if x1.button('Add New Attribute',use_container_width=True): st.session_state['attribute_mode']='create'; st.session_state['selected_attribute']=None
    if x2.button('Generate Latest Excel',use_container_width=True):
        response=api('GET','/data-dictionary/download-latest')
        if response: st.session_state['latest_excel']=response.content
    if st.session_state.get('latest_excel'):
        x2.download_button('Download Latest Data',st.session_state['latest_excel'],'data_dictionary_latest.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',use_container_width=True)
    selected=x3.selectbox('Selected PRJ ID',['']+[r.get('prj_id','') for r in rows],key='selected_prj')
    if x4.button('Open / Edit Selected Attribute',disabled=not selected,use_container_width=True):
        response=api('GET',f'/data-dictionary/attributes/{selected}')
        if response: st.session_state['selected_attribute']=response.json(); st.session_state['attribute_mode']='readonly'
    y1,y2,y3=st.columns(3)
    if y1.button('Upload Data Dictionary',use_container_width=True): st.session_state['show_master_upload']=not st.session_state.get('show_master_upload',False)
    if y2.button('Soft Delete Attribute',disabled=not selected,use_container_width=True):
        if api('DELETE',f'/data-dictionary/attributes/{selected}?user={user}'): st.success('Attribute soft deleted.'); st.rerun()
    if y3.button('Export to S3',use_container_width=True):
        response=api('POST',f'/s3/export?user={user}')
        if response: st.success('S3 export completed.')
    if st.session_state.get('show_master_upload'):
        st.markdown('### Upload Master Dictionary')
        master=st.file_uploader('Master Dictionary Excel (.xlsx)',type=['xlsx'],key='master_dictionary_upload')
        if master:
            files={'file':(master.name,master.getvalue(),master.type or 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}
            p=api('POST','/master-upload/preview',files=files)
            if p: st.dataframe(pd.DataFrame(p.json()['preview']),use_container_width=True,hide_index=True)
            d1,d2=st.columns(2)
            if d1.button('Compare Master Dictionary'):
                delta=api('POST','/master-upload/delta',files=files)
                if delta: st.info(str(delta.json()))
            if d2.button('Finalize Master Upload'):
                completed=api('POST',f'/master-upload/finalize?user={user}',files=files)
                if completed: st.success(str(completed.json()))
    if st.session_state['attribute_mode']=='create':
        st.markdown('## Create New Attribute'); attribute_form()
        if st.button('Close Create Attribute'): st.session_state['attribute_mode']=None; st.rerun()
    elif st.session_state['attribute_mode']=='readonly':
        st.markdown('## Edit Attribute')
        st.info('Attribute is read-only. PRJ ID remains read-only after Edit is enabled.')
        attribute_form(st.session_state.get('selected_attribute'),readonly=True)
        if st.button('Edit Attribute',type='primary'): st.session_state['attribute_mode']='edit'; st.rerun()
        if st.button('Close Attribute Form'): st.session_state['attribute_mode']=None; st.rerun()
    elif st.session_state['attribute_mode']=='edit':
        st.markdown('## Edit Attribute'); attribute_form(st.session_state.get('selected_attribute'))
        if st.button('Close Attribute Form'): st.session_state['attribute_mode']=None; st.rerun()

# Prompt and audit management.
with tab2:
    bulk,manual=st.tabs(['Bulk Upload','Edit/Insert Prompts'])
    with bulk:
        uploaded=st.file_uploader('Upload Prompt Excel',type=['xlsx'],key='prompt_upload_file')
        if uploaded:
            files={'file':(uploaded.name,uploaded.getvalue(),uploaded.type or 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}
            sheet_api=api('POST','/prompt-upload/sheets',files=files)
            sheets=sheet_api.json().get('sheets',[]) if sheet_api else []
            sheet=st.selectbox('Workbook sheet',sheets) if sheets else None
            if sheet and st.button('Load Selected Data'):
                preview=api('POST','/prompt-upload/preview',files=files,data={'sheet_name':sheet})
                if preview: st.session_state['prompt_preview']=preview.json()
            if st.session_state.get('prompt_preview'):
                st.dataframe(pd.DataFrame(st.session_state['prompt_preview']['preview']),use_container_width=True,hide_index=True)
            a,b,c=st.columns(3)
            if sheet and a.button('Validate and Compare Delta'):
                r=api('POST','/prompt-upload/delta',files=files,data={'sheet_name':sheet})
                if r: st.session_state['prompt_delta']=r.json(); st.info(str(r.json()))
            if sheet and b.button('Generate SQL Script'):
                r=api('POST','/prompt-upload/generate-sql?mode=MERGE',files=files,data={'sheet_name':sheet})
                if r: st.download_button('Download MERGE SQL',r.content,'prompt_merge.sql',mime='text/sql')
            if sheet and c.button('Commit Valid Rows'):
                r=api('POST',f'/prompt-upload/finalize?user={user}',files=files,data={'sheet_name':sheet})
                if r: st.success(str(r.json()))
    with manual:
        st.info('Prompt CRUD is available through Swagger route /api/v1/prompts. The bulk flow above derives scopes automatically.')
with tab3:
    audit=api('GET','/audit')
    if audit: st.dataframe(pd.DataFrame(audit.json()),use_container_width=True,hide_index=True)
