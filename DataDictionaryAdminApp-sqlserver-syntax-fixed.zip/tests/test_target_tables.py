from DataDictionaryAdminApp.core.target_tables import APPLICATION_TABLES, S3_EXPORT_TABLES


def test_only_approved_application_tables_are_registered():
    assert APPLICATION_TABLES == (
        'prj_attribute_master_test',
        'prj_portfolio_reference_test',
        'prj_attribute_portfolio_scope_test',
        'prj_attribute_business_rules_test',
        'prj_scanning_prompt_reference_test',
        'audit_table_test',
    )
    assert S3_EXPORT_TABLES == (
        'prj_attribute_master_test',
        'prj_attribute_portfolio_scope_test',
        'prj_attribute_business_rules_test',
        'prj_scanning_prompt_reference_test',
    )
