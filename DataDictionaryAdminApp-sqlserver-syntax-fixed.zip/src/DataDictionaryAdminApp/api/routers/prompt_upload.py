from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from DataDictionaryAdminApp.service.excel_service import ExcelService

router=APIRouter(prefix='/prompt-upload',tags=['Prompt Upload'])

@router.post('/sheets')
async def sheets(file:UploadFile=File(...)): return {'sheets':ExcelService().sheets(await file.read())}

@router.post('/preview')
async def preview(file:UploadFile=File(...),sheet_name:str=Form(...)):
    try:
        df=ExcelService().read_prompt_workbook(await file.read(),sheet_name)
        return {'sheet':sheet_name,'row_count':len(df),'columns':[str(c) for c in df.columns],'preview':df.head(50).where(df.notna(),None).to_dict(orient='records')}
    except Exception as e: raise HTTPException(400,f'Unable to parse Prompt workbook: {e}')

@router.post('/delta')
async def delta(file:UploadFile=File(...),sheet_name:str=Form(...)):
    df=ExcelService().read_prompt_workbook(await file.read(),sheet_name)
    return {'status':'preview_ready','new':len(df),'updated':0,'soft_delete_candidates':0,'message':'Use /prompt-upload/finalize after validation.'}

@router.post('/finalize')
def finalize_prompt(): raise HTTPException(501,'Prompt bulk finalization is not enabled in this base package.')
