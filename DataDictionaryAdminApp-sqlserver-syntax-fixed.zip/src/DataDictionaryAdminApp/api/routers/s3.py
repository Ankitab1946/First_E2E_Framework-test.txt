from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
import pandas as pd
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.model.entities import AttributeMaster, AttributePortfolioScope, AttributeBusinessRule, ScanningPromptReference
from DataDictionaryAdminApp.service.s3_service import S3Service
from DataDictionaryAdminApp.repositories.data_dictionary_repository import DataDictionaryRepository
from DataDictionaryAdminApp.utils.security import current_user
router=APIRouter(prefix='/s3',tags=['S3 Export'])
def frame(db, model): return pd.DataFrame([{c.name:getattr(x,c.name) for c in x.__table__.columns} for x in db.scalars(select(model)).all()])
@router.post('/export')
def export_all(user:str|None=Query(None),db:Session=Depends(get_db)):
    try:
        keys=S3Service().export_frames({'master_data':frame(db,AttributeMaster),'attribute_scope':frame(db,AttributePortfolioScope),'business_rules':frame(db,AttributeBusinessRule),'prompt_data':frame(db,ScanningPromptReference)})
        DataDictionaryRepository(db).audit('s3_export','ALL','EXPORT',None,{'keys':keys},current_user(user),'S3_EXPORT'); db.commit(); return {'status':'exported','keys':keys}
    except Exception as e: raise HTTPException(400,str(e))
