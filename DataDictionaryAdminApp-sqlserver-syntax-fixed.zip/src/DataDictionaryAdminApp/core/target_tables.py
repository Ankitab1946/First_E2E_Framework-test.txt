"""Authoritative list of the only application-managed SQL Server tables."""

ATTRIBUTE_MASTER = "prj_attribute_master_test"
PORTFOLIO_REFERENCE = "prj_portfolio_reference_test"
ATTRIBUTE_PORTFOLIO_SCOPE = "prj_attribute_portfolio_scope_test"
ATTRIBUTE_BUSINESS_RULES = "prj_attribute_business_rules_test"
SCANNING_PROMPT_REFERENCE = "prj_scanning_prompt_reference_test"
AUDIT = "audit_table_test"

APPLICATION_TABLES: tuple[str, ...] = (
    ATTRIBUTE_MASTER,
    PORTFOLIO_REFERENCE,
    ATTRIBUTE_PORTFOLIO_SCOPE,
    ATTRIBUTE_BUSINESS_RULES,
    SCANNING_PROMPT_REFERENCE,
    AUDIT,
)

S3_EXPORT_TABLES: tuple[str, ...] = (
    ATTRIBUTE_MASTER,
    ATTRIBUTE_PORTFOLIO_SCOPE,
    ATTRIBUTE_BUSINESS_RULES,
    SCANNING_PROMPT_REFERENCE,
)
