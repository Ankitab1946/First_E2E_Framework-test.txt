from typing import Any


class DeltaService:
    def compare(self, db_records: list[dict[str, Any]], uploaded_records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        db_map = {str(r.get("prj_id", "")).strip(): r for r in db_records if r.get("prj_id")}
        upload_map = {str(r.get("prj_id", "")).strip(): r for r in uploaded_records if r.get("prj_id")}
        deltas: list[dict[str, Any]] = []

        for prj_id, uploaded_record in upload_map.items():
            if prj_id not in db_map:
                deltas.append({**uploaded_record, "delta_type": "NEW", "changed_fields": list(uploaded_record.keys())})
                continue
            old_record = db_map[prj_id]
            changed_fields = self._get_changed_fields(old_record, uploaded_record)
            if changed_fields:
                deltas.append({**uploaded_record, "delta_type": "UPDATED", "changed_fields": changed_fields, "old_record": old_record})

        for prj_id, db_record in db_map.items():
            if prj_id not in upload_map:
                deltas.append({**db_record, "delta_type": "DELETED", "changed_fields": ["is_active"], "old_record": db_record})

        return deltas

    def _get_changed_fields(self, old_record: dict, new_record: dict) -> list[str]:
        ignored = {"created_at", "updated_at", "created_by", "updated_by", "version_no", "is_active", "old_record", "changed_fields", "delta_type"}
        changed = []
        for key, new_value in new_record.items():
            if key in ignored:
                continue
            if self._normalize(old_record.get(key)) != self._normalize(new_value):
                changed.append(key)
        return changed

    @staticmethod
    def _normalize(value: Any) -> str:
        if value is None:
            return ""
        if isinstance(value, bool):
            return "true" if value else "false"
        return str(value).strip()
