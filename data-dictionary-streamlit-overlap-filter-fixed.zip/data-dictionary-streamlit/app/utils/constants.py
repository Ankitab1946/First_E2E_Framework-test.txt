PORTFOLIO_OPTIONS = ["FI Banks", "Corporates", "FI Insurance", "Zeus Downstream", "ALL"]

SECTION_OPTIONS = [
    "Income Statement",
    "Balance Sheet",
    "Cash Flow",
    "Ratios",
    "Derivatives",
    "Miscellaneous and Other",
]

LIMITED_DICTIONARY_FIELDS = [
    "prj_id",
    "prj_attribute_name",
    "prj_attribute_description",
    "prj_physical_attribute_name",
    "editable",
    "percentage_ratio",
    "version_update",
    "where_in_financial_statement",
    "required_by_corporates",
    "required_by_banks",
    "required_by_insurance",
    "required_by_downstream",
]

PORTFOLIO_FIELD_MAP = {
    "FI Banks": "required_by_banks",
    "Corporates": "required_by_corporates",
    "FI Insurance": "required_by_insurance",
    "Zeus Downstream": "required_by_downstream",
}
