import json
from sqlalchemy import or_
from sqlalchemy.orm import Session
from app.models.audit import AuditLog, HistoryLog, PromptLibrary
from app.models.master_dictionary import MasterDictionary
from app.repositories.filter_utils import apply_dictionary_filters
from app.utils.constants import PORTFOLIO_FIELD_MAP


class AuditRepository:
    def log_audit(self, db: Session, *, batch_id: str, prj_id: str, table_name: str, action_type: str,
                  source_module: str, old_value, new_value, changed_by: str) -> None:
        db.add(AuditLog(
            batch_id=batch_id,
            prj_id=prj_id,
            table_name=table_name,
            action_type=action_type,
            source_module=source_module,
            old_value=json.dumps(old_value, default=str) if old_value is not None else None,
            new_value=json.dumps(new_value, default=str) if new_value is not None else None,
            changed_by=changed_by,
        ))

    def log_history(self, db: Session, *, batch_id: str, prj_id: str, table_name: str, action_type: str,
                    snapshot, changed_by: str) -> None:
        db.add(HistoryLog(
            batch_id=batch_id,
            prj_id=prj_id,
            table_name=table_name,
            action_type=action_type,
            snapshot_json=json.dumps(snapshot, default=str) if snapshot is not None else None,
            changed_by=changed_by,
        ))

    def search_audit(self, db: Session, *, prj_id: str = "", attribute_name: str = "", section: str = "",
                     portfolio: str = "ALL", include_full_history: bool = False) -> list[dict]:
        filters = {
            "portfolios": [portfolio] if portfolio else ["ALL"],
            "prj_id": prj_id,
            "attribute_name": attribute_name,
            "section": section,
            "active_only": False,
            "limit": 1000 if include_full_history else 200,
        }
        return self.filter_audit(db, filters=filters, include_full_history=include_full_history)

    def filter_audit(self, db: Session, *, filters: dict, include_full_history: bool = False) -> list[dict]:
        query = db.query(AuditLog).outerjoin(MasterDictionary, MasterDictionary.prj_id == AuditLog.prj_id)
        query = apply_dictionary_filters(
            query,
            portfolios=filters.get("portfolios"),
            portfolio_sector=filters.get("portfolio_sector"),
            prj_id=filters.get("prj_id", ""),
            attribute_name=filters.get("attribute_name", ""),
            attribute_description=filters.get("attribute_description", ""),
            section=filters.get("section", ""),
            overlapped_attribute=bool(filters.get("overlapped_attribute", False)),
            active_only=False,
        )
        action_type = str(filters.get("action_type") or "").strip()
        changed_by = str(filters.get("changed_by") or "").strip()
        if action_type:
            query = query.filter(AuditLog.action_type == action_type)
        if changed_by:
            query = query.filter(AuditLog.changed_by.ilike(f"%{changed_by}%"))
        limit = int(filters.get("limit") or (1000 if include_full_history else 200))
        rows = query.order_by(AuditLog.changed_at.desc()).limit(limit).all()
        return [self._audit_to_dict(row) for row in rows]

    def get_full_history(self, db: Session) -> list[dict]:
        rows = db.query(AuditLog).order_by(AuditLog.changed_at.desc()).limit(2000).all()
        return [self._audit_to_dict(row) for row in rows]

    def get_prompts(self, db: Session) -> list[dict]:
        rows = db.query(PromptLibrary).filter(PromptLibrary.is_active == True).order_by(PromptLibrary.prompt_name).all()  # noqa: E712
        return [{
            "prompt_name": row.prompt_name,
            "prompt_category": row.prompt_category,
            "prompt_text": row.prompt_text,
            "created_at": row.created_at,
        } for row in rows]

    def _audit_to_dict(self, row: AuditLog) -> dict:
        return {
            "id": row.id,
            "batch_id": row.batch_id,
            "prj_id": row.prj_id,
            "table_name": row.table_name,
            "action_type": row.action_type,
            "source_module": row.source_module,
            "old_value": row.old_value,
            "new_value": row.new_value,
            "changed_by": row.changed_by,
            "changed_at": row.changed_at,
        }
