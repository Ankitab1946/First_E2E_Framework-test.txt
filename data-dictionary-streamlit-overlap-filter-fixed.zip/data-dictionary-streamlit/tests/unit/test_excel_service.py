from app.services.excel_service import ExcelService
from app.utils.sample_data import get_sample_records


def test_generate_and_parse_template_roundtrip():
    service = ExcelService()
    stream = service.generate_template(get_sample_records(), "1.0")
    records = service.parse_uploaded_file(stream.getvalue())
    assert len(records) == 2
    assert records[0]["prj_id"] == "PRJ001"
    assert records[0]["editable"] is True
