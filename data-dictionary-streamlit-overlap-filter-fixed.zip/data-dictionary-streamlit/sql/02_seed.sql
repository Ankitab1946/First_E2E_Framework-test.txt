USE PRJ_DB;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.master_dictionary WHERE prj_id = 'PRJ001')
BEGIN
    INSERT INTO dbo.master_dictionary (
        prj_id, prj_attribute_name, prj_attribute_description, prj_physical_attribute_name,
        editable, percentage_ratio, calculation_logic, where_in_financial_statement,
        required_by_corporates, required_by_banks, required_by_insurance, required_by_downstream,
        version_update, release_scope, mapping_type, calculation_in_prj, editable_in_historicals,
        sign_flipping, gc_template_attribute_name, sp_standardisation_attribute_name,
        sp_standardisation_dataitem_id, sp_as_reported_dataitem_id, updates, zeus_attribute,
        zeus_table_name, zeus_description, comments, snl_dataitemid, scanned_calculated
    )
    VALUES
    ('PRJ001','Revenue','Total revenue reported by company','revenue_amt',1,'Amount','As reported','Income Statement',1,1,0,1,'v1','Global','Direct','No',0,0,'Revenue','Revenue','1001','AR1001','Initial setup','revenue','financials','Revenue amount','Seed sample','SNL1001','Scanned');
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.master_dictionary WHERE prj_id = 'PRJ002')
BEGIN
    INSERT INTO dbo.master_dictionary (
        prj_id, prj_attribute_name, prj_attribute_description, prj_physical_attribute_name,
        editable, percentage_ratio, calculation_logic, where_in_financial_statement,
        required_by_corporates, required_by_banks, required_by_insurance, required_by_downstream,
        version_update, release_scope, mapping_type, calculation_in_prj, editable_in_historicals,
        sign_flipping, gc_template_attribute_name, sp_standardisation_attribute_name,
        sp_standardisation_dataitem_id, sp_as_reported_dataitem_id, updates, zeus_attribute,
        zeus_table_name, zeus_description, comments, snl_dataitemid, scanned_calculated
    )
    VALUES
    ('PRJ002','EBITDA','Earnings before interest tax depreciation amortization','ebitda_amt',1,'Amount','Operating Profit + D&A','Income Statement / Notes',1,1,1,1,'v1','Global','Calculated','Yes',1,0,'EBITDA','EBITDA','1002','AR1002','Initial setup','ebitda','financials','EBITDA amount','Seed sample','SNL1002','Calculated');
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.prompt_library WHERE prompt_name = 'Data Dictionary Change Summary')
BEGIN
    INSERT INTO dbo.prompt_library (prompt_name, prompt_category, prompt_text, is_active)
    VALUES ('Data Dictionary Change Summary', 'Data Dictionary', 'Summarize the latest Data Dictionary changes by portfolio, PRJ_ID, section, and business impact.', 1);
END
GO
