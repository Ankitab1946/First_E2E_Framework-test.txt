#!/usr/bin/env bash
uvicorn app.api.swagger_app:app --host 0.0.0.0 --port 8000 --reload
