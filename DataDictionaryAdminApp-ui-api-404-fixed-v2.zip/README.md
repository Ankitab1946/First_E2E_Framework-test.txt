# Data Dictionary Admin App

Production-oriented three-tier Python application for managing PRJ data-dictionary and prompt records.

## Architecture
- **Presentation:** Streamlit (`streamlit_app.py`)
- **Application/API:** FastAPI (`api/`)
- **Business/Repository/Data:** service, repository, SQL Server models
- **Storage:** SQL Server and S3-compatible object storage

## Run locally
```bash
copy .env.example .env
poetry install
poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --reload --port 8502
poetry run streamlit run src/DataDictionaryAdminApp/streamlit_app.py --server.port 8501
```

Swagger: `http://localhost:8502/docs`  
UI: `http://localhost:8501`

## Bootstrap database
Run `src/DataDictionaryAdminApp/sql/001_create_tables.sql` in the target SQL Server database. It creates only the six requested operational tables and assumes `prj_data_source` already exists.

## Tests
```bash
poetry run pytest --alluredir=allure-results
allure serve allure-results
```

## Environment configuration
Copy `.env.example` to `.env`. The Streamlit sidebar sends the selected environment to the API using the `X-App-Environment` header. The API resolves `ENV_<ENV>_SQLSERVER_*` first, then falls back to default `SQLSERVER_*` values.

For internal S3-compatible storage, set `BUCKET_NAME`, `HOST`, `ACCESS_KEY_ID`, and `SECRET_KEY`. `HOST` must contain only the service endpoint and port, never a bucket or folder path. Keep `S3_USE_SSL=false` and `S3_VERIFY_SSL=false` for internal endpoints that use a self-signed certificate chain.

## Database bootstrap and legacy-object safety
Run `src/DataDictionaryAdminApp/sql/001_create_tables.sql`. It is idempotent: it does not drop tables or existing data, and all new constraints/indexes use the `ddam` naming prefix to avoid collisions with legacy objects such as `ug_portfolio_rerenece`.

If SQL Server still reports a legacy-object conflict, first run `src/DataDictionaryAdminApp/sql/000_preflight_existing_objects.sql` and share its result. Do not manually drop a legacy object until its dependency is confirmed.

## Retiring superseded legacy tables

The application operates only on these six tables:

- `prj_attribute_master_test`
- `prj_portfolio_reference_test`
- `prj_attribute_portfolio_scope_test`
- `prj_attribute_business_rules_test`
- `prj_scanning_prompt_reference_test`
- `audit_table_test`

The following old tables are not used by the application and must be retired:

- `prj_attribute`
- `prj_attribute_logc_test`
- `prj_attr_business_logic`
- `prj_ui_display_config_test`

Execution order:

1. `src/DataDictionaryAdminApp/sql/000_preflight_existing_objects.sql`
2. `src/DataDictionaryAdminApp/sql/002_remove_legacy_tables.sql`
3. `src/DataDictionaryAdminApp/sql/001_create_tables.sql`

`002_remove_legacy_tables.sql` drops foreign keys attached to the four retired tables and then drops those tables. It does not drop or modify the six active application tables.

## Swagger route groups (v2.1.0)

The application exposes the following independent FastAPI route groups under `/api/v1`:

- `/data-dictionary`
- `/master-upload`
- `/prompts`
- `/prompt-upload`
- `/portfolio-reference`
- `/lookups`
- `/audit`
- `/history`
- `/s3`
- `/admin`
- `/system`

Swagger UI is available at `/docs` when the API is running.


## Resolving `API error (404): Not found`

The Streamlit UI now normalizes `API_BASE_URL` automatically. You may configure either `http://localhost:8502` or `http://localhost:8502/api/v1`; the UI will use `http://localhost:8502/api/v1`. Start both processes from the same extracted project folder:

```powershell
poetry run python -m DataDictionaryAdminApp.api
poetry run streamlit run src\DataDictionaryAdminApp\streamlit_app.py --server.port 8501
```

Verify the active API build before opening Streamlit:

```text
http://localhost:8502/api/v1
http://localhost:8502/api/v1/health
http://localhost:8502/api/v1/system/environment
```

If `/api/v1` does not return the `route_groups` response, stop old `uvicorn` / Python processes and start the command above from this package.


## 404 troubleshooting built into this release
The Streamlit client now retries the supported route aliases when a configured route returns HTTP 404. The sidebar reads `.env` by searching from the Streamlit file upward to the project root. Keep `API_BASE_URL=http://localhost:8502/api/v1` in `.env`, start FastAPI with `poetry run python -m DataDictionaryAdminApp.api`, then start Streamlit from the same project root.
