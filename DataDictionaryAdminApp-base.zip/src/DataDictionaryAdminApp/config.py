from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    app_env: str = "DEV"
    api_host: str = "0.0.0.0"
    api_port: int = 8502
    streamlit_api_base_url: str = "http://localhost:8502/api/v1"
    sql_server: str = "localhost"
    sql_database: str = "PRJ_DB"
    sql_driver: str = "ODBC Driver 17 for SQL Server"
    sql_trusted_connection: str = "yes"
    sql_encrypt: str = "no"
    sql_trust_server_certificate: str = "yes"
    s3_bucket_name: str = ""
    s3_host: str = ""
    s3_secure_host: str = ""
    s3_access_key_id: str = ""
    s3_secret_key: str = ""
    s3_use_ssl: bool = False
    s3_verify_ssl: bool = False
    admin_users: str = "admin,sysuser"

    @property
    def connection_string(self) -> str:
        return (
            f"DRIVER={{{self.sql_driver}}};SERVER={self.sql_server};DATABASE={self.sql_database};"
            f"Trusted_Connection={self.sql_trusted_connection};Encrypt={self.sql_encrypt};"
            f"TrustServerCertificate={self.sql_trust_server_certificate};"
        )

    def is_admin(self, username: str) -> bool:
        return username.lower() in {x.strip().lower() for x in self.admin_users.split(',') if x.strip()}

@lru_cache
def get_settings() -> Settings:
    return Settings()
