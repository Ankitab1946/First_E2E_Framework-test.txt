from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from urllib.parse import quote_plus
from DataDictionaryAdminApp.config import get_settings

settings = get_settings()
engine = create_engine(f"mssql+pyodbc:///?odbc_connect={quote_plus(settings.connection_string)}", future=True, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
