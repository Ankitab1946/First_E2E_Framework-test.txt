from io import BytesIO
from datetime import datetime
import boto3
import pandas as pd
from DataDictionaryAdminApp.config import get_settings

class S3Service:
    def __init__(self):
        s=get_settings(); self.bucket=s.s3_bucket_name
        self.client=boto3.client('s3',aws_access_key_id=s.s3_access_key_id,aws_secret_access_key=s.s3_secret_key,use_ssl=s.s3_use_ssl,verify=s.s3_verify_ssl,endpoint_url=s.s3_host or s.s3_secure_host)
    def export_frames(self, frames):
        stamp=datetime.utcnow().strftime('%Y%m%d_%H%M%S'); keys=[]
        for name,frame in frames.items():
            key=f'data-dictionary/{stamp}/{name}_{stamp}.xlsx'; stream=BytesIO(); frame.to_excel(stream,index=False)
            self.client.put_object(Bucket=self.bucket,Key=key,Body=stream.getvalue());keys.append(key)
        return keys
