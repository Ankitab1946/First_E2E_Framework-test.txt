from fastapi import FastAPI
from DataDictionaryAdminApp.api.routers import data_dictionary,audit
app=FastAPI(title='Data Dictionary Admin API',version='1.0.0',description='CRUD, filters, audit, Excel and S3 integration API')
app.include_router(data_dictionary.router,prefix='/api/v1')
app.include_router(audit.router,prefix='/api/v1')
@app.get('/health')
def health(): return {'status':'UP'}
