from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
router=APIRouter(prefix='/audit',tags=['Audit History'])
@router.get('')
def get_audit(table_name:str|None=None,record_key:str|None=None,db:Session=Depends(get_db)):
    rows=DataDictionaryService(db).audit_rows(table_name,record_key)
    return [{c.name:getattr(x,c.name) for c in x.__table__.columns} for x in rows]
