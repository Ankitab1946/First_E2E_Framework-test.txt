# Data Dictionary Admin App

Production-oriented three-tier Python application for managing PRJ data-dictionary and prompt records.

## Architecture
- **Presentation:** Streamlit (`streamlit_app.py`)
- **Application/API:** FastAPI (`api/`)
- **Business/Repository/Data:** service, repository, SQL Server models
- **Storage:** SQL Server and S3-compatible object storage

## Run locally
```bash
copy .env.example .env
poetry install
poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --reload --port 8502
poetry run streamlit run src/DataDictionaryAdminApp/streamlit_app.py --server.port 8501
```

Swagger: `http://localhost:8502/docs`  
UI: `http://localhost:8501`

## Bootstrap database
Run `src/DataDictionaryAdminApp/sql/001_create_tables.sql` in the target SQL Server database. It creates only the six requested operational tables and assumes `prj_data_source` already exists.

## Tests
```bash
poetry run pytest --alluredir=allure-results
allure serve allure-results
```
