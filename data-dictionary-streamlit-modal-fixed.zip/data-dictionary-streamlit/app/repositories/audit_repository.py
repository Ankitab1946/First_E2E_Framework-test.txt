import json
from sqlalchemy import or_
from sqlalchemy.orm import Session
from app.models.audit import AuditLog, HistoryLog, PromptLibrary
from app.utils.constants import PORTFOLIO_FIELD_MAP
from app.models.master_dictionary import MasterDictionary


class AuditRepository:
    def log_audit(self, db: Session, *, batch_id: str, prj_id: str, table_name: str, action_type: str,
                  source_module: str, old_value, new_value, changed_by: str) -> None:
        db.add(AuditLog(
            batch_id=batch_id,
            prj_id=prj_id,
            table_name=table_name,
            action_type=action_type,
            source_module=source_module,
            old_value=json.dumps(old_value, default=str) if old_value is not None else None,
            new_value=json.dumps(new_value, default=str) if new_value is not None else None,
            changed_by=changed_by,
        ))

    def log_history(self, db: Session, *, batch_id: str, prj_id: str, table_name: str, action_type: str,
                    snapshot, changed_by: str) -> None:
        db.add(HistoryLog(
            batch_id=batch_id,
            prj_id=prj_id,
            table_name=table_name,
            action_type=action_type,
            snapshot_json=json.dumps(snapshot, default=str) if snapshot is not None else None,
            changed_by=changed_by,
        ))

    def search_audit(self, db: Session, *, prj_id: str = "", attribute_name: str = "", section: str = "",
                     portfolio: str = "ALL", include_full_history: bool = False) -> list[dict]:
        query = db.query(AuditLog)
        if prj_id:
            query = query.filter(AuditLog.prj_id.ilike(f"%{prj_id}%"))
        if attribute_name or section or portfolio != "ALL":
            query = query.join(MasterDictionary, MasterDictionary.prj_id == AuditLog.prj_id)
        if attribute_name:
            like_value = f"%{attribute_name}%"
            query = query.filter(
                or_(
                    MasterDictionary.prj_attribute_name.ilike(like_value),
                    MasterDictionary.prj_attribute_description.ilike(like_value),
                )
            )
        if section:
            query = query.filter(MasterDictionary.where_in_financial_statement == section)
        field_name = PORTFOLIO_FIELD_MAP.get(portfolio)
        if field_name:
            query = query.filter(getattr(MasterDictionary, field_name) == True)  # noqa: E712
        rows = query.order_by(AuditLog.changed_at.desc()).limit(1000 if include_full_history else 200).all()
        return [self._audit_to_dict(row) for row in rows]

    def get_full_history(self, db: Session) -> list[dict]:
        rows = db.query(AuditLog).order_by(AuditLog.changed_at.desc()).limit(2000).all()
        return [self._audit_to_dict(row) for row in rows]

    def get_prompts(self, db: Session) -> list[dict]:
        rows = db.query(PromptLibrary).filter(PromptLibrary.is_active == True).order_by(PromptLibrary.prompt_name).all()  # noqa: E712
        return [{
            "prompt_name": row.prompt_name,
            "prompt_category": row.prompt_category,
            "prompt_text": row.prompt_text,
            "created_at": row.created_at,
        } for row in rows]

    def _audit_to_dict(self, row: AuditLog) -> dict:
        return {
            "id": row.id,
            "batch_id": row.batch_id,
            "prj_id": row.prj_id,
            "table_name": row.table_name,
            "action_type": row.action_type,
            "source_module": row.source_module,
            "old_value": row.old_value,
            "new_value": row.new_value,
            "changed_by": row.changed_by,
            "changed_at": row.changed_at,
        }
