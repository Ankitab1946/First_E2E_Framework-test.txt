USE DataDictionaryDB;
GO

INSERT INTO dbo.master_dictionary (
    prj_id, prj_attribute_name, prj_attribute_description,
    prj_physical_attribute_name, editable, percentage_ratio,
    calculation_logic, required_by_corporates, required_by_banks,
    version_update, release_scope, mapping_type, created_by, updated_by
)
VALUES
('PRJ001', 'Revenue', 'Total revenue from financial statement', 'revenue_amt', 1, 'Ratio', 'Direct mapping', 1, 1, 'v1', 'Global', 'Direct', 'seed', 'seed'),
('PRJ002', 'EBITDA', 'Earnings before interest tax depreciation and amortization', 'ebitda_amt', 1, 'Ratio', 'Calculated', 1, 1, 'v1', 'Global', 'Calculated', 'seed', 'seed');
GO
