import DictionaryAdminPage from "./pages/DictionaryAdminPage";

export default function App() {
  return <DictionaryAdminPage />;
}
