import { render, screen } from "@testing-library/react";
import DictionaryAdminPage from "./DictionaryAdminPage";

it("renders title", () => {
  render(<DictionaryAdminPage />);
  expect(screen.getByText(/Data Dictionary Management/i)).toBeTruthy();
});
