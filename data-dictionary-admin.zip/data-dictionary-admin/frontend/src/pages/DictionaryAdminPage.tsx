import { useEffect, useState } from "react";
import { Alert, Box, Button, Container, Paper, Stack, Tab, Tabs, Typography } from "@mui/material";
import DataGridWrapper from "../components/DataGridWrapper";
import UploadPanel from "../components/UploadPanel";
import ConfirmDialog from "../components/ConfirmDialog";
import { dictionaryApi } from "../api/dictionaryApi";

export default function DictionaryAdminPage() {
  const [tab, setTab] = useState(0);
  const [latestRows, setLatestRows] = useState<any[]>([]);
  const [editableRows, setEditableRows] = useState<any[]>([]);
  const [deltaRows, setDeltaRows] = useState<any[]>([]);
  const [hasChanges, setHasChanges] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [message, setMessage] = useState("");

  const loadLatest = async () => setLatestRows(await dictionaryApi.getLatest());
  const loadAll = async () => setEditableRows(await dictionaryApi.getAll());

  useEffect(() => { loadLatest(); }, []);

  const handleUpload = async (file: File) => {
    const result = await dictionaryApi.uploadAndCompare(file);
    setDeltaRows(result.deltas || []);
    setHasChanges((result.deltas || []).length > 0);
    setTab(2);
    setMessage(`Detected ${result.delta_count} delta records from ${result.file_name}`);
  };

  const handleAddRow = () => {
    setEditableRows([{ id: crypto.randomUUID(), prj_id: "", delta_type: "NEW" }, ...editableRows]);
    setHasChanges(true);
  };

  const handleFinalize = async () => {
    const rows = deltaRows.length > 0 ? deltaRows : editableRows.filter((r) => r.delta_type);
    const result = await dictionaryApi.finalize(rows, deltaRows.length > 0 ? "UPLOAD_AND_EDIT" : "EDIT_LATEST");
    setConfirmOpen(false);
    setHasChanges(false);
    setMessage(`Upload successful. Batch ID: ${result.batch_id}`);
    await loadLatest();
  };

  return (
    <Container maxWidth="xl" sx={{ py: 3 }}>
      <Typography variant="h4" gutterBottom>Data Dictionary Management</Typography>
      {message && <Alert severity="info" sx={{ mb: 2 }}>{message}</Alert>}

      <Paper sx={{ p: 2 }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)}>
          <Tab label="View Latest" />
          <Tab label="Edit Latest" />
          <Tab label="Upload and Edit" />
          <Tab label="Finalize and Upload" disabled={!hasChanges} />
        </Tabs>

        {tab === 0 && (
          <Box mt={2}>
            <Stack direction="row" spacing={2}>
              <Button variant="contained" onClick={loadLatest}>View Latest</Button>
              <Button variant="outlined" onClick={dictionaryApi.downloadTemplate}>Download Latest</Button>
            </Stack>
            <DataGridWrapper rows={latestRows} editable={false} />
          </Box>
        )}

        {tab === 1 && (
          <Box mt={2}>
            <Stack direction="row" spacing={2}>
              <Button variant="contained" onClick={loadAll}>Load Editable Data</Button>
              <Button variant="outlined" onClick={handleAddRow}>Add New Row</Button>
            </Stack>
            <DataGridWrapper rows={editableRows} editable={true} onRowsChange={(rows: any[]) => { setEditableRows(rows); setHasChanges(true); }} />
          </Box>
        )}

        {tab === 2 && (
          <Box mt={2}>
            <UploadPanel onUpload={handleUpload} />
            <DataGridWrapper rows={deltaRows} editable={true} onRowsChange={(rows: any[]) => { setDeltaRows(rows); setHasChanges(true); }} />
          </Box>
        )}

        {tab === 3 && (
          <Box mt={2}>
            <Button variant="contained" disabled={!hasChanges} onClick={() => setConfirmOpen(true)}>
              Finalize and Upload
            </Button>
          </Box>
        )}
      </Paper>

      <ConfirmDialog
        open={confirmOpen}
        title="Confirm Database Update"
        message="Do you want to update database tables?"
        onConfirm={handleFinalize}
        onCancel={() => setConfirmOpen(false)}
      />
    </Container>
  );
}
