import { Button } from "@mui/material";

export default function UploadPanel({ onUpload }: { onUpload: (file: File) => void }) {
  return (
    <Button variant="outlined" component="label">
      Upload Excel
      <input
        type="file"
        hidden
        accept=".xlsx"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onUpload(file);
        }}
      />
    </Button>
  );
}
