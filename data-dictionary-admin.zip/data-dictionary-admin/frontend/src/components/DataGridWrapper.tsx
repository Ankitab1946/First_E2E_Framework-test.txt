import { Box } from "@mui/material";
import { DataGrid, GridColDef } from "@mui/x-data-grid";

const fields = [
  "delta_type",
  "prj_id",
  "prj_attribute_name",
  "prj_attribute_description",
  "prj_physical_attribute_name",
  "editable",
  "percentage_ratio",
  "calculation_logic",
  "where_in_financial_statement",
  "required_by_corporates",
  "required_by_banks",
  "required_by_insurance",
  "required_by_downstream",
  "version_update",
  "release_scope",
  "mapping_type",
  "calculation_in_prj",
  "editable_in_historicals",
  "sign_flipping",
  "gc_template_attribute_name",
  "sp_standardisation_attribute_name",
  "sp_standardisation_dataitem_id",
  "sp_as_reported_dataitem_id",
  "updates",
  "updated_on",
  "zeus_attribute",
  "zeus_table_name",
  "zeus_description",
  "comments",
  "snl_dataitemid",
  "scanned_calculated",
];

export default function DataGridWrapper({ rows, editable, onRowsChange }: any) {
  const columns: GridColDef[] = fields.map((field) => ({
    field,
    headerName: field.replaceAll("_", " ").toUpperCase(),
    width: field === "prj_attribute_description" || field === "calculation_logic" ? 300 : 180,
    editable: editable && field !== "delta_type",
  }));

  const safeRows = (rows || []).map((row: any, index: number) => ({ id: row.id || row.prj_id || index, ...row }));

  return (
    <Box sx={{ height: 600, width: "100%", mt: 2 }}>
      <DataGrid
        rows={safeRows}
        columns={columns}
        pageSizeOptions={[10, 25, 50, 100]}
        initialState={{ pagination: { paginationModel: { pageSize: 25 } } }}
        processRowUpdate={(newRow) => {
          const updated = safeRows.map((r: any) => (r.id === newRow.id ? newRow : r));
          onRowsChange?.(updated);
          return newRow;
        }}
      />
    </Box>
  );
}
