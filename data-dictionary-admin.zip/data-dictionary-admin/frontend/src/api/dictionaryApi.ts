import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:8000/api/v1";

export const dictionaryApi = {
  getLatest: async () => (await axios.get(`${API_BASE_URL}/dictionary/latest`)).data,
  getAll: async () => (await axios.get(`${API_BASE_URL}/dictionary/all`)).data,

  downloadTemplate: async () => {
    const response = await axios.get(`${API_BASE_URL}/dictionary/template/download`, { responseType: "blob" });
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "data_dictionary_template.xlsx");
    document.body.appendChild(link);
    link.click();
    link.remove();
  },

  uploadAndCompare: async (file: File) => {
    const formData = new FormData();
    formData.append("file", file);
    return (await axios.post(`${API_BASE_URL}/dictionary/upload/compare`, formData)).data;
  },

  finalize: async (changes: any[], sourceModule: string) => {
    return (await axios.post(`${API_BASE_URL}/dictionary/finalize`, {
      changes,
      source_module: sourceModule,
    })).data;
  },
};
