# Data Dictionary Admin App

Enterprise-grade three-tier starter project for managing PRJ Data Dictionary records with:

- React + TypeScript frontend
- FastAPI backend
- SQL Server database scripts
- Excel download/upload
- Delta detection: NEW / UPDATED / DELETED
- Finalization workflow
- Audit and history strategy
- Docker Compose
- Pytest + Allure setup

## Project Structure

```text
backend/      FastAPI application
frontend/     React application
sql/          SQL Server schema and seed scripts
docker-compose.yml
```

## Run with Docker Compose

```bash
docker compose up --build
```

Services:

| Service | URL |
|---|---|
| Frontend | http://localhost:3000 |
| Backend Swagger | http://localhost:8000/docs |
| Health API | http://localhost:8000/api/v1/health |
| SQL Server | localhost:1433 |

## Backend Local Setup

```bash
cd backend
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

## Frontend Local Setup

```bash
cd frontend
npm install
npm run dev
```

## Run Tests

Backend:

```bash
cd backend
pytest
allure serve allure-results
```

Frontend:

```bash
cd frontend
npm test
```

## Important Notes

This is a complete production-style starter implementation. For a real enterprise rollout, add:

- AD/SSO integration
- Server-side pagination for large datasets
- Environment-specific deployment manifests
- Secrets management through Vault/Azure Key Vault
- Full database migration tooling such as Alembic
- Role-based access control
