from fastapi import APIRouter, Depends, File, Header, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from app.core.config import settings
from app.core.database import get_db
from app.schemas.dictionary_schema import FinalizeRequest
from app.services.dictionary_service import DictionaryService
from app.services.delta_service import DeltaService
from app.services.excel_service import ExcelService
from app.services.finalization_service import FinalizationService

router = APIRouter(prefix="/dictionary", tags=["Dictionary"])

dictionary_service = DictionaryService()
excel_service = ExcelService()
delta_service = DeltaService()
finalization_service = FinalizationService()

@router.get("/latest")
def get_latest(db: Session = Depends(get_db)):
    return dictionary_service.get_latest_records_as_dict(db)

@router.get("/all")
def get_all(db: Session = Depends(get_db)):
    return dictionary_service.get_all_records_as_dict(db)

@router.get("/template/download")
def download_template(db: Session = Depends(get_db)):
    records = dictionary_service.get_latest_records_as_dict(db)
    stream = excel_service.generate_template(records, settings.excel_template_version)
    return StreamingResponse(
        stream,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=data_dictionary_template.xlsx"},
    )

@router.post("/upload/compare")
async def upload_compare(file: UploadFile = File(...), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith(".xlsx"):
        return {"error": "Only .xlsx files are supported"}
    data = await file.read()
    uploaded = excel_service.parse_uploaded_file(data)
    current = dictionary_service.get_latest_records_as_dict(db)
    deltas = delta_service.compare(current, uploaded)
    return {"file_name": file.filename, "total_uploaded_records": len(uploaded), "delta_count": len(deltas), "deltas": deltas}

@router.post("/finalize")
def finalize(payload: FinalizeRequest, db: Session = Depends(get_db), x_user_id: str | None = Header(default=None)):
    return finalization_service.finalize_changes(db, payload.changes, x_user_id or "sysuser", payload.source_module)
