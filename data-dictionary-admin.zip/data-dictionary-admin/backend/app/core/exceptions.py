from fastapi import Request
from fastapi.responses import JSONResponse

class BusinessValidationError(Exception):
    def __init__(self, message: str):
        self.message = message

async def business_validation_exception_handler(request: Request, exc: BusinessValidationError):
    return JSONResponse(status_code=400, content={"error": "BUSINESS_VALIDATION_ERROR", "message": exc.message})
