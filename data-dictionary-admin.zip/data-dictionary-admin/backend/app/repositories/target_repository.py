from sqlalchemy.orm import Session
from app.models.target_tables import PrjAttribute, PrjBusinessLogic, PrjBusinessLogicScope

class TargetRepository:
    def upsert_prj_attribute(self, db: Session, r: dict, user: str):
        obj = db.query(PrjAttribute).filter(PrjAttribute.prj_id == r["prj_id"]).first()
        if obj is None:
            obj = PrjAttribute(prj_id=r["prj_id"], created_by=user)
            db.add(obj)
        obj.prj_attribute_id = r.get("prj_attribute_name")
        obj.prj_attribute_description = r.get("prj_attribute_description")
        obj.prj_physical_attribute_name = r.get("prj_physical_attribute_name")
        obj.where_in_financial_statement = r.get("where_in_financial_statement")
        obj.version_update = r.get("version_update")
        obj.updated_by = user
        obj.is_active = True
        obj.version_no = (obj.version_no or 1) + 1
        db.flush()
        return obj

    def upsert_business_logic(self, db: Session, r: dict, user: str):
        obj = db.query(PrjBusinessLogic).filter(PrjBusinessLogic.prj_id == r["prj_id"]).first()
        if obj is None:
            obj = PrjBusinessLogic(prj_id=r["prj_id"], created_by=user)
            db.add(obj)
        for f in ["editable", "percentage_ratio", "calculation_logic", "release_scope", "mapping_type", "calculation_in_prj", "editable_in_historicals", "sign_flipping", "gc_template_attribute_name", "sp_standardisation_attribute_name", "sp_standardisation_dataitem_id", "sp_as_reported_dataitem_id", "updates", "updated_on", "zeus_attribute", "zeus_table_name", "zeus_description", "comments", "snl_dataitemid", "scanned_calculated"]:
            setattr(obj, f, r.get(f))
        obj.updated_by = user
        obj.is_active = True
        obj.version_no = (obj.version_no or 1) + 1
        db.flush()
        return obj

    def upsert_scope(self, db: Session, r: dict, user: str):
        obj = db.query(PrjBusinessLogicScope).filter(PrjBusinessLogicScope.prj_id == r["prj_id"]).first()
        if obj is None:
            obj = PrjBusinessLogicScope(prj_id=r["prj_id"], created_by=user)
            db.add(obj)
        for f in ["required_by_corporates", "required_by_banks", "required_by_insurance", "required_by_downstream"]:
            setattr(obj, f, r.get(f))
        obj.updated_by = user
        obj.is_active = True
        obj.version_no = (obj.version_no or 1) + 1
        db.flush()
        return obj

    def insert_all(self, db: Session, r: dict, user: str):
        self.upsert_prj_attribute(db, r, user)
        self.upsert_business_logic(db, r, user)
        self.upsert_scope(db, r, user)

    def soft_delete_all(self, db: Session, prj_id: str, user: str):
        for model in [PrjAttribute, PrjBusinessLogic, PrjBusinessLogicScope]:
            obj = db.query(model).filter(model.prj_id == prj_id).first()
            if obj:
                obj.is_active = False
                obj.updated_by = user
                obj.version_no = (obj.version_no or 1) + 1
        db.flush()
