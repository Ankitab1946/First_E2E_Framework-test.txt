from sqlalchemy.orm import Session
from app.models.master_dictionary import MasterDictionary
from app.utils.excel_mapping import BUSINESS_FIELDS

class DictionaryRepository:
    def get_latest(self, db: Session):
        return db.query(MasterDictionary).filter(MasterDictionary.is_active == True).all()

    def get_all(self, db: Session):
        return db.query(MasterDictionary).all()

    def get_by_prj_id(self, db: Session, prj_id: str):
        return db.query(MasterDictionary).filter(MasterDictionary.prj_id == prj_id).first()

    def to_dict(self, model: MasterDictionary | None) -> dict | None:
        if model is None:
            return None
        data = {}
        for field in BUSINESS_FIELDS + ["is_active", "version_no", "created_by", "updated_by"]:
            data[field] = getattr(model, field, None)
        return data

    def insert_master(self, db: Session, record: dict, user_id: str):
        allowed = {k: v for k, v in record.items() if k in BUSINESS_FIELDS}
        obj = MasterDictionary(**allowed, created_by=user_id, updated_by=user_id, is_active=True)
        db.add(obj)
        db.flush()
        return obj

    def update_master(self, db: Session, prj_id: str, record: dict, user_id: str):
        obj = self.get_by_prj_id(db, prj_id)
        if obj is None:
            return self.insert_master(db, record, user_id)
        for k in BUSINESS_FIELDS:
            if k in record and k != "prj_id":
                setattr(obj, k, record[k])
        obj.version_no = (obj.version_no or 1) + 1
        obj.updated_by = user_id
        obj.is_active = True
        db.flush()
        return obj

    def soft_delete_master(self, db: Session, prj_id: str, user_id: str):
        obj = self.get_by_prj_id(db, prj_id)
        if obj:
            obj.is_active = False
            obj.updated_by = user_id
            obj.version_no = (obj.version_no or 1) + 1
        db.flush()
