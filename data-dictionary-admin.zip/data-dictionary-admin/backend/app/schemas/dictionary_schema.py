from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, Field

class DictionaryRecordBase(BaseModel):
    prj_id: str = Field(..., min_length=1, max_length=100)
    prj_attribute_name: Optional[str] = None
    prj_attribute_description: Optional[str] = None
    prj_physical_attribute_name: Optional[str] = None
    editable: Optional[bool] = None
    percentage_ratio: Optional[str] = None
    calculation_logic: Optional[str] = None
    where_in_financial_statement: Optional[str] = None
    required_by_corporates: Optional[bool] = None
    required_by_banks: Optional[bool] = None
    required_by_insurance: Optional[bool] = None
    required_by_downstream: Optional[bool] = None
    version_update: Optional[str] = None
    release_scope: Optional[str] = None
    mapping_type: Optional[str] = None
    calculation_in_prj: Optional[str] = None
    editable_in_historicals: Optional[bool] = None
    sign_flipping: Optional[bool] = None
    gc_template_attribute_name: Optional[str] = None
    sp_standardisation_attribute_name: Optional[str] = None
    sp_standardisation_dataitem_id: Optional[str] = None
    sp_as_reported_dataitem_id: Optional[str] = None
    updates: Optional[str] = None
    updated_on: Optional[datetime] = None
    zeus_attribute: Optional[str] = None
    zeus_table_name: Optional[str] = None
    zeus_description: Optional[str] = None
    comments: Optional[str] = None
    snl_dataitemid: Optional[str] = None
    scanned_calculated: Optional[str] = None

class DictionaryRecordResponse(DictionaryRecordBase):
    is_active: bool = True
    version_no: int = 1
    class Config:
        from_attributes = True

class FinalizeRequest(BaseModel):
    source_module: str = "UNKNOWN"
    changes: list[dict[str, Any]]
