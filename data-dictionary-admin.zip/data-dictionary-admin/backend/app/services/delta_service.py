class DeltaService:
    def compare(self, db_records: list[dict], uploaded_records: list[dict]) -> list[dict]:
        db_map = {x["prj_id"]: x for x in db_records if x.get("prj_id")}
        upload_map = {x["prj_id"]: x for x in uploaded_records if x.get("prj_id")}
        deltas = []

        for prj_id, uploaded in upload_map.items():
            if prj_id not in db_map:
                deltas.append({**uploaded, "delta_type": "NEW", "changed_fields": list(uploaded.keys())})
                continue
            changed = self._changed_fields(db_map[prj_id], uploaded)
            if changed:
                deltas.append({**uploaded, "delta_type": "UPDATED", "changed_fields": changed, "old_record": db_map[prj_id]})

        for prj_id, existing in db_map.items():
            if prj_id not in upload_map:
                deltas.append({**existing, "delta_type": "DELETED", "changed_fields": ["is_active"], "old_record": existing})
        return deltas

    def _changed_fields(self, old: dict, new: dict) -> list[str]:
        ignore = {"created_at", "updated_at", "created_by", "updated_by", "version_no", "is_active"}
        changed = []
        for k, new_value in new.items():
            if k in ignore:
                continue
            if self._norm(old.get(k)) != self._norm(new_value):
                changed.append(k)
        return changed

    def _norm(self, value):
        if value is None:
            return ""
        if isinstance(value, bool):
            return str(value).lower()
        return str(value).strip()
