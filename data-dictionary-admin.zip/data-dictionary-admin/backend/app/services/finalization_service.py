from uuid import uuid4
from sqlalchemy.orm import Session
from app.repositories.dictionary_repository import DictionaryRepository
from app.repositories.target_repository import TargetRepository
from app.services.audit_service import AuditService

class FinalizationService:
    def __init__(self):
        self.dictionary_repo = DictionaryRepository()
        self.target_repo = TargetRepository()
        self.audit = AuditService()

    def finalize_changes(self, db: Session, changes: list[dict], user_id: str, source_module: str):
        batch_id = uuid4()
        try:
            for change in changes:
                delta_type = change.get("delta_type")
                prj_id = change["prj_id"]
                existing = self.dictionary_repo.get_by_prj_id(db, prj_id)
                old_value = self.dictionary_repo.to_dict(existing)

                if delta_type == "NEW":
                    self.dictionary_repo.insert_master(db, change, user_id)
                    self.target_repo.insert_all(db, change, user_id)
                    action = "INSERT"
                    new_value = change
                elif delta_type == "UPDATED":
                    self.dictionary_repo.update_master(db, prj_id, change, user_id)
                    self.target_repo.insert_all(db, change, user_id)
                    action = "UPDATE"
                    new_value = change
                elif delta_type == "DELETED":
                    self.dictionary_repo.soft_delete_master(db, prj_id, user_id)
                    self.target_repo.soft_delete_all(db, prj_id, user_id)
                    action = "DELETE"
                    new_value = {"is_active": False}
                else:
                    continue

                self.audit.log_change(db, batch_id, prj_id, "ALL", action, old_value, new_value, user_id, source_module)
            db.commit()
            return {"status": "SUCCESS", "batch_id": str(batch_id), "records_processed": len(changes)}
        except Exception:
            db.rollback()
            raise
