from io import BytesIO
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from app.utils.excel_mapping import EXCEL_HEADER_ROW, EXCEL_DATA_START_ROW, EXCEL_TO_FIELD_MAPPING, MANDATORY_COLUMNS
from app.core.exceptions import BusinessValidationError

class ExcelService:
    def generate_template(self, records: list[dict], template_version: str) -> BytesIO:
        wb = Workbook()
        ws = wb.active
        ws.title = "Data Dictionary"
        ws["A1"] = "Data Dictionary Template"
        ws["B1"] = f"Version: {template_version}"
        ws["A2"] = "Header row is row 3. Data starts from row 4."
        headers = list(EXCEL_TO_FIELD_MAPPING.keys())
        for idx, h in enumerate(headers, 1):
            c = ws.cell(EXCEL_HEADER_ROW, idx, h)
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="1F4E78")
            c.alignment = Alignment(horizontal="center", vertical="center")
            ws.column_dimensions[c.column_letter].width = 28
        yes_no = DataValidation(type="list", formula1='"Yes,No,True,False,1,0"', allow_blank=True)
        ws.add_data_validation(yes_no)
        bool_headers = {"Editable?", "Required by corporates?", "Required by banks ?", "Required by insurance?", "Required by Downstream?", "Editable in Historicals", "Sign Flipping"}
        for row_idx, record in enumerate(records, EXCEL_DATA_START_ROW):
            for col_idx, header in enumerate(headers, 1):
                ws.cell(row_idx, col_idx, record.get(EXCEL_TO_FIELD_MAPPING[header]))
        for col_idx, header in enumerate(headers, 1):
            if header in bool_headers:
                yes_no.add(f"{ws.cell(EXCEL_DATA_START_ROW, col_idx).coordinate}:{ws.cell(5000, col_idx).coordinate}")
        out = BytesIO()
        wb.save(out)
        out.seek(0)
        return out

    def parse_uploaded_file(self, data: bytes) -> list[dict]:
        wb = load_workbook(BytesIO(data), data_only=True)
        ws = wb.active
        headers = [ws.cell(EXCEL_HEADER_ROW, col).value for col in range(1, ws.max_column + 1)]
        missing = [c for c in MANDATORY_COLUMNS if c not in headers]
        if missing:
            raise BusinessValidationError(f"Missing mandatory columns: {missing}")
        rows = []
        seen = set()
        for r in range(EXCEL_DATA_START_ROW, ws.max_row + 1):
            item = {}
            for col_idx, header in enumerate(headers, 1):
                field = EXCEL_TO_FIELD_MAPPING.get(header)
                if field:
                    item[field] = self._normalize(field, ws.cell(r, col_idx).value)
            if item.get("prj_id"):
                if item["prj_id"] in seen:
                    raise BusinessValidationError(f"Duplicate PRJ ID in upload: {item['prj_id']}")
                seen.add(item["prj_id"])
                rows.append(item)
        return rows

    def _normalize(self, field: str, value):
        bool_fields = {"editable", "required_by_corporates", "required_by_banks", "required_by_insurance", "required_by_downstream", "editable_in_historicals", "sign_flipping"}
        if field in bool_fields:
            if value is None or value == "":
                return None
            if str(value).strip().lower() in {"yes", "true", "1", "y"}:
                return True
            if str(value).strip().lower() in {"no", "false", "0", "n"}:
                return False
        return value
