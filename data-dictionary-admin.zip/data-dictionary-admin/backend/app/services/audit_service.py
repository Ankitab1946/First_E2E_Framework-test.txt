import json
from sqlalchemy.orm import Session
from app.models.audit import AuditLog

class AuditService:
    def log_change(self, db: Session, batch_id, prj_id: str, table_name: str, action_type: str, old_value, new_value, user_id: str, source_module: str):
        db.add(AuditLog(
            batch_id=str(batch_id),
            prj_id=prj_id,
            table_name=table_name,
            action_type=action_type,
            source_module=source_module,
            old_value=json.dumps(old_value, default=str) if old_value is not None else None,
            new_value=json.dumps(new_value, default=str) if new_value is not None else None,
            changed_by=user_id,
        ))
        db.flush()
