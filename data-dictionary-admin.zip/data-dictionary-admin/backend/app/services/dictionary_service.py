from sqlalchemy.orm import Session
from app.repositories.dictionary_repository import DictionaryRepository

class DictionaryService:
    def __init__(self):
        self.repo = DictionaryRepository()

    def get_latest_records_as_dict(self, db: Session):
        return [self.repo.to_dict(x) for x in self.repo.get_latest(db)]

    def get_all_records_as_dict(self, db: Session):
        return [self.repo.to_dict(x) for x in self.repo.get_all(db)]
