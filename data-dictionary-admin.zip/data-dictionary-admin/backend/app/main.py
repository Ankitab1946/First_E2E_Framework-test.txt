from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.exceptions import BusinessValidationError, business_validation_exception_handler
from app.routers.dictionary_router import router as dictionary_router

app = FastAPI(title=settings.app_name, debug=settings.app_debug, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_exception_handler(BusinessValidationError, business_validation_exception_handler)

@app.get(f"{settings.api_prefix}/health")
def health():
    return {"status": "UP", "environment": settings.app_env, "service": settings.app_name}

app.include_router(dictionary_router, prefix=settings.api_prefix)
