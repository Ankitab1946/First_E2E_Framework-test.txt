from app.services.delta_service import DeltaService

def test_detect_new_record():
    result = DeltaService().compare(
        [{"prj_id": "P1", "prj_attribute_name": "Revenue"}],
        [{"prj_id": "P1", "prj_attribute_name": "Revenue"}, {"prj_id": "P2", "prj_attribute_name": "EBITDA"}],
    )
    assert len(result) == 1
    assert result[0]["delta_type"] == "NEW"


def test_detect_updated_record():
    result = DeltaService().compare(
        [{"prj_id": "P1", "prj_attribute_name": "Revenue"}],
        [{"prj_id": "P1", "prj_attribute_name": "Total Revenue"}],
    )
    assert len(result) == 1
    assert result[0]["delta_type"] == "UPDATED"
    assert "prj_attribute_name" in result[0]["changed_fields"]


def test_detect_deleted_record():
    result = DeltaService().compare(
        [{"prj_id": "P1", "prj_attribute_name": "Revenue"}],
        [],
    )
    assert len(result) == 1
    assert result[0]["delta_type"] == "DELETED"
