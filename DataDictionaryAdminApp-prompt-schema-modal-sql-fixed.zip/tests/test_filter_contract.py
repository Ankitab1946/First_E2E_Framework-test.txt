from DataDictionaryAdminApp.api.schemas_api import FilterRequest
def test_multi_portfolio_filter_contract():
    assert FilterRequest(portfolios=['FI Banks','FI Insurance']).portfolios == ['FI Banks','FI Insurance']
