import pandas as pd
from DataDictionaryAdminApp.service.excel_service import ExcelService


def test_attribute_name_header_with_suffix_is_mapped():
    source = pd.DataFrame({
        'PRJID': ['P100'],
        'Attribute Name (to be Viewed on Historical and HITL)': ['Total Debt'],
        'Description (Proposed one-shot prompt)': ['Prompt text'],
    })
    result, mapping = ExcelService.normalise_prompt_columns(source)
    assert mapping['attribute_name'] == 'Attribute Name (to be Viewed on Historical and HITL)'
    assert result.iloc[0]['attribute_name'] == 'Total Debt'


def test_attribute_name_is_preferred_over_legacy_prj_attribute():
    source = pd.DataFrame({
        'PRJID': ['P101'],
        'PRJ Attribute': ['Wrong legacy value'],
        'Attribute Name any suffix': ['Correct value'],
    })
    result, _ = ExcelService.normalise_prompt_columns(source)
    assert result.iloc[0]['attribute_name'] == 'Correct value'
