from DataDictionaryAdminApp.api.swagger_app import app

def test_expected_route_groups_are_registered():
    paths={route.path for route in app.routes}
    expected={
        '/api/v1/data-dictionary/filter',
        '/api/v1/master-upload/preview',
        '/api/v1/prompts',
        '/api/v1/prompt-upload/sheets',
        '/api/v1/portfolio-reference',
        '/api/v1/lookups/sections',
        '/api/v1/audit',
        '/api/v1/history/attributes/{prj_id}',
        '/api/v1/s3/export',
        '/api/v1/admin/access',
    }
    assert expected.issubset(paths)
