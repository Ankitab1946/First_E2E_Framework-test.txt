from DataDictionaryAdminApp.utils.normalizers import physical_name
def test_physical_name(): assert physical_name('Land & Buildings (Gross)') == 'land_buildings_gross'
