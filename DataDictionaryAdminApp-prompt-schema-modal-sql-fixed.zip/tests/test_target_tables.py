from DataDictionaryAdminApp.core.target_tables import APPLICATION_TABLES, S3_EXPORTS

def test_only_approved_application_tables_are_registered():
    assert APPLICATION_TABLES == (
        'prj_attribute_master_test',
        'prj_portfolio_reference_test',
        'prj_attribute_portfolio_scope_test',
        'prj_attribute_business_rules_test',
        'prj_scanning_prompt_reference_test',
        'audit_table_test',
    )
    assert set(table for _, table in S3_EXPORTS).issubset(set(APPLICATION_TABLES))
    assert len(S3_EXPORTS) == 6
