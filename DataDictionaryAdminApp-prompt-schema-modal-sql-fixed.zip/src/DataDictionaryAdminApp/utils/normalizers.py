import re

def physical_name(value: str) -> str:
    tokens = re.sub(r"[^a-zA-Z0-9]+", "_", value.strip().lower()).strip("_")
    return tokens[:500] or "attribute"
