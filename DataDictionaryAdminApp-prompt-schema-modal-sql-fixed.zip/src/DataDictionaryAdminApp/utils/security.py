import getpass

def current_user(value: str | None = None) -> str:
    return value or getpass.getuser() or "sysuser"


def is_admin_role(role: str | None) -> bool:
    return (role or 'Admin').strip().lower() == 'admin'
