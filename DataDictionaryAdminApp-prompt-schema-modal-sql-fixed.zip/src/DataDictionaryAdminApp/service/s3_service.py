from __future__ import annotations

from datetime import datetime, timezone
from io import BytesIO

import boto3
import pandas as pd
from botocore.config import Config

from DataDictionaryAdminApp.config import get_settings
from DataDictionaryAdminApp.core.target_tables import S3_EXPORTS


class S3Service:
    def __init__(self):
        settings = get_settings()
        if not settings.effective_s3_bucket_name:
            raise ValueError("S3_BUCKET_NAME or BUCKET_NAME must be configured before export.")
        if not settings.effective_s3_endpoint_url:
            raise ValueError("S3 endpoint is missing. Set S3_ENDPOINT_URL, S3_HOST, or HOST.")
        self.bucket = settings.effective_s3_bucket_name
        self.prefix = settings.s3_prefix.strip("/")
        self.client = boto3.client(
            "s3",
            aws_access_key_id=settings.effective_s3_access_key_id,
            aws_secret_access_key=settings.effective_s3_secret_key,
            region_name=settings.aws_region,
            use_ssl=settings.s3_use_ssl,
            verify=settings.s3_verify_ssl,
            endpoint_url=settings.effective_s3_endpoint_url,
            config=Config(s3={"addressing_style": settings.s3_addressing_style}),
        )

    def export_frames(self, frames: dict[str, pd.DataFrame]) -> list[str]:
        invalid_tables = sorted(set(frames).difference(name for name, _ in S3_EXPORTS))
        if invalid_tables:
            raise ValueError(f"S3 export contains unsupported table(s): {', '.join(invalid_tables)}")
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_UTC")
        keys: list[str] = []
        for name, frame in frames.items():
            stream = BytesIO()
            frame.to_excel(stream, index=False, engine="openpyxl")
            key = f"{self.prefix}/{stamp}/{name}_{stamp}.xlsx"
            self.client.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=stream.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
            keys.append(key)
        return keys
