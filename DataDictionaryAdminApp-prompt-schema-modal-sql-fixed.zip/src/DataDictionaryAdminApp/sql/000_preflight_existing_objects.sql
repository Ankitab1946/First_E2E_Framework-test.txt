/* Review only the six application-managed tables before bootstrap. */
SELECT
    s.name AS schema_name,
    o.name AS object_name,
    o.type_desc,
    o.create_date,
    o.modify_date
FROM sys.objects o
INNER JOIN sys.schemas s ON s.schema_id = o.schema_id
WHERE s.name = N'dbo'
  AND o.name IN (
    N'prj_attribute_master_test',
    N'prj_portfolio_reference_test',
    N'prj_attribute_portfolio_scope_test',
    N'prj_attribute_business_rules_test',
    N'prj_scanning_prompt_reference_test',
    N'audit_table_test'
  )
ORDER BY o.name;

SELECT
    fk.name AS foreign_key_name,
    OBJECT_NAME(fk.parent_object_id) AS parent_table,
    OBJECT_NAME(fk.referenced_object_id) AS referenced_table
FROM sys.foreign_keys fk
WHERE OBJECT_NAME(fk.parent_object_id) IN (
    N'prj_attribute_master_test',
    N'prj_portfolio_reference_test',
    N'prj_attribute_portfolio_scope_test',
    N'prj_attribute_business_rules_test',
    N'prj_scanning_prompt_reference_test',
    N'audit_table_test'
)
OR OBJECT_NAME(fk.referenced_object_id) IN (
    N'prj_attribute_master_test',
    N'prj_portfolio_reference_test',
    N'prj_attribute_portfolio_scope_test',
    N'prj_attribute_business_rules_test',
    N'prj_scanning_prompt_reference_test',
    N'audit_table_test'
)
ORDER BY parent_table, foreign_key_name;
