/* Run this in the database selected by the Streamlit sidebar. It reports missing final-schema objects/columns. */
DECLARE @required TABLE (table_name sysname, column_name sysname);
INSERT @required VALUES
('prj_attribute_master_test','prj_id'),('prj_attribute_master_test','prj_attribute_name'),('prj_attribute_master_test','is_active'),('prj_attribute_master_test','where_in_financial_statement'),
('prj_portfolio_reference_test','port_ref_id'),('prj_portfolio_reference_test','port_name'),('prj_portfolio_reference_test','is_active'),
('prj_attribute_portfolio_scope_test','scope_id'),('prj_attribute_portfolio_scope_test','prj_id'),('prj_attribute_portfolio_scope_test','port_ref_id'),('prj_attribute_portfolio_scope_test','is_active'),
('prj_attribute_business_rules_test','id'),('prj_attribute_business_rules_test','scope_id'),('prj_attribute_business_rules_test','source_abbr_name'),('prj_attribute_business_rules_test','is_active'),
('prj_scanning_prompt_reference_test','prompt_id'),('prj_scanning_prompt_reference_test','prj_id'),('prj_scanning_prompt_reference_test','is_active'),
('audit_table_test','audit_id'),('audit_table_test','table_name'),('audit_table_test','record_key'),('audit_table_test','action');

SELECT r.table_name, r.column_name,
       CASE WHEN c.column_id IS NULL THEN 'MISSING' ELSE 'OK' END AS status
FROM @required r
LEFT JOIN sys.tables t ON t.name=r.table_name AND t.schema_id=SCHEMA_ID('dbo')
LEFT JOIN sys.columns c ON c.object_id=t.object_id AND c.name=r.column_name
ORDER BY r.table_name, r.column_name;

SELECT DB_NAME() AS connected_database, @@SERVERNAME AS connected_server;
