from fastapi import FastAPI
from DataDictionaryAdminApp.api.routers import (
    data_dictionary, audit, system, lookups, prompts, master_upload, prompt_upload,
    portfolio_reference, history, s3, admin,
)

app=FastAPI(
    title='Data Dictionary Admin API',
    version='2.1.0',
    description=(
        'API-first administration for the six approved Data Dictionary tables. '
        'Route groups are separated for master data, prompt data, uploads, audit/history, '
        'portfolio reference, S3 exports and administration.'
    ),
)
for router in (data_dictionary.router, master_upload.router, prompts.router, prompt_upload.router,
               portfolio_reference.router, lookups.router, audit.router, history.router,
               s3.router, admin.router, system.router):
    app.include_router(router,prefix='/api/v1')

@app.get('/health', tags=['System'])
def health():
    return {'status': 'UP', 'api_version': app.version, 'api_base_path': '/api/v1'}


@app.get('/api/v1/health', tags=['System'])
def v1_health():
    return {'status': 'UP', 'api_version': app.version, 'api_base_path': '/api/v1'}


@app.get('/api/v1', tags=['System'])
def api_root():
    return {
        'status': 'UP',
        'api_version': app.version,
        'swagger': '/docs',
        'environment_endpoint': '/api/v1/system/environment',
        'route_groups': [
            'data-dictionary', 'master-upload', 'prompts', 'prompt-upload',
            'portfolio-reference', 'lookups', 'audit', 'history', 's3', 'admin', 'system',
        ],
    }
