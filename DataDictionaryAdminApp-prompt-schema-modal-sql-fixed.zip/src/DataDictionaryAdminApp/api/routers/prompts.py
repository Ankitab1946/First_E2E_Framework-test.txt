from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.api.schemas_api import PromptUpsert
from DataDictionaryAdminApp.model.entities import ScanningPromptReference
from DataDictionaryAdminApp.service.data_dictionary_service import DataDictionaryService
from DataDictionaryAdminApp.utils.security import current_user

router = APIRouter(prefix='/prompts', tags=['Prompts'])
def serial(row): return {c.name:getattr(row,c.name) for c in row.__table__.columns}

@router.get('')
def list_prompts(prj_id:str|None=None, include_deleted:bool=False, db:Session=Depends(get_db)):
    stmt=select(ScanningPromptReference)
    if not include_deleted: stmt=stmt.where(ScanningPromptReference.is_active.is_(True))
    if prj_id: stmt=stmt.where(ScanningPromptReference.prj_id.ilike(f'%{prj_id}%'))
    return [serial(x) for x in db.scalars(stmt.order_by(ScanningPromptReference.prompt_id)).all()]

@router.post('')
def create_prompt(payload:PromptUpsert,user:str|None=Query(None),db:Session=Depends(get_db)):
    try: return serial(DataDictionaryService(db).upsert_prompt(payload,current_user(user),source='UI'))
    except ValueError as e: raise HTTPException(400,str(e))

@router.put('/{prompt_id}')
def update_prompt(prompt_id:int,payload:PromptUpsert,user:str|None=Query(None),db:Session=Depends(get_db)):
    try: return serial(DataDictionaryService(db).upsert_prompt(payload,current_user(user),prompt_id,source='UI'))
    except ValueError as e: raise HTTPException(400,str(e))

@router.delete('/{prompt_id}')
def delete_prompt(prompt_id:int,user:str|None=Query(None),db:Session=Depends(get_db)):
    if not DataDictionaryService(db).soft_delete_prompt(prompt_id,current_user(user)): raise HTTPException(404,'Prompt not found')
    return {'status':'soft_deleted','prompt_id':prompt_id}

@router.post('/{prompt_id}/reactivate')
def reactivate_prompt(prompt_id:int,user:str|None=Query(None),db:Session=Depends(get_db)):
    row=db.get(ScanningPromptReference,prompt_id)
    if not row: raise HTTPException(404,'Prompt not found')
    row.is_active=True; row.updated_by=current_user(user); db.commit()
    return serial(row)
