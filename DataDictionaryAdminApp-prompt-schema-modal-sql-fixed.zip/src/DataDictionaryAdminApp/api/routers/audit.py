from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.model.entities import AuditTable

router=APIRouter(prefix='/audit',tags=['Audit History'])

@router.get('')
def get_audit(table_name:str|None=None,record_key:str|None=None,action:str|None=None,performed_by:str|None=None,source_operation:str|None=None,db:Session=Depends(get_db)):
    stmt=select(AuditTable).order_by(AuditTable.performed_at.desc())
    if table_name: stmt=stmt.where(AuditTable.table_name.ilike(f'%{table_name}%'))
    if record_key: stmt=stmt.where(AuditTable.record_key.ilike(f'%{record_key}%'))
    if action: stmt=stmt.where(AuditTable.action==action)
    if performed_by: stmt=stmt.where(AuditTable.performed_by.ilike(f'%{performed_by}%'))
    if source_operation: stmt=stmt.where(AuditTable.source_operation.ilike(f'%{source_operation}%'))
    rows=db.scalars(stmt).all()
    return [{c.name:getattr(x,c.name) for c in x.__table__.columns} for x in rows]
