from fastapi import APIRouter, Query
from DataDictionaryAdminApp.config import get_settings
from DataDictionaryAdminApp.utils.security import current_user
router=APIRouter(prefix='/admin',tags=['Administration'])
@router.get('/access')
def access(user:str|None=Query(None)):
    name=current_user(user); settings=get_settings(); admins={x.strip().lower() for x in settings.admin_users.split(',') if x.strip()}
    return {'user':name,'is_admin': '*' in admins or name.lower() in admins,'admin_users_configured':bool(admins)}
