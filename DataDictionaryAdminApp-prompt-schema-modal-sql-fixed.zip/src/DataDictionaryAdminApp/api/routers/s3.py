from fastapi import APIRouter, Depends, HTTPException, Query, Header
from sqlalchemy import select
from sqlalchemy.orm import Session
import pandas as pd
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.model.entities import AttributeMaster, PortfolioReference, AttributePortfolioScope, AttributeBusinessRule, ScanningPromptReference
from DataDictionaryAdminApp.service.s3_service import S3Service
from DataDictionaryAdminApp.repositories.data_dictionary_repository import DataDictionaryRepository
from DataDictionaryAdminApp.utils.security import current_user, is_admin_role

router=APIRouter(prefix='/s3',tags=['S3 Export'])

def frame(db, model):
    return pd.DataFrame([{c.name:getattr(x,c.name) for c in x.__table__.columns} for x in db.scalars(select(model)).all()])

@router.post('/export')
def export_all(user:str|None=Query(None),db:Session=Depends(get_db),x_app_role: str | None = Header(None)):
    if not is_admin_role(x_app_role): raise HTTPException(403, 'Admin role is required for S3 export.')
    try:
        master = frame(db, AttributeMaster)
        payload = {
            'master_dictionary': master,
            'prj_attribute_master_test': master,
            'prj_portfolio_reference_test': frame(db, PortfolioReference),
            'prj_attribute_portfolio_scope_test': frame(db, AttributePortfolioScope),
            'prj_attribute_business_rules_test': frame(db, AttributeBusinessRule),
            'prj_scanning_prompt_reference_test': frame(db, ScanningPromptReference),
        }
        keys=S3Service().export_frames(payload)
        DataDictionaryRepository(db).audit('audit_table_test','S3_EXPORT','S3_EXPORT',None,{'keys':keys},current_user(user),'S3_EXPORT')
        db.commit()
        return {'status':'exported','file_count':len(keys),'keys':keys}
    except Exception as e:
        raise HTTPException(400,str(e))
