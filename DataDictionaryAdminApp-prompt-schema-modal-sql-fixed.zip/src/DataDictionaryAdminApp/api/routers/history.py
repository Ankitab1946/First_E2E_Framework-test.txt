from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from DataDictionaryAdminApp.core.database import get_db
from DataDictionaryAdminApp.model.entities import AuditTable
router=APIRouter(prefix='/history',tags=['History'])

def serialize(x): return {c.name:getattr(x,c.name) for c in x.__table__.columns}
@router.get('/attributes/{prj_id}')
def attribute_history(prj_id:str,db:Session=Depends(get_db)):
    return [serialize(x) for x in db.scalars(select(AuditTable).where(AuditTable.record_key==prj_id).order_by(AuditTable.performed_at.desc())).all()]
@router.get('/prompts/{prompt_id}')
def prompt_history(prompt_id:int,db:Session=Depends(get_db)):
    return [serialize(x) for x in db.scalars(select(AuditTable).where(AuditTable.record_key==str(prompt_id)).order_by(AuditTable.performed_at.desc())).all()]
