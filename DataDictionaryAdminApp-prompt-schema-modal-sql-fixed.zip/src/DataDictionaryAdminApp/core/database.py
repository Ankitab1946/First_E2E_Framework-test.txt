"""Environment-aware SQL Server session factory."""
from __future__ import annotations

from functools import lru_cache
from urllib.parse import quote_plus

from fastapi import HTTPException, Request
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from DataDictionaryAdminApp.config import get_settings


class Base(DeclarativeBase):
    pass


@lru_cache(maxsize=8)
def _session_factory(environment: str):
    settings = get_settings()
    cfg = settings.database_config(environment)
    if not cfg["enabled"]:
        raise RuntimeError(f"Database access is disabled for environment {cfg['environment']}.")
    engine = create_engine(
        f"mssql+pyodbc:///?odbc_connect={quote_plus(settings.connection_string(cfg['environment']))}",
        future=True,
        pool_pre_ping=True,
    )
    return sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db(request: Request):
    settings = get_settings()
    environment = request.headers.get("X-App-Environment") or request.query_params.get("environment")
    selected = settings.resolve_environment(environment)
    try:
        session_local = _session_factory(selected)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    db = session_local()
    try:
        yield db
    finally:
        db.close()
