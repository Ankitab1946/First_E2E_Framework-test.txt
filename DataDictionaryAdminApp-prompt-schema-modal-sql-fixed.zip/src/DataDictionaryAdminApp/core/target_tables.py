"""Authoritative list of the only application-managed SQL Server tables."""

ATTRIBUTE_MASTER = "prj_attribute_master_test"
PORTFOLIO_REFERENCE = "prj_portfolio_reference_test"
ATTRIBUTE_PORTFOLIO_SCOPE = "prj_attribute_portfolio_scope_test"
ATTRIBUTE_BUSINESS_RULES = "prj_attribute_business_rules_test"
SCANNING_PROMPT_REFERENCE = "prj_scanning_prompt_reference_test"
AUDIT = "audit_table_test"

APPLICATION_TABLES: tuple[str, ...] = (
    ATTRIBUTE_MASTER, PORTFOLIO_REFERENCE, ATTRIBUTE_PORTFOLIO_SCOPE,
    ATTRIBUTE_BUSINESS_RULES, SCANNING_PROMPT_REFERENCE, AUDIT,
)

# Six requested timestamped S3 extracts. The first is a business-friendly Master Dictionary projection;
# the remaining five are the physical application-table extracts excluding audit history.
S3_EXPORTS: tuple[tuple[str, str], ...] = (
    ("master_dictionary", ATTRIBUTE_MASTER),
    ("prj_attribute_master_test", ATTRIBUTE_MASTER),
    ("prj_portfolio_reference_test", PORTFOLIO_REFERENCE),
    ("prj_attribute_portfolio_scope_test", ATTRIBUTE_PORTFOLIO_SCOPE),
    ("prj_attribute_business_rules_test", ATTRIBUTE_BUSINESS_RULES),
    ("prj_scanning_prompt_reference_test", SCANNING_PROMPT_REFERENCE),
)

# Backward-compatible validation tuple. It contains only approved physical table names.
S3_EXPORT_TABLES: tuple[str, ...] = tuple(dict.fromkeys(table for _, table in S3_EXPORTS))
