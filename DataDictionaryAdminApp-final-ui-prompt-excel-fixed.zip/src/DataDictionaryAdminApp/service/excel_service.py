from io import BytesIO
from datetime import datetime
import re
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation


class ExcelService:
    master_columns = [
        'PRJ ID','PRJ Attribute Name','PRJ Attribute Description','PRJ Physical Attribute Name','Editable?',
        'Calculated or Reported?','Percentage(%) / Ratio(X)','Calculation Logic',
        'Where in financial statement is this generally collected from ?','Required by corporates?',
        'Required by banks ?','Required by insurance?','Required by Downstream?','Version Update',
        'Mapping Type (calculated/CAPIQ sourced/Manual Updates/Out of Scope)','Calculated in CFV? (Y/N)',
        'Editable in Historicals screen in UCRS-CFV?(Y/N)','Sign Flipping (multiply by)',
        'GC Template attribute name','S&P Standradisation dataitem id','S&P As-Reported dataitem ID / logic',
        'Calculation Logic Details','Updates','Updated ON','Zeus attribute','Zeus table name','Zeus Description',
        'Commnets','SNL dataitemid','Scanned/Calculated'
    ]

    @staticmethod
    def _identifier(value) -> str:
        return ''.join(ch for ch in str(value).replace('\xa0', ' ').lower() if ch.isalnum())

    def sheets(self, content):
        return pd.ExcelFile(BytesIO(content)).sheet_names

    def read_prompt_workbook(self, content, sheet_name):
        """Find the actual header row without confusing data columns such as CFVID.

        The preferred header row must contain a PRJ ID-like header and an explicit
        Attribute Name header. If no such row exists, choose the strongest PRJ-ID row
        and normalisation reports the detected headers clearly.
        """
        raw = pd.read_excel(BytesIO(content), sheet_name=sheet_name, header=None, nrows=200)
        best = None
        fallback = None
        for idx, row in raw.iterrows():
            values = [self._identifier(v) for v in row.tolist() if pd.notna(v) and str(v).strip()]
            has_prj = any(v in {'prjid','prjid'} or v.startswith('prjid') or v.startswith('projectid') or v == 'cfvid' for v in values)
            # Attribute Name must really be an Attribute Name header; CFVID is never valid.
            has_attribute_name = any(v.startswith('attributename') or v.startswith('prjattributename') for v in values)
            has_prj_attribute = any(v.startswith('prjattribute') for v in values)
            has_description = any(v.startswith('description') for v in values)
            score = (10 if has_prj else 0) + (20 if has_attribute_name else 0) + (8 if has_prj_attribute else 0) + (3 if has_description else 0)
            if has_prj and (has_attribute_name or has_prj_attribute) and (best is None or score > best[1]):
                best = (int(idx), score)
            if has_prj and (fallback is None or score > fallback[1]):
                fallback = (int(idx), score)
        header_row = best[0] if best else (fallback[0] if fallback else 0)
        return pd.read_excel(BytesIO(content), sheet_name=sheet_name, header=header_row)

    @staticmethod
    def normalise_prompt_columns(df):
        df = df.copy()
        df.columns = [str(c).replace('\xa0', ' ').strip() for c in df.columns]
        indexed = [(column, ExcelService._identifier(column)) for column in df.columns]

        def first(predicate):
            for col, ident in indexed:
                if predicate(ident):
                    return col
            return None

        # Explicit requirement: any header starting with 'Attribute Name' wins.
        # Only if absent, accept PRJ Attribute/PRJ Attribute Name as legacy fallbacks.
        attr_col = first(lambda v: v.startswith('attributename'))
        if not attr_col:
            attr_col = first(lambda v: v.startswith('prjattributename'))
        if not attr_col:
            attr_col = first(lambda v: v.startswith('prjattribute') and v not in {'prjid', 'prj_id'})

        prj_col = first(lambda v: v == 'prjid' or v.startswith('prjid') or v.startswith('projectid') or v == 'cfvid')
        mapping = {
            'prj_id': prj_col,
            'attribute_name': attr_col,
            'attribute_description': first(lambda v: v.startswith('description')),
            'section': first(lambda v: v == 'section' or v.startswith('section')),
            'sub_section': first(lambda v: v.startswith('subsection')),
            'data_type': first(lambda v: v.startswith('datatype')),
            'calculated_or_reported': first(lambda v: v.startswith('calculatedorreported')),
            'calculation_logic': first(lambda v: v.startswith('calculationlogic')),
            'segment': first(lambda v: v.startswith('segment')),
            'display_order': first(lambda v: v.startswith('displayorder')),
            'examples': first(lambda v: v.startswith('examples')),
        }
        if not mapping['prj_id']:
            raise ValueError('Prompt worksheet is missing required column PRJID/PRJ ID. Detected headers: ' + ', '.join(map(str, df.columns)))
        if not mapping['attribute_name']:
            raise ValueError('Prompt worksheet is missing an Attribute Name column. Use a column whose name starts with Attribute Name, or a legacy PRJ Attribute column. Detected headers: ' + ', '.join(map(str, df.columns)))

        output = pd.DataFrame()
        for target, column in mapping.items():
            output[target] = df[column] if column else None
        output['prj_id'] = output['prj_id'].astype(str).str.strip()
        output = output[(output['prj_id'] != '') & (output['prj_id'].str.lower() != 'nan')]
        return output, mapping

    @staticmethod
    def _format_master_sheet(ws):
        blue = PatternFill(fill_type='solid', fgColor='1F4E78')
        white_bold = Font(color='FFFFFF', bold=True)
        for cell in ws[3]:
            cell.fill = blue
            cell.font = white_bold
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        ws.freeze_panes = 'A4'
        ws.auto_filter.ref = f'A3:{ws.cell(row=max(ws.max_row, 3), column=ws.max_column).coordinate}'
        ws.row_dimensions[3].height = 32
        for column_cells in ws.columns:
            letter = column_cells[0].column_letter
            max_len = max((len(str(c.value or '')) for c in column_cells[:250]), default=12)
            ws.column_dimensions[letter].width = min(max(max_len + 2, 14), 42)

    def build_latest_dicts(self, rows):
        wb = Workbook(); ws = wb.active; ws.title = 'PRJ Data Dictionary Mapping'
        ws['A1'] = 'Data Dictionary Export'
        ws['A2'] = f'Generated: {datetime.utcnow().isoformat()}Z'
        ws.append(self.master_columns)
        for r in rows:
            ws.append([
                r.get('prj_id'), r.get('prj_attribute_name'), r.get('prj_attribute_description'),
                r.get('prj_physical_attribute_name'), r.get('editable'), r.get('calculated_or_reported'),
                r.get('percent_ratio') or r.get('symbol'), r.get('calculation_logic'),
                r.get('where_in_financial_statement'), r.get('required_by_corporates'), r.get('required_by_banks'),
                r.get('required_by_insurance'), r.get('required_by_zeus_downstream'), r.get('version_update'),
                r.get('mapping_type'), r.get('calculated_in_cfv'), r.get('editable_in_historicals'),
                r.get('sign_flipping_value'), None, r.get('sp_standardisation_dataitem_id'),
                r.get('sp_as_reported_dataitem_logic'), r.get('calculation_logic_details'), None, None, None,
                None, None, None, None, None
            ])
        self._format_master_sheet(ws)
        validation = DataValidation(type='list', formula1='"Y,N"', allow_blank=True)
        ws.add_data_validation(validation); validation.add('E4:E1048576'); validation.add('J4:M1048576')
        out = BytesIO(); wb.save(out); return out.getvalue()

    def build_latest(self, rows):
        return self.build_latest_dicts([{c.name: getattr(r, c.name) for c in r.__table__.columns} for r in rows])

    def read_master_workbook(self, content):
        return pd.read_excel(BytesIO(content), sheet_name='PRJ Data Dictionary Mapping', header=2)
