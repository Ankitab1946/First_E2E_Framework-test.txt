import getpass

def current_user(value: str | None = None) -> str:
    return value or getpass.getuser() or "sysuser"
