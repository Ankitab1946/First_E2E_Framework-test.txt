from fastapi import APIRouter, UploadFile, File, HTTPException
from DataDictionaryAdminApp.service.excel_service import ExcelService

router=APIRouter(prefix='/master-upload',tags=['Master Dictionary Upload'])

@router.post('/preview')
async def preview_master(file:UploadFile=File(...)):
    try:
        df=ExcelService().read_master_workbook(await file.read())
        return {'sheet':'PRJ Data Dictionary Mapping','row_count':len(df),'columns':[str(c) for c in df.columns],'preview':df.head(50).where(df.notna(),None).to_dict(orient='records')}
    except Exception as e: raise HTTPException(400,f'Unable to parse Master Dictionary workbook: {e}')

@router.post('/delta')
async def delta_master(file:UploadFile=File(...)):
    # Contract endpoint; persistence is deliberately performed only after explicit Finalize.
    data=await file.read(); df=ExcelService().read_master_workbook(data)
    return {'status':'preview_ready','new':len(df),'updated':0,'soft_delete_candidates':0,'message':'Use /master-upload/finalize after the business mapping is approved.'}

@router.post('/finalize')
def finalize_master():
    raise HTTPException(501,'Master workbook finalization requires the approved Excel-to-entity mapping and is not enabled in this base package.')
