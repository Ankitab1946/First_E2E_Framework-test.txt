/*
 Data Dictionary Admin App - idempotent SQL Server schema bootstrap AND reconciliation.
 It creates the six approved application tables and adds missing final-schema columns
 when an earlier version of an approved table already exists. It never drops data.
 prj_data_source is a pre-existing static reference table and is not created here.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    /* Create the final six tables when absent. */
    IF OBJECT_ID(N'dbo.prj_attribute_master_test', N'U') IS NULL
    CREATE TABLE dbo.prj_attribute_master_test (
        prj_id varchar(80) NOT NULL PRIMARY KEY,
        prj_attribute_name varchar(500) NOT NULL,
        prj_attribute_description nvarchar(max) NULL,
        prj_physical_attribute_name varchar(500) NULL,
        where_in_financial_statement varchar(255) NULL,
        version_update varchar(255) NULL,
        calculated_or_reported varchar(100) NULL,
        calculation_logic nvarchar(max) NULL,
        calculation_logic_details nvarchar(max) NULL,
        sign_flipping_value varchar(50) NULL,
        mapping_type varchar(255) NULL,
        sp_standardisation_dataitem_id varchar(255) NULL,
        sp_as_reported_dataitem_logic nvarchar(max) NULL,
        calculated_in_cfv varchar(5) NULL,
        editable_in_historicals varchar(5) NULL,
        is_active bit NOT NULL DEFAULT(1),
        created_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        updated_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        created_by varchar(128) NOT NULL DEFAULT('sysuser'),
        updated_by varchar(128) NOT NULL DEFAULT('sysuser')
    );

    IF OBJECT_ID(N'dbo.prj_portfolio_reference_test', N'U') IS NULL
    CREATE TABLE dbo.prj_portfolio_reference_test (
        port_ref_id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        port_name varchar(120) NOT NULL,
        sector_name varchar(120) NULL,
        sub_sector varchar(120) NULL,
        remark varchar(500) NULL,
        is_active bit NOT NULL DEFAULT(1),
        created_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        updated_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        created_by varchar(128) NOT NULL DEFAULT('sysuser'),
        updated_by varchar(128) NOT NULL DEFAULT('sysuser')
    );

    IF OBJECT_ID(N'dbo.prj_attribute_portfolio_scope_test', N'U') IS NULL
    CREATE TABLE dbo.prj_attribute_portfolio_scope_test (
        scope_id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        prj_id varchar(80) NOT NULL,
        port_ref_id int NOT NULL,
        description nvarchar(max) NULL,
        is_active bit NOT NULL DEFAULT(1),
        created_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        updated_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        created_by varchar(128) NOT NULL DEFAULT('sysuser'),
        updated_by varchar(128) NOT NULL DEFAULT('sysuser')
    );

    IF OBJECT_ID(N'dbo.prj_attribute_business_rules_test', N'U') IS NULL
    CREATE TABLE dbo.prj_attribute_business_rules_test (
        id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        scope_id int NOT NULL,
        source_abbr_name varchar(50) NOT NULL DEFAULT('SNPAR'),
        editable varchar(20) NULL,
        symbol varchar(50) NULL,
        mapping_type varchar(255) NULL,
        mapping_logic nvarchar(max) NULL,
        calculation_logic nvarchar(max) NULL,
        business_logic nvarchar(max) NULL,
        is_active bit NOT NULL DEFAULT(1),
        created_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        updated_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        created_by varchar(128) NOT NULL DEFAULT('sysuser'),
        updated_by varchar(128) NOT NULL DEFAULT('sysuser')
    );

    IF OBJECT_ID(N'dbo.prj_scanning_prompt_reference_test', N'U') IS NULL
    CREATE TABLE dbo.prj_scanning_prompt_reference_test (
        prompt_id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        scope_id int NULL,
        prj_id varchar(80) NOT NULL,
        port_ref_id int NULL,
        required_by_scope varchar(255) NULL,
        attribute_name varchar(500) NULL,
        section varchar(255) NULL,
        sub_section varchar(255) NULL,
        data_type varchar(100) NULL,
        calculated_or_reported varchar(100) NULL,
        calculation_logic nvarchar(max) NULL,
        segment varchar(255) NULL,
        attribute_description nvarchar(max) NULL,
        examples nvarchar(max) NULL,
        display_order int NULL,
        is_active bit NOT NULL DEFAULT(1),
        created_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        updated_at datetime2 NOT NULL DEFAULT(sysutcdatetime()),
        created_by varchar(128) NOT NULL DEFAULT('sysuser'),
        updated_by varchar(128) NOT NULL DEFAULT('sysuser')
    );

    IF OBJECT_ID(N'dbo.audit_table_test', N'U') IS NULL
    CREATE TABLE dbo.audit_table_test (
        audit_id bigint IDENTITY(1,1) NOT NULL PRIMARY KEY,
        table_name varchar(255) NOT NULL,
        record_key varchar(255) NOT NULL,
        action varchar(50) NOT NULL,
        before_value nvarchar(max) NULL,
        after_value nvarchar(max) NULL,
        source_operation varchar(100) NULL,
        batch_reference varchar(255) NULL,
        performed_by varchar(128) NOT NULL,
        performed_at datetime2 NOT NULL DEFAULT(sysutcdatetime())
    );

    /* Reconcile columns for tables that existed before this version. */
    IF COL_LENGTH('dbo.prj_attribute_master_test','prj_id') IS NULL OR COL_LENGTH('dbo.prj_attribute_master_test','prj_attribute_name') IS NULL
        THROW 51001, 'prj_attribute_master_test exists but does not contain required columns prj_id and prj_attribute_name. Rename/migrate the legacy columns before running the application.', 1;

    IF COL_LENGTH('dbo.prj_attribute_master_test','prj_attribute_description') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD prj_attribute_description nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','prj_physical_attribute_name') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD prj_physical_attribute_name varchar(500) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','where_in_financial_statement') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD where_in_financial_statement varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','version_update') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD version_update varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','calculated_or_reported') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD calculated_or_reported varchar(100) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','calculation_logic') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD calculation_logic nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','calculation_logic_details') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD calculation_logic_details nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','sign_flipping_value') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD sign_flipping_value varchar(50) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','mapping_type') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD mapping_type varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','sp_standardisation_dataitem_id') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD sp_standardisation_dataitem_id varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','sp_as_reported_dataitem_logic') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD sp_as_reported_dataitem_logic nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','calculated_in_cfv') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD calculated_in_cfv varchar(5) NULL;
    IF COL_LENGTH('dbo.prj_attribute_master_test','editable_in_historicals') IS NULL ALTER TABLE dbo.prj_attribute_master_test ADD editable_in_historicals varchar(5) NULL;

    /* Common audit columns. Defaults backfill existing records safely. */
    DECLARE @tbl sysname, @sql nvarchar(max);
    DECLARE table_cursor CURSOR LOCAL FAST_FORWARD FOR
    SELECT name FROM sys.tables WHERE schema_id = SCHEMA_ID('dbo') AND name IN (
      'prj_attribute_master_test','prj_portfolio_reference_test','prj_attribute_portfolio_scope_test',
      'prj_attribute_business_rules_test','prj_scanning_prompt_reference_test'
    );
    OPEN table_cursor; FETCH NEXT FROM table_cursor INTO @tbl;
    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF COL_LENGTH('dbo.' + @tbl,'is_active') IS NULL EXEC(N'ALTER TABLE dbo.' + QUOTENAME(@tbl) + N' ADD is_active bit NOT NULL CONSTRAINT DF_ddam_' + @tbl + N'_active DEFAULT(1) WITH VALUES;');
      IF COL_LENGTH('dbo.' + @tbl,'created_at') IS NULL EXEC(N'ALTER TABLE dbo.' + QUOTENAME(@tbl) + N' ADD created_at datetime2 NOT NULL CONSTRAINT DF_ddam_' + @tbl + N'_created DEFAULT(sysutcdatetime()) WITH VALUES;');
      IF COL_LENGTH('dbo.' + @tbl,'updated_at') IS NULL EXEC(N'ALTER TABLE dbo.' + QUOTENAME(@tbl) + N' ADD updated_at datetime2 NOT NULL CONSTRAINT DF_ddam_' + @tbl + N'_updated DEFAULT(sysutcdatetime()) WITH VALUES;');
      IF COL_LENGTH('dbo.' + @tbl,'created_by') IS NULL EXEC(N'ALTER TABLE dbo.' + QUOTENAME(@tbl) + N' ADD created_by varchar(128) NOT NULL CONSTRAINT DF_ddam_' + @tbl + N'_created_by DEFAULT(''sysuser'') WITH VALUES;');
      IF COL_LENGTH('dbo.' + @tbl,'updated_by') IS NULL EXEC(N'ALTER TABLE dbo.' + QUOTENAME(@tbl) + N' ADD updated_by varchar(128) NOT NULL CONSTRAINT DF_ddam_' + @tbl + N'_updated_by DEFAULT(''sysuser'') WITH VALUES;');
      FETCH NEXT FROM table_cursor INTO @tbl;
    END
    CLOSE table_cursor; DEALLOCATE table_cursor;

    /* Reconcile non-audit columns for the remaining approved tables. */
    IF COL_LENGTH('dbo.prj_portfolio_reference_test','port_ref_id') IS NULL OR COL_LENGTH('dbo.prj_portfolio_reference_test','port_name') IS NULL
        THROW 51002, 'prj_portfolio_reference_test exists but does not contain required columns port_ref_id and port_name.', 1;
    IF COL_LENGTH('dbo.prj_portfolio_reference_test','sector_name') IS NULL ALTER TABLE dbo.prj_portfolio_reference_test ADD sector_name varchar(120) NULL;
    IF COL_LENGTH('dbo.prj_portfolio_reference_test','sub_sector') IS NULL ALTER TABLE dbo.prj_portfolio_reference_test ADD sub_sector varchar(120) NULL;
    IF COL_LENGTH('dbo.prj_portfolio_reference_test','remark') IS NULL ALTER TABLE dbo.prj_portfolio_reference_test ADD remark varchar(500) NULL;

    IF COL_LENGTH('dbo.prj_attribute_portfolio_scope_test','scope_id') IS NULL OR COL_LENGTH('dbo.prj_attribute_portfolio_scope_test','prj_id') IS NULL OR COL_LENGTH('dbo.prj_attribute_portfolio_scope_test','port_ref_id') IS NULL
        THROW 51003, 'prj_attribute_portfolio_scope_test exists but does not contain required columns scope_id, prj_id and port_ref_id.', 1;
    IF COL_LENGTH('dbo.prj_attribute_portfolio_scope_test','description') IS NULL ALTER TABLE dbo.prj_attribute_portfolio_scope_test ADD description nvarchar(max) NULL;

    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','id') IS NULL OR COL_LENGTH('dbo.prj_attribute_business_rules_test','scope_id') IS NULL
        THROW 51004, 'prj_attribute_business_rules_test exists but does not contain required columns id and scope_id.', 1;
    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','source_abbr_name') IS NULL ALTER TABLE dbo.prj_attribute_business_rules_test ADD source_abbr_name varchar(50) NOT NULL CONSTRAINT DF_ddam_business_source DEFAULT('SNPAR') WITH VALUES;
    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','editable') IS NULL ALTER TABLE dbo.prj_attribute_business_rules_test ADD editable varchar(20) NULL;
    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','symbol') IS NULL ALTER TABLE dbo.prj_attribute_business_rules_test ADD symbol varchar(50) NULL;
    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','mapping_type') IS NULL ALTER TABLE dbo.prj_attribute_business_rules_test ADD mapping_type varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','mapping_logic') IS NULL ALTER TABLE dbo.prj_attribute_business_rules_test ADD mapping_logic nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','calculation_logic') IS NULL ALTER TABLE dbo.prj_attribute_business_rules_test ADD calculation_logic nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_attribute_business_rules_test','business_logic') IS NULL ALTER TABLE dbo.prj_attribute_business_rules_test ADD business_logic nvarchar(max) NULL;

    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','prompt_id') IS NULL OR COL_LENGTH('dbo.prj_scanning_prompt_reference_test','prj_id') IS NULL
        THROW 51005, 'prj_scanning_prompt_reference_test exists but does not contain required columns prompt_id and prj_id.', 1;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','scope_id') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD scope_id int NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','port_ref_id') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD port_ref_id int NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','required_by_scope') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD required_by_scope varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','attribute_name') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD attribute_name varchar(500) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','section') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD section varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','sub_section') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD sub_section varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','data_type') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD data_type varchar(100) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','calculated_or_reported') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD calculated_or_reported varchar(100) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','calculation_logic') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD calculation_logic nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','segment') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD segment varchar(255) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','attribute_description') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD attribute_description nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','examples') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD examples nvarchar(max) NULL;
    IF COL_LENGTH('dbo.prj_scanning_prompt_reference_test','display_order') IS NULL ALTER TABLE dbo.prj_scanning_prompt_reference_test ADD display_order int NULL;

    /* Constraints and indexes are created only when missing. */
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.prj_portfolio_reference_test') AND name=N'UX_ddam_portfolio_reference_key')
      CREATE UNIQUE INDEX UX_ddam_portfolio_reference_key ON dbo.prj_portfolio_reference_test(port_name,sector_name,sub_sector);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.prj_attribute_master_test') AND name=N'UX_ddam_attribute_physical_name')
      CREATE UNIQUE INDEX UX_ddam_attribute_physical_name ON dbo.prj_attribute_master_test(prj_physical_attribute_name) WHERE prj_physical_attribute_name IS NOT NULL;
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.prj_attribute_portfolio_scope_test') AND name=N'UX_ddam_attribute_scope_prj_port')
      CREATE UNIQUE INDEX UX_ddam_attribute_scope_prj_port ON dbo.prj_attribute_portfolio_scope_test(prj_id,port_ref_id);
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.prj_attribute_business_rules_test') AND name=N'UX_ddam_business_rules_scope')
      CREATE UNIQUE INDEX UX_ddam_business_rules_scope ON dbo.prj_attribute_business_rules_test(scope_id);

    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_test WHERE port_name='FI' AND sector_name='Banks' AND ISNULL(sub_sector,'')='')
      INSERT dbo.prj_portfolio_reference_test(port_name,sector_name,sub_sector,remark) VALUES('FI','Banks',NULL,'Financial Institutes - Banks');
    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_test WHERE port_name='FI' AND sector_name='Insurance' AND ISNULL(sub_sector,'')='')
      INSERT dbo.prj_portfolio_reference_test(port_name,sector_name,sub_sector,remark) VALUES('FI','Insurance',NULL,'Financial Institutes - Insurance');
    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_test WHERE port_name='Corporate' AND sector_name='Corporate' AND ISNULL(sub_sector,'')='')
      INSERT dbo.prj_portfolio_reference_test(port_name,sector_name,sub_sector,remark) VALUES('Corporate','Corporate',NULL,'Global Corporates');
    IF NOT EXISTS (SELECT 1 FROM dbo.prj_portfolio_reference_test WHERE port_name='Zeus Downstream' AND sector_name='Zeus Downstream' AND ISNULL(sub_sector,'')='')
      INSERT dbo.prj_portfolio_reference_test(port_name,sector_name,sub_sector,remark) VALUES('Zeus Downstream','Zeus Downstream',NULL,'Zeus Downstream');

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
