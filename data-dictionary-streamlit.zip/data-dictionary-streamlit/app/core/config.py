from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "Data Dictionary Streamlit Admin"
    app_env: str = "local"
    app_debug: bool = False

    sqlserver_host: str = "localhost"
    sqlserver_port: int = 1433
    sqlserver_database: str = "DataDictionaryDB"
    sqlserver_user: str = "sa"
    sqlserver_password: str = "YourStrongPassword123!"
    sqlserver_driver: str = "ODBC Driver 18 for SQL Server"
    sqlserver_trust_cert: str = "yes"

    excel_template_version: str = "1.0"
    max_upload_size_mb: int = 20
    default_user: str = "sysuser"
    enable_db: bool = False

    @property
    def database_url(self) -> str:
        driver = self.sqlserver_driver.replace(" ", "+")
        return (
            f"mssql+pyodbc://{self.sqlserver_user}:{self.sqlserver_password}"
            f"@{self.sqlserver_host}:{self.sqlserver_port}/{self.sqlserver_database}"
            f"?driver={driver}&TrustServerCertificate={self.sqlserver_trust_cert}"
        )

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()
