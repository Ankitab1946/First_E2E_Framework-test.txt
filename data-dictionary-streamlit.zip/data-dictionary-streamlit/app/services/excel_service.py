from io import BytesIO
from typing import Any
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from app.utils.excel_mapping import (
    BOOLEAN_FIELDS,
    EXCEL_DATA_START_ROW,
    EXCEL_HEADER_ROW,
    EXCEL_TO_FIELD_MAPPING,
    FIELD_TO_EXCEL_MAPPING,
    MANDATORY_COLUMNS,
    MASTER_FIELDS,
)


class ExcelService:
    def generate_template(self, records: list[dict[str, Any]], template_version: str = "1.0") -> BytesIO:
        wb = Workbook()
        ws = wb.active
        ws.title = "Data Dictionary"
        ws["A1"] = "Data Dictionary Template"
        ws["A2"] = f"Template Version: {template_version}"
        headers = list(EXCEL_TO_FIELD_MAPPING.keys())

        for col_index, header in enumerate(headers, start=1):
            cell = ws.cell(row=EXCEL_HEADER_ROW, column=col_index)
            cell.value = header
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1F4E78")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            ws.column_dimensions[cell.column_letter].width = 28

        yes_no_validation = DataValidation(type="list", formula1='"Yes,No,True,False,1,0"', allow_blank=True)
        ws.add_data_validation(yes_no_validation)

        for row_index, record in enumerate(records, start=EXCEL_DATA_START_ROW):
            for col_index, header in enumerate(headers, start=1):
                field = EXCEL_TO_FIELD_MAPPING[header]
                value = record.get(field)
                if field in BOOLEAN_FIELDS and value is not None:
                    value = "Yes" if bool(value) else "No"
                ws.cell(row=row_index, column=col_index).value = value

        for col_index, header in enumerate(headers, start=1):
            field = EXCEL_TO_FIELD_MAPPING[header]
            if field in BOOLEAN_FIELDS:
                yes_no_validation.add(f"{ws.cell(row=EXCEL_DATA_START_ROW, column=col_index).coordinate}:{ws.cell(row=5000, column=col_index).coordinate}")

        ws.freeze_panes = "A4"
        stream = BytesIO()
        wb.save(stream)
        stream.seek(0)
        return stream

    def parse_uploaded_file(self, file_bytes: bytes) -> list[dict[str, Any]]:
        wb = load_workbook(BytesIO(file_bytes), data_only=True)
        ws = wb.active
        headers = [ws.cell(row=EXCEL_HEADER_ROW, column=col).value for col in range(1, ws.max_column + 1)]
        self.validate_headers(headers)
        rows: list[dict[str, Any]] = []
        seen: set[str] = set()
        for row_num in range(EXCEL_DATA_START_ROW, ws.max_row + 1):
            record: dict[str, Any] = {}
            for col_index, header in enumerate(headers, start=1):
                if not header or header not in EXCEL_TO_FIELD_MAPPING:
                    continue
                field = EXCEL_TO_FIELD_MAPPING[header]
                record[field] = self._normalize_value(field, ws.cell(row=row_num, column=col_index).value)
            prj_id = str(record.get("prj_id") or "").strip()
            if not prj_id:
                continue
            if prj_id in seen:
                raise ValueError(f"Duplicate PRJ ID in upload: {prj_id}")
            seen.add(prj_id)
            for field in MASTER_FIELDS:
                record.setdefault(field, None)
            rows.append(record)
        return rows

    def validate_headers(self, headers: list[str | None]) -> None:
        missing = [c for c in MANDATORY_COLUMNS if c not in headers]
        if missing:
            raise ValueError(f"Missing mandatory columns: {', '.join(missing)}")

    @staticmethod
    def _normalize_value(field_name: str, value: Any) -> Any:
        if field_name in BOOLEAN_FIELDS:
            if value is None or str(value).strip() == "":
                return None
            normalized = str(value).strip().lower()
            if normalized in {"yes", "true", "1", "y"}:
                return True
            if normalized in {"no", "false", "0", "n"}:
                return False
        return value

    @staticmethod
    def to_excel_columns(records: list[dict[str, Any]]):
        return [{FIELD_TO_EXCEL_MAPPING.get(k, k): v for k, v in record.items() if k in FIELD_TO_EXCEL_MAPPING} for record in records]
