# Performance Tuning and Large Workbook Uploads

## Expected behaviour

The application now uses:

- pooled SQL Server connections;
- a 120-second read timeout and 600-second upload/write timeout;
- bounded database commits of 100 rows by default;
- one transaction commit per batch rather than one commit per Excel row;
- SQL Server performance indexes for active attributes, scopes, rules, prompts and audit history.

For a typical 788-row Master Dictionary upload, the target is normally a few minutes rather than 30 minutes. Actual duration depends on SQL Server network latency, Windows/Kerberos authentication, available SQL Server capacity, audit-table growth, and how many portfolio scopes are selected per row.

## One-time database step

Run this after `001_create_tables.sql` against every application database:

```sql
src/DataDictionaryAdminApp/sql/004_add_performance_indexes.sql
```

## Runtime configuration

Use these `.env` values as a safe initial production configuration:

```env
BULK_UPLOAD_BATCH_SIZE=100
SQLALCHEMY_POOL_SIZE=10
SQLALCHEMY_MAX_OVERFLOW=20
SQLALCHEMY_POOL_TIMEOUT_SECONDS=30
SQLALCHEMY_POOL_RECYCLE_SECONDS=1800
SQLSERVER_CONNECT_TIMEOUT_SECONDS=30
API_READ_TIMEOUT_SECONDS=120
API_WRITE_TIMEOUT_SECONDS=600
```

If the database has low capacity or high lock contention, reduce `BULK_UPLOAD_BATCH_SIZE` to `50`. Do not set it above `500` without load testing.

## Operational notes

- Run the API and Streamlit services from the same release version.
- Avoid running multiple Master Dictionary finalizations against the same environment at once.
- Use the Master Upload finalization response to inspect rejected rows. Valid batches continue even when individual rows are rejected.
- For internal-cloud deployment, scale the API deployment after confirming SQL Server can support the additional concurrent connection load.
