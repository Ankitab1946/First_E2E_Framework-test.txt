# Business Rule tab fix

Run `infra/DataDictionaryAdminApp/sql/05_fix_business_rules_soft_delete.sql` against `PRJ_DB`.

This resolves the `Invalid column name 'deleted_at'` error caused by an older `prj_attribute_business_rules_test` table lacking the soft-delete columns used by the application.
