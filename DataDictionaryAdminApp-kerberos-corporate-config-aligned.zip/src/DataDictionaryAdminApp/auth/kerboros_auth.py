"""Kerboros authentication support for SQL Server Integrated Authentication.

This module configures MIT Kerberos paths, obtains a ticket from a keytab when
required, and exposes SQL Server ODBC connection parameters.  It deliberately
contains no credentials.  In Docker/Internal Cloud, mount ``krb5.conf`` and the
keytab as secrets; the default relative paths keep both files together in the
project ``krb5/`` directory for local/container testing.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import threading
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Optional

from DataDictionaryAdminApp.config import Settings, get_settings

logger = logging.getLogger(__name__)
_LOCK = threading.Lock()
_LAST_RESULT: dict[str, Any] = {"attempted": False, "ok": False, "message": "Not initialized"}


class KerborosAuthManager:
    """Configure and validate Kerberos before SQL Server connections are opened.

    Configuration is read through the corporate-style paths ``config.api`` and
    ``config.kerboros``.  The underlying ``Settings`` object remains backward
    compatible with the existing environment-specific configuration.
    """

    def __init__(self, config: Optional[Settings] = None, environment: Optional[str] = None) -> None:
        self.config = config or get_settings()
        self.environment = self.config.resolve_environment(environment)
        self.api = self.config.api_for(self.environment)
        self.kerboros = self.config.kerboros_for(self.environment)
        self.krb5_config_path: Optional[str] = None
        self.krb5_ktname_path: Optional[str] = None

    def setup_environment(self) -> bool:
        """Set KRB5_CONFIG/KRB5_KTNAME/KRB5_REALM without acquiring a ticket."""
        if not self.kerboros.use_kerberos:
            logger.debug("Kerberos authentication is disabled")
            return False

        try:
            krb5_config_path = self._resolve_path(self.kerboros.config)
            if not krb5_config_path or not os.path.isfile(krb5_config_path):
                logger.warning("krb5 configuration file not found: %s", self.kerboros.config)
                return False

            keytab_path = self._resolve_path(self.kerboros.ktname)
            if not keytab_path or not os.path.isfile(keytab_path):
                logger.warning("Kerberos keytab file not found: %s", self.kerboros.ktname)
                return False

            os.environ["KRB5_CONFIG"] = krb5_config_path
            os.environ["KRB5_KTNAME"] = keytab_path
            os.environ["KRB5CCNAME"] = self.kerboros.credential_cache
            if self.kerboros.realm:
                os.environ["KRB5_REALM"] = self.kerboros.realm

            self.krb5_config_path = krb5_config_path
            self.krb5_ktname_path = keytab_path
            logger.info("Kerberos environment configured. krb5.conf=%s keytab=%s", krb5_config_path, keytab_path)
            return True
        except Exception as exc:  # pragma: no cover - defensive diagnostics
            logger.exception("Failed to configure Kerberos environment")
            _set_last_result(False, f"Kerberos environment setup failed: {exc}")
            return False

    def _resolve_path(self, path: str) -> str:
        if not path:
            return ""
        candidate = Path(path).expanduser()
        if candidate.is_absolute():
            return str(candidate)

        # Prefer repository root, then process working directory.  This supports
        # local Poetry execution and Docker where /app is the repository root.
        project_root = Path(__file__).resolve().parents[3]
        root_candidate = project_root / candidate
        if root_candidate.exists():
            return str(root_candidate.resolve())
        cwd_candidate = Path.cwd() / candidate
        if cwd_candidate.exists():
            return str(cwd_candidate.resolve())
        return str(root_candidate)

    def ensure_ticket(self, force: bool = False) -> None:
        """Run kinit using the configured keytab once per process."""
        global _LAST_RESULT
        if not self.kerboros.use_kerberos:
            return

        with _LOCK:
            if _LAST_RESULT.get("ok") and not force:
                return
            if not self.kerboros.principal:
                raise RuntimeError("KERBEROS_PRINCIPAL is required when Kerberos is enabled.")
            if not self.setup_environment():
                raise RuntimeError("Kerberos paths are invalid. Check config.kerboros.config and config.kerboros.ktname.")
            if not shutil.which("kinit"):
                raise RuntimeError("kinit is not installed in the runtime image. Use the supplied Dockerfile.")

            try:
                completed = subprocess.run(
                    ["kinit", "-kt", self.krb5_ktname_path or "", self.kerboros.principal],
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=self.kerboros.kinit_timeout_seconds,
                    env=os.environ.copy(),
                )
            except subprocess.TimeoutExpired as exc:
                _set_last_result(False, "kinit timed out. Check KDC reachability, DNS and network policy.")
                raise RuntimeError(_LAST_RESULT["message"]) from exc

            if completed.returncode != 0:
                message = (completed.stderr or completed.stdout or "kinit failed").strip()
                _set_last_result(False, message[:500])
                raise RuntimeError(f"Kerberos kinit failed: {message}")

            _set_last_result(True, "Kerberos ticket acquired")
            logger.info("Kerberos ticket acquired for principal %s", self.kerboros.principal)

    def get_connection_params(self) -> dict[str, str]:
        """Return ODBC parameter names/values using config.api compatibility fields."""
        params: dict[str, str] = {
            "DRIVER": f"{{{self.api.db_driver}}}",
            "SERVER": self.api.db_server,
            "DATABASE": self.api.db_database,
            "Encrypt": "no",
        }
        if self.api.db_integrated_security or self.kerboros.use_kerberos:
            params["Trusted_Connection"] = "yes"
            if self.kerboros.server_spn:
                params["ServerSPN"] = self.kerboros.server_spn
            logger.debug("Using integrated security / Kerberos for SQL Server")
        else:
            params["UID"] = self.api.db_username
            params["PWD"] = self.api.db_password
            logger.debug("Using SQL username/password authentication")
        if self.api.db_trust_certificate:
            params["TrustServerCertificate"] = "yes"
        return params

    def build_odbc_connection_string(self) -> str:
        return ";".join(f"{key}={value}" for key, value in self.get_connection_params().items()) + ";"


def _set_last_result(ok: bool, message: str) -> None:
    global _LAST_RESULT
    _LAST_RESULT = {"attempted": True, "ok": ok, "message": message, "at": datetime.now(UTC).isoformat()}


_kerberos_manager: Optional[KerborosAuthManager] = None


def get_kerberos_manager(settings: Optional[Settings] = None, environment: Optional[str] = None) -> KerborosAuthManager:
    global _kerberos_manager
    target = (settings or get_settings()).resolve_environment(environment)
    if _kerberos_manager is None or _kerberos_manager.environment != target:
        _kerberos_manager = KerborosAuthManager(settings, target)
    return _kerberos_manager


def initialize_kerberos(settings: Optional[Settings] = None, environment: Optional[str] = None) -> bool:
    return get_kerberos_manager(settings, environment).setup_environment()


def ensure_kerberos_ticket(settings: Settings, environment: Optional[str] = None, *, force: bool = False) -> None:
    get_kerberos_manager(settings, environment).ensure_ticket(force=force)


def kerberos_status(settings: Settings, environment: Optional[str] = None) -> dict[str, Any]:
    manager = get_kerberos_manager(settings, environment)
    configured = manager.setup_environment() if manager.kerboros.use_kerberos else False
    result = {
        "enabled": manager.kerboros.use_kerberos,
        "environment": manager.environment,
        "principal_configured": bool(manager.kerboros.principal),
        "keytab_configured": bool(manager.kerboros.ktname),
        "keytab_exists": bool(manager.krb5_ktname_path and os.path.isfile(manager.krb5_ktname_path)),
        "krb5_conf_path": manager._resolve_path(manager.kerboros.config),
        "krb5_conf_exists": os.path.isfile(manager._resolve_path(manager.kerboros.config)),
        "credential_cache": manager.kerboros.credential_cache,
        "server_spn_configured": bool(manager.kerboros.server_spn),
        "environment_configured": configured,
        "last_result": _LAST_RESULT.copy(),
    }
    if manager.kerboros.use_kerberos and shutil.which("klist"):
        try:
            result["ticket_available"] = _run_klist(manager.kerboros.credential_cache)
        except Exception:
            result["ticket_available"] = False
    else:
        result["ticket_available"] = False
    return result


def _run_klist(cache: str) -> bool:
    env = os.environ.copy()
    env["KRB5CCNAME"] = cache
    return subprocess.run(["klist", "-s"], check=False, timeout=5, env=env).returncode == 0
