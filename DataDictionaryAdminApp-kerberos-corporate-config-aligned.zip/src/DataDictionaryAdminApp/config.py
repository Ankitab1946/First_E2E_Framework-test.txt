"""Central, environment-aware application configuration."""
from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

from pydantic_settings import BaseSettings, SettingsConfigDict


@dataclass(frozen=True)
class ApiConfigView:
    """Corporate compatibility path: config.api.<db_*>, resolved per environment."""
    db_driver: str
    db_server: str
    db_database: str
    db_integrated_security: bool
    db_username: str
    db_password: str
    db_trust_certificate: bool


@dataclass(frozen=True)
class KerborosConfigView:
    """Corporate compatibility path: config.kerboros.<setting>."""
    use_kerberos: bool
    config: str
    ktname: str
    realm: str
    principal: str
    credential_cache: str
    server_spn: str
    validate_on_startup: bool
    kinit_timeout_seconds: int


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    app_name: str = "Data Dictionary Streamlit Admin"
    app_env: str = "LOCAL"
    app_debug: bool = False
    api_base_url: str = "http://localhost:8503/api/v1"
    use_api_for_filters: bool = True
    app_environments: str = "LOCAL,DEV,UAT,PROD"
    selected_environment: str = "LOCAL"

    sqlserver_server: str = r"localhost\SQLEXPRESS"
    sqlserver_database: str = "PRJ_DB"
    sqlserver_windows_auth: bool = True
    sqlserver_user: str = ""
    sqlserver_password: str = ""
    sqlserver_driver: str = "ODBC Driver 17 for SQL Server"
    sqlserver_trust_cert: str = "yes"
    enable_db: bool = False

    admin_users: str = "*,sysuser"
    default_user: str = "sysuser"
    local_auto_admin: bool = True
    excel_template_version: str = "1.0"
    max_upload_size_mb: int = 20

    # Kerberos settings.  ``kerboros_*`` aliases keep the corporate configuration
    # path available as config.kerboros while retaining existing KERBEROS_* variables.
    kerberos_enabled: bool = False
    kerberos_principal: str = ""
    kerberos_keytab_path: str = "krb5/data_dictionary.keytab"
    kerberos_krb5_conf_path: str = "krb5/krb5.conf"
    kerberos_realm: str = ""
    kerberos_credential_cache: str = "FILE:/tmp/krb5cc_data_dictionary"
    kerberos_server_spn_value: str = ""
    kerberos_validate_on_startup: bool = True
    kerberos_kinit_timeout_seconds: int = 30

    # Performance controls. Safe defaults for SQL Server / internal cloud deployments.
    bulk_upload_batch_size: int = 100
    sqlalchemy_pool_size: int = 10
    sqlalchemy_max_overflow: int = 20
    sqlalchemy_pool_timeout_seconds: int = 30
    sqlalchemy_pool_recycle_seconds: int = 1800
    sqlalchemy_pool_pre_ping: bool = False
    data_dictionary_default_page_size: int = 200
    data_dictionary_max_page_size: int = 1000
    sqlserver_connect_timeout_seconds: int = 30
    api_read_timeout_seconds: int = 120
    api_write_timeout_seconds: int = 600

    s3_bucket_name: str = ""
    bucket_name: str = ""
    s3_prefix: str = "data-dictionary"
    aws_region: str = "ap-south-1"
    s3_host: str = ""
    host: str = ""
    s3_secure_host: str = ""
    secure_host: str = ""
    s3_port: str = ""
    s3_endpoint_url: str = ""
    s3_use_ssl: bool = False
    s3_verify_ssl: bool = False
    s3_addressing_style: str = "path"
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    access_key_id: str = ""
    secret_key: str = ""

    def available_environments(self) -> list[str]:
        return [item.strip().upper() for item in self.app_environments.split(",") if item.strip()]

    def resolve_environment(self, environment: str | None = None) -> str:
        candidate = (environment or self.selected_environment or self.app_env).upper()
        return candidate if candidate in self.available_environments() else self.app_env.upper()

    def _env_value(self, environment: str, suffix: str, default: Any) -> Any:
        value = os.getenv(f"ENV_{environment}_{suffix}")
        return default if value is None or value == "" else value

    @staticmethod
    def _as_bool(value: Any) -> bool:
        return str(value).strip().lower() in {"1", "true", "yes", "y", "on"}

    def database_config(self, environment: str | None = None) -> dict[str, Any]:
        env = self.resolve_environment(environment)
        return {
            "environment": env,
            "server": self._env_value(env, "SQLSERVER_SERVER", self.sqlserver_server),
            "database": self._env_value(env, "SQLSERVER_DATABASE", self.sqlserver_database),
            "windows_auth": self._as_bool(self._env_value(env, "SQLSERVER_WINDOWS_AUTH", self.sqlserver_windows_auth)),
            "user": self._env_value(env, "SQLSERVER_USER", self.sqlserver_user),
            "password": self._env_value(env, "SQLSERVER_PASSWORD", self.sqlserver_password),
            "driver": self._env_value(env, "SQLSERVER_DRIVER", self.sqlserver_driver),
            "trust_cert": self._env_value(env, "SQLSERVER_TRUST_CERT", self.sqlserver_trust_cert),
            "enabled": self._as_bool(self._env_value(env, "ENABLE_DB", self.enable_db)),
        }

    def _kerberos_value(self, environment: str, suffix: str, default: Any) -> Any:
        # ENV_<ENV>_KERBEROS_* takes precedence. KERBOROS_* is retained for existing deployments.
        value = os.getenv(f"ENV_{environment}_KERBEROS_{suffix}", os.getenv(f"KERBEROS_{suffix}", default))
        return default if value is None or value == "" else value

    def api_for(self, environment: str | None = None) -> ApiConfigView:
        cfg = self.database_config(environment)
        return ApiConfigView(
            db_driver=str(cfg["driver"]),
            db_server=str(cfg["server"]),
            db_database=str(cfg["database"]),
            db_integrated_security=bool(cfg["windows_auth"]),
            db_username=str(cfg["user"]),
            db_password=str(cfg["password"]),
            db_trust_certificate=self._as_bool(cfg["trust_cert"]),
        )

    def kerboros_for(self, environment: str | None = None) -> KerborosConfigView:
        env = self.resolve_environment(environment)
        cache = str(self._kerberos_value(env, "CREDENTIAL_CACHE", self.kerberos_credential_cache))
        if not cache.startswith(("FILE:", "KEYRING:")):
            cache = f"FILE:{cache}"
        return KerborosConfigView(
            use_kerberos=self._as_bool(self._kerberos_value(env, "ENABLED", self.kerberos_enabled)),
            config=str(self._kerberos_value(env, "KRB5_CONF_PATH", self.kerberos_krb5_conf_path)),
            ktname=str(self._kerberos_value(env, "KEYTAB_PATH", self.kerberos_keytab_path)),
            realm=str(self._kerberos_value(env, "REALM", self.kerberos_realm)),
            principal=str(self._kerberos_value(env, "PRINCIPAL", self.kerberos_principal)),
            credential_cache=cache,
            server_spn=str(self._kerberos_value(env, "SERVER_SPN", self.kerberos_server_spn_value)),
            validate_on_startup=self._as_bool(self._kerberos_value(env, "VALIDATE_ON_STARTUP", self.kerberos_validate_on_startup)),
            kinit_timeout_seconds=int(self._kerberos_value(env, "KINIT_TIMEOUT_SECONDS", self.kerberos_kinit_timeout_seconds)),
        )

    @property
    def api(self) -> ApiConfigView:
        return self.api_for()

    @property
    def kerboros(self) -> KerborosConfigView:
        return self.kerboros_for()

    def kerberos_server_spn(self, environment: str | None = None) -> str:
        return self.kerboros_for(environment).server_spn

    def connection_string(self, environment: str | None = None) -> str:
        cfg = self.database_config(environment)
        common = (
            f"DRIVER={{{cfg['driver']}}};SERVER={cfg['server']};DATABASE={cfg['database']};"
            f"Encrypt=no;TrustServerCertificate={cfg['trust_cert']};"
        )
        if cfg["windows_auth"]:
            server_spn = self.kerberos_server_spn(cfg["environment"])
            spn_part = f"ServerSPN={server_spn};" if server_spn else ""
            return common + "Trusted_Connection=yes;" + spn_part
        return common + f"UID={cfg['user']};PWD={cfg['password']};"

    @property
    def effective_s3_bucket_name(self) -> str:
        return self.s3_bucket_name or self.bucket_name

    @property
    def effective_s3_access_key_id(self) -> str:
        return self.aws_access_key_id or self.access_key_id

    @property
    def effective_s3_secret_key(self) -> str:
        return self.aws_secret_access_key or self.secret_key

    @property
    def effective_s3_endpoint_url(self) -> str:
        endpoint = self.s3_endpoint_url or self.s3_host or self.host
        if not endpoint and self.s3_secure_host:
            endpoint = self.s3_secure_host
        if not endpoint and self.secure_host:
            endpoint = self.secure_host
        if endpoint and self.s3_port and ":" not in endpoint.rsplit("/", 1)[-1]:
            endpoint = f"{endpoint.rstrip('/')}:{self.s3_port}"
        return endpoint

    def is_admin(self, username: str) -> bool:
        users = {value.strip().lower() for value in self.admin_users.split(",") if value.strip()}
        return "*" in users or username.lower() in users


@lru_cache
def get_settings() -> Settings:
    return Settings()
