# Kerberos runtime files

`krb5.conf` is a non-secret configuration template. The keytab is deliberately not included.

For local Docker/Internal Cloud testing, mount the secret keytab next to the configuration file:

```text
/app/krb5/krb5.conf
/app/krb5/data_dictionary.keytab
```

The defaults in `config.kerboros` are:

```text
config.kerboros.config = krb5/krb5.conf
config.kerboros.ktname = krb5/data_dictionary.keytab
```

Do not commit a `.keytab` file to source control.
