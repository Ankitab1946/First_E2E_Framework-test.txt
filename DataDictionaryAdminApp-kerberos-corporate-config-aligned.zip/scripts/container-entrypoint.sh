#!/bin/sh
set -eu

# Kerberos is opt-in.  krb5.conf and the keytab can be mounted together at /app/krb5
# (or supplied through explicit KERBEROS_* paths in the deployment environment).
if [ "${KERBEROS_ENABLED:-false}" = "true" ]; then
  : "${KERBEROS_PRINCIPAL:?KERBEROS_PRINCIPAL is required when KERBEROS_ENABLED=true}"
  : "${KERBEROS_KRB5_CONF_PATH:=/app/krb5/krb5.conf}"
  : "${KERBEROS_KEYTAB_PATH:=/app/krb5/data_dictionary.keytab}"
  : "${KERBEROS_CREDENTIAL_CACHE:=FILE:/tmp/krb5cc_data_dictionary}"

  if [ ! -r "${KERBEROS_KRB5_CONF_PATH}" ]; then
    echo "krb5.conf is not readable: ${KERBEROS_KRB5_CONF_PATH}" >&2
    exit 1
  fi
  if [ ! -r "${KERBEROS_KEYTAB_PATH}" ]; then
    echo "Kerberos keytab is not readable: ${KERBEROS_KEYTAB_PATH}" >&2
    exit 1
  fi

  export KRB5_CONFIG="${KERBEROS_KRB5_CONF_PATH}"
  export KRB5_KTNAME="${KERBEROS_KEYTAB_PATH}"
  export KRB5CCNAME="${KERBEROS_CREDENTIAL_CACHE}"
  if [ -n "${KERBEROS_REALM:-}" ]; then export KRB5_REALM="${KERBEROS_REALM}"; fi

  echo "Acquiring Kerberos ticket for ${KERBEROS_PRINCIPAL}..."
  kinit -kt "${KERBEROS_KEYTAB_PATH}" "${KERBEROS_PRINCIPAL}"
fi

exec "$@"
