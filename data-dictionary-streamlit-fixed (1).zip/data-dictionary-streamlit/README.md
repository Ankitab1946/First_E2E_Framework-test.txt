# Data Dictionary Management Admin - Python Streamlit Edition

This is a Python-only implementation of the Data Dictionary Management Admin App.

The application uses:

| Area | Technology |
|---|---|
| UI | Streamlit |
| Data processing | Pandas + openpyxl |
| Database | SQL Server |
| ORM | SQLAlchemy + pyodbc |
| Testing | Pytest + Allure |
| Deployment | Docker + Docker Compose |

## Features

- View latest data dictionary records
- Download formatted Excel template
- Edit records directly in Streamlit grid
- Upload Excel with row 3 header and row 4 onward data
- Validate Excel structure and mandatory columns
- Detect NEW / UPDATED / DELETED deltas
- Edit delta grid before finalization
- Finalize records into:
  - `master_dictionary`
  - `prj_attribute`
  - `prj_attr_business_logic`
  - `prj_attr_business_logic_scope`
- Audit every finalization batch
- Supports simulation mode for UI testing without DB
- Dockerized and deployment-ready

## Folder Structure

```text
app/
  core/                # config and database setup
  models/              # SQLAlchemy models
  repositories/        # DB access layer
  services/            # business logic, Excel, delta, finalization
  utils/               # mappings and sample data
sql/                   # SQL Server schema and seed scripts
tests/                 # pytest tests
streamlit_app.py       # Streamlit UI entry point
Dockerfile
docker-compose.yml
.env.example
```

## Run Locally Without Database

This is the fastest way to test the UI. It uses sample in-memory data and simulates final upload.

```bash
cd data-dictionary-streamlit
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env   # Windows
# cp .env.example .env   # macOS/Linux

streamlit run streamlit_app.py
```

Open:

```text
http://localhost:8501
```

In `.env`, keep:

```env
ENABLE_DB=false
```

## Run With SQL Server

1. Make sure database `PRJ_DB` already exists in SQL Server. The schema script will not create or drop the database.

2. Execute SQL scripts in this order using SSMS or Azure Data Studio:

```text
sql/01_schema.sql
sql/02_seed.sql
```

3. Update `.env` for Windows Authentication:

```env
ENABLE_DB=true
SQLSERVER_SERVER=localhost
SQLSERVER_DATABASE=PRJ_DB
SQLSERVER_WINDOWS_AUTH=true
SQLSERVER_DRIVER=ODBC Driver 17 for SQL Server
SQLSERVER_TRUST_CERT=yes
```

4. Run Streamlit:

```bash
streamlit run streamlit_app.py
```

## Run Full App With Docker Compose

```bash
copy .env.example .env   # Windows
# cp .env.example .env   # macOS/Linux

docker compose up --build
```

Open:

```text
http://localhost:8501
```

Note: Windows Authentication is intended for local Windows execution. If you run inside Docker, use SQL authentication or a domain-enabled container setup. For local Windows execution, install the matching Microsoft ODBC Driver and set `SQLSERVER_DRIVER` accordingly.

## Excel Template Rules

- Header row: row 3
- Data starts from: row 4
- Mandatory columns:
  - `PRJ ID`
  - `PRJ Attribute Name`
- Existing `PRJ ID` should not be changed
- New rows can use new `PRJ ID`

## Main Workflow

```text
View Latest
  ↓
Download Excel or Edit UI
  ↓
Upload and Compare / Stage UI Changes
  ↓
Review Delta Grid
  ↓
Finalize and Upload
  ↓
Update master + three target tables + audit log
```

## Run Tests

```bash
pytest
```

Generate Allure report:

```bash
pytest --alluredir=allure-results
allure serve allure-results
```

## Important Production Notes

- Add enterprise authentication before production deployment.
- Restrict DB permissions for the app service account.
- Move secrets to a vault for enterprise use.
- Add proper history tables if full rollback is required.
- Use server-side pagination if the master dictionary grows beyond several thousand rows.
- Streamlit is suitable for internal admin apps; for public/high-concurrency workflows, FastAPI + React remains more scalable.
