from functools import lru_cache
from sqlalchemy.engine import URL
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "Data Dictionary Streamlit Admin"
    app_env: str = "local"
    app_debug: bool = False

    # SQL Server configuration.
    # For Windows Authentication, set SQLSERVER_WINDOWS_AUTH=true.
    # Example server names:
    #   localhost
    #   localhost\\SQLEXPRESS
    #   YOUR_SERVER_NAME
    sqlserver_server: str = "localhost"
    sqlserver_database: str = "PRJ_DB"
    sqlserver_windows_auth: bool = True
    sqlserver_user: str = ""
    sqlserver_password: str = ""
    sqlserver_driver: str = "ODBC Driver 17 for SQL Server"
    sqlserver_trust_cert: str = "yes"

    excel_template_version: str = "1.0"
    max_upload_size_mb: int = 20
    default_user: str = "sysuser"
    enable_db: bool = False

    @property
    def database_url(self):
        query = {
            "driver": self.sqlserver_driver,
            "TrustServerCertificate": self.sqlserver_trust_cert,
        }

        if self.sqlserver_windows_auth:
            query["Trusted_Connection"] = "yes"
            return URL.create(
                "mssql+pyodbc",
                host=self.sqlserver_server,
                database=self.sqlserver_database,
                query=query,
            )

        return URL.create(
            "mssql+pyodbc",
            username=self.sqlserver_user,
            password=self.sqlserver_password,
            host=self.sqlserver_server,
            database=self.sqlserver_database,
            query=query,
        )

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()
