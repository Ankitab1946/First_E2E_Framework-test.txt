import os, json
import pandas as pd
import requests
import streamlit as st
from streamlit_modal import Modal

API=os.getenv('API_BASE_URL', os.getenv('STREAMLIT_API_BASE_URL','http://localhost:8502/api/v1'))
ENVIRONMENTS=[x.strip() for x in os.getenv('APP_ENVIRONMENTS','LOCAL,DEV,UAT,PROD').split(',') if x.strip()]
DEFAULT_ENV=os.getenv('SELECTED_ENVIRONMENT', os.getenv('APP_ENV','LOCAL'))
st.set_page_config(page_title='Data Dictionary Admin App',layout='wide')
st.title(os.getenv('APP_NAME', 'Data Dictionary Streamlit Admin'))
with st.sidebar:
    st.subheader('Connection')
    env=st.selectbox('Environment', ENVIRONMENTS, index=ENVIRONMENTS.index(DEFAULT_ENV) if DEFAULT_ENV in ENVIRONMENTS else 0)
    db_name=os.getenv(f'ENV_{env}_SQLSERVER_DATABASE', os.getenv('SQLSERVER_DATABASE','PRJ_DB'))
    db_server=os.getenv(f'ENV_{env}_SQLSERVER_SERVER', os.getenv('SQLSERVER_SERVER',''))
    st.caption(f'Database: {db_name}')
    st.caption(f'Server: {db_server}')
    user=st.text_input('Current User',value=os.getenv('USERNAME', os.getenv('DEFAULT_USER','sysuser')))
    st.button('Refresh',on_click=lambda:st.cache_data.clear())

def api(method,path,**kwargs):
    headers=kwargs.pop('headers', {})
    headers['X-App-Environment']=env
    res=requests.request(method,f'{API}{path}',timeout=45,headers=headers,**kwargs)
    if not res.ok: st.error(res.text); return None
    return res

tab1,tab2,tab3=st.tabs(['Data Dictionary','Prompt Management','Audit History'])
with tab1:
    c1,c2,c3=st.columns([4,2,2]); portfolios=c1.multiselect('Portfolio/Sector',['FI Banks','Corporates','FI Insurance','Zeus Downstream','ALL']); include_deleted=c2.checkbox('View soft deleted records'); overlap=c3.checkbox('Overlapped Attribute')
    filters={'portfolios':[] if 'ALL' in portfolios else portfolios,'overlapped_only':overlap,'include_deleted':include_deleted}
    data=api('POST','/data-dictionary/filter',json=filters)
    rows=data.json() if data else []
    st.dataframe(pd.DataFrame(rows),use_container_width=True,hide_index=True)
    x,y,z=st.columns(3)
    if x.button('Add New Attribute'):
        st.session_state['attribute_modal']='create'
    if y.button('Download Latest Data'):
        r=api('GET','/data-dictionary/download-latest')
        if r: st.download_button('Save Excel',r.content,'data_dictionary_latest.xlsx')
    if z.button('Edit selected PRJ ID'):
        st.info('Enter the PRJ ID in the editor below to open it in read-only mode, then click Edit.')
    modal=Modal('Create New Attribute' if st.session_state.get('attribute_modal')=='create' else 'Edit Attribute',key='attribute-modal')
    if st.session_state.get('attribute_modal')=='create': modal.open()
    if modal.is_open():
        with modal.container():
            with st.form('attribute-form'):
                prj=st.text_input('PRJ ID *'); name=st.text_input('Attribute Name *'); desc=st.text_area('Attribute Description'); section=st.selectbox('Where in financial statement',['Income Statement','Balance Sheet','Cash Flow','Ratios','Derivatives','Miscellaneous','Other'])
                ports=st.multiselect('Required By', ['FI Banks','Corporates','FI Insurance','Zeus Downstream']); source=st.text_input('Source Name',value='S&P CAPIQ AS REPORTED DATA'); editable=st.selectbox('Editable?',['Y','N']); symbol=st.text_input('Percentage / Ratio'); logic=st.text_area('Calculation Logic'); business=st.text_area('Business Logic')
                if st.form_submit_button('Create Attribute'):
                    p={'prj_id':prj,'prj_attribute_name':name,'prj_attribute_description':desc,'where_in_financial_statement':section,'required_portfolios':ports,'source_name':source,'editable':editable,'symbol':symbol,'calculation_logic':logic,'business_logic':business}
                    if api('POST',f'/data-dictionary/attributes?user={user}',json=p): st.success('Attribute created'); modal.close(); st.rerun()
with tab2:
    bulk,manual=st.tabs(['Bulk Upload','Edit/Insert Prompts'])
    with bulk:
        uploaded=st.file_uploader('Upload Prompt Excel',type=['xlsx'])
        if uploaded:
            st.info('The API supports sheet discovery. Select the sheet and use the preview as the controlled bulk-import checkpoint.')
            st.write(pd.ExcelFile(uploaded).sheet_names)
    with manual:
        with st.form('prompt-form'):
            prj=st.text_input('PRJ ID (read-only in edit mode) *'); attr=st.text_input('Attribute Name'); section=st.text_input('Section'); subsection=st.text_input('Sub-Section'); dtype=st.selectbox('DATA TYPE',['Amount','%','Ratio','Actual']); desc=st.text_area('Description'); display=st.number_input('Display Order',min_value=0,step=1)
            if st.form_submit_button('Save Prompt'):
                p={'prj_id':prj,'attribute_name':attr,'section':section,'sub_section':subsection,'data_type':dtype,'attribute_description':desc,'display_order':display}
                if api('POST',f'/data-dictionary/prompts?user={user}',json=p):st.success('Prompt saved')
with tab3:
    table=st.text_input('Table Name'); key=st.text_input('PRJ ID / Record Key')
    r=api('GET','/audit',params={'table_name':table or None,'record_key':key or None})
    if r:st.dataframe(pd.DataFrame(r.json()),use_container_width=True,hide_index=True)
