# Data Dictionary Admin App - Implementation TODO

## Phase 1: Scaffolding + Database
- [ ] Create monorepo folder structure
- [x] Add root documentation and environment templates
- [x] Add SQL Server schema scripts for master/audit/history/target tables
- [x] Add indexing and constraints scripts

## Phase 2: Backend (FastAPI)
- [ ] Create FastAPI app skeleton with three-tier layering
- [ ] Add configuration via .env (python-dotenv / pydantic-settings)
- [ ] Add SQLAlchemy models and repository layer
- [ ] Add services for CRUD/audit/history/delta/excel
- [ ] Add API routes and OpenAPI tags
- [ ] Add health endpoint and error handlers

## Phase 3: Frontend (React)
- [ ] Create React app scaffold
- [ ] Build shell layout with sidebar, environment selector, logged-in user
- [ ] Implement Data Dictionary tab with grid and actions
- [ ] Implement Audit History tab with filters
- [ ] Implement Prompts Library read-only tab
- [ ] Implement upload/download and delta visualization

## Phase 4: Testing + Allure
- [ ] Add backend unit tests (pytest)
- [ ] Add API tests (httpx + TestClient)
- [ ] Add mocks for repository/service isolation
- [ ] Add Allure integration and scripts

## Phase 5: Docker + Deployment
- [ ] Add backend Dockerfile
- [ ] Add frontend Dockerfile
- [ ] Add docker-compose.yml
- [ ] Add deployment runbook and CI/CD recommendation

## Final Documentation
- [ ] Architecture explanation
- [ ] API endpoint definitions
- [ ] Step-by-step implementation guide
- [ ] Best practices and recommendations
