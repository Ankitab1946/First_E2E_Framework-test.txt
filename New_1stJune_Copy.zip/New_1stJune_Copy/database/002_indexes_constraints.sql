-- =============================================
-- Indexes and Constraints
-- =============================================

-- Unique active PRJ + Attribute combination in master dictionary
IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'UX_master_dictionary_prj_attr_active'
      AND object_id = OBJECT_ID('dbo.master_dictionary')
)
BEGIN
    CREATE UNIQUE INDEX UX_master_dictionary_prj_attr_active
    ON dbo.master_dictionary (prj_id, prj_attribute_name, is_deleted)
    WHERE is_deleted = 0;
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_master_dictionary_portfolio_section'
      AND object_id = OBJECT_ID('dbo.master_dictionary')
)
BEGIN
    CREATE INDEX IX_master_dictionary_portfolio_section
    ON dbo.master_dictionary (portfolio_sector, where_in_financial_statement, is_active);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_master_dictionary_updated_at'
      AND object_id = OBJECT_ID('dbo.master_dictionary')
)
BEGIN
    CREATE INDEX IX_master_dictionary_updated_at
    ON dbo.master_dictionary (updated_at DESC);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_prj_attribute_prj_id'
      AND object_id = OBJECT_ID('dbo.prj_attribute')
)
BEGIN
    CREATE INDEX IX_prj_attribute_prj_id
    ON dbo.prj_attribute (prj_id, is_deleted);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_prj_attr_business_logic_prj_id'
      AND object_id = OBJECT_ID('dbo.prj_attr_business_logic')
)
BEGIN
    CREATE INDEX IX_prj_attr_business_logic_prj_id
    ON dbo.prj_attr_business_logic (prj_id, is_deleted);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_prj_attr_business_logic_scope_prj_id'
      AND object_id = OBJECT_ID('dbo.prj_attr_business_logic_scope')
)
BEGIN
    CREATE INDEX IX_prj_attr_business_logic_scope_prj_id
    ON dbo.prj_attr_business_logic_scope (prj_id, is_deleted);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_audit_log_lookup'
      AND object_id = OBJECT_ID('dbo.audit_log')
)
BEGIN
    CREATE INDEX IX_audit_log_lookup
    ON dbo.audit_log (prj_id, attribute_name, section_name, portfolio_sector, performed_at DESC);
END
GO

-- Optional FK links by PRJ_ID logical key (not strict relational on purpose due to versioning/history flows)
-- Add CHECK constraints for section values
IF NOT EXISTS (
    SELECT 1 FROM sys.check_constraints WHERE name = 'CK_master_dictionary_section'
)
BEGIN
    ALTER TABLE dbo.master_dictionary
    ADD CONSTRAINT CK_master_dictionary_section
    CHECK (where_in_financial_statement IN (
        'Income Statement', 'Balance Sheet', 'Cash Flow', 'Ratios', 'Derivatives', 'Miscellaneous and Other'
    ) OR where_in_financial_statement IS NULL);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.check_constraints WHERE name = 'CK_master_dictionary_portfolio'
)
BEGIN
    ALTER TABLE dbo.master_dictionary
    ADD CONSTRAINT CK_master_dictionary_portfolio
    CHECK (portfolio_sector IN (
        'FI Banks', 'Corporates', 'FI Insurance', 'Zeus Downstream', 'ALL'
    ) OR portfolio_sector IS NULL);
END
GO
