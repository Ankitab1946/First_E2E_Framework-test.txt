-- =============================================
-- Data Dictionary Admin App - SQL Server Schema
-- =============================================

-- 1) Master Dictionary Table
IF OBJECT_ID('dbo.master_dictionary', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.master_dictionary (
        id BIGINT IDENTITY(1,1) PRIMARY KEY,
        prj_id NVARCHAR(100) NOT NULL,
        prj_attribute_name NVARCHAR(255) NOT NULL,
        prj_attribute_description NVARCHAR(MAX) NULL,
        prj_physical_attribute_name NVARCHAR(255) NULL,
        editable BIT NULL,
        percentage_ratio NVARCHAR(50) NULL,
        calculation_logic NVARCHAR(MAX) NULL,
        where_in_financial_statement NVARCHAR(100) NULL,
        required_by_corporates BIT NULL,
        required_by_banks BIT NULL,
        required_by_insurance BIT NULL,
        required_by_downstream BIT NULL,
        version_update NVARCHAR(50) NULL,
        release_scope NVARCHAR(100) NULL,
        mapping_type NVARCHAR(100) NULL,
        calculation_in_prj NVARCHAR(100) NULL,
        editable_in_historicals BIT NULL,
        sign_flipping NVARCHAR(20) NULL,
        gc_template_attribute_name NVARCHAR(255) NULL,
        sp_standardisation_attribute_name NVARCHAR(255) NULL,
        sp_standardisation_dataitem_id NVARCHAR(100) NULL,
        sp_as_reported_dataitem_id NVARCHAR(100) NULL,
        calculation_logic_details NVARCHAR(MAX) NULL,
        updates NVARCHAR(MAX) NULL,
        updated_on DATETIME2 NULL,
        zeus_attribute NVARCHAR(255) NULL,
        zeus_table_name NVARCHAR(255) NULL,
        zeus_description NVARCHAR(MAX) NULL,
        comments NVARCHAR(MAX) NULL,
        snl_dataitemid NVARCHAR(100) NULL,
        scanned_calculated NVARCHAR(50) NULL,
        portfolio_sector NVARCHAR(50) NULL,
        is_active BIT NOT NULL CONSTRAINT DF_master_dictionary_is_active DEFAULT (1),
        is_deleted BIT NOT NULL CONSTRAINT DF_master_dictionary_is_deleted DEFAULT (0),
        record_version INT NOT NULL CONSTRAINT DF_master_dictionary_record_version DEFAULT (1),
        created_at DATETIME2 NOT NULL CONSTRAINT DF_master_dictionary_created_at DEFAULT (SYSUTCDATETIME()),
        updated_at DATETIME2 NOT NULL CONSTRAINT DF_master_dictionary_updated_at DEFAULT (SYSUTCDATETIME()),
        created_by NVARCHAR(255) NOT NULL CONSTRAINT DF_master_dictionary_created_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        updated_by NVARCHAR(255) NOT NULL CONSTRAINT DF_master_dictionary_updated_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser'))
    );
END
GO

-- 2) PRJ Attribute Table
IF OBJECT_ID('dbo.prj_attribute', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.prj_attribute (
        id BIGINT IDENTITY(1,1) PRIMARY KEY,
        prj_id NVARCHAR(100) NOT NULL,
        prj_attribute_id NVARCHAR(255) NOT NULL,
        prj_attribute_description NVARCHAR(MAX) NULL,
        prj_attribute_eg NVARCHAR(500) NULL,
        prj_physical_attribute_name NVARCHAR(255) NULL,
        where_in_finanical_statement NVARCHAR(100) NULL,
        version_update NVARCHAR(50) NULL,
        is_active BIT NOT NULL CONSTRAINT DF_prj_attribute_is_active DEFAULT (1),
        is_deleted BIT NOT NULL CONSTRAINT DF_prj_attribute_is_deleted DEFAULT (0),
        created_at DATETIME2 NOT NULL CONSTRAINT DF_prj_attribute_created_at DEFAULT (SYSUTCDATETIME()),
        updated_at DATETIME2 NOT NULL CONSTRAINT DF_prj_attribute_updated_at DEFAULT (SYSUTCDATETIME()),
        created_by NVARCHAR(255) NOT NULL CONSTRAINT DF_prj_attribute_created_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        uploaded_by NVARCHAR(255) NOT NULL CONSTRAINT DF_prj_attribute_uploaded_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser'))
    );
END
GO

-- 3) PRJ Attribute Business Logic Table
IF OBJECT_ID('dbo.prj_attr_business_logic', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.prj_attr_business_logic (
        id BIGINT IDENTITY(1,1) PRIMARY KEY,
        prj_id NVARCHAR(100) NOT NULL,
        s_number INT NULL,
        editable BIT NULL,
        percentage_ratio NVARCHAR(50) NULL,
        calculation_logic NVARCHAR(MAX) NULL,
        release_scope NVARCHAR(100) NULL,
        mapping_type NVARCHAR(100) NULL,
        calculation_in_prj NVARCHAR(100) NULL,
        editable_in_historicals BIT NULL,
        sign_flipping NVARCHAR(20) NULL,
        gc_template_attribute_name NVARCHAR(255) NULL,
        sp_standardize_attribute_name NVARCHAR(255) NULL,
        sp_standardize_dataitem_id NVARCHAR(100) NULL,
        sp_asreported_dataitem_id NVARCHAR(100) NULL,
        calculation_logic_details NVARCHAR(MAX) NULL,
        updates NVARCHAR(MAX) NULL,
        updated_on DATETIME2 NULL,
        zeus_attribute NVARCHAR(255) NULL,
        zeus_table_name NVARCHAR(255) NULL,
        zeus_description NVARCHAR(MAX) NULL,
        comments NVARCHAR(MAX) NULL,
        snl_dataitemid NVARCHAR(100) NULL,
        scanned_calculated NVARCHAR(50) NULL,
        is_active BIT NOT NULL CONSTRAINT DF_prj_attr_business_logic_is_active DEFAULT (1),
        is_deleted BIT NOT NULL CONSTRAINT DF_prj_attr_business_logic_is_deleted DEFAULT (0),
        created_at DATETIME2 NOT NULL CONSTRAINT DF_prj_attr_business_logic_created_at DEFAULT (SYSUTCDATETIME()),
        updated_at DATETIME2 NOT NULL CONSTRAINT DF_prj_attr_business_logic_updated_at DEFAULT (SYSUTCDATETIME()),
        created_by NVARCHAR(255) NOT NULL CONSTRAINT DF_prj_attr_business_logic_created_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        uploaded_by NVARCHAR(255) NOT NULL CONSTRAINT DF_prj_attr_business_logic_uploaded_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser'))
    );
END
GO

-- 4) PRJ Attribute Business Logic Scope Table
IF OBJECT_ID('dbo.prj_attr_business_logic_scope', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.prj_attr_business_logic_scope (
        id BIGINT IDENTITY(1,1) PRIMARY KEY,
        prj_id NVARCHAR(100) NOT NULL,
        required_by_corporates BIT NULL,
        required_by_banks BIT NULL,
        required_by_insurance BIT NULL,
        required_by_downstream BIT NULL,
        is_active BIT NOT NULL CONSTRAINT DF_prj_attr_business_logic_scope_is_active DEFAULT (1),
        is_deleted BIT NOT NULL CONSTRAINT DF_prj_attr_business_logic_scope_is_deleted DEFAULT (0),
        created_at DATETIME2 NOT NULL CONSTRAINT DF_prj_attr_business_logic_scope_created_at DEFAULT (SYSUTCDATETIME()),
        updated_at DATETIME2 NOT NULL CONSTRAINT DF_prj_attr_business_logic_scope_updated_at DEFAULT (SYSUTCDATETIME()),
        created_by NVARCHAR(255) NOT NULL CONSTRAINT DF_prj_attr_business_logic_scope_created_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        uploaded_by NVARCHAR(255) NOT NULL CONSTRAINT DF_prj_attr_business_logic_scope_uploaded_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser'))
    );
END
GO

-- 5) Audit Log Table
IF OBJECT_ID('dbo.audit_log', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.audit_log (
        audit_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        batch_id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWID(),
        entity_name NVARCHAR(100) NOT NULL,
        entity_pk NVARCHAR(255) NOT NULL,
        prj_id NVARCHAR(100) NULL,
        attribute_name NVARCHAR(255) NULL,
        section_name NVARCHAR(100) NULL,
        portfolio_sector NVARCHAR(50) NULL,
        action_type NVARCHAR(20) NOT NULL, -- INSERT/UPDATE/SOFT_DELETE
        old_value NVARCHAR(MAX) NULL,
        new_value NVARCHAR(MAX) NULL,
        source_module NVARCHAR(100) NULL,
        environment_name NVARCHAR(50) NULL,
        performed_by NVARCHAR(255) NOT NULL CONSTRAINT DF_audit_log_performed_by DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        performed_at DATETIME2 NOT NULL CONSTRAINT DF_audit_log_performed_at DEFAULT (SYSUTCDATETIME())
    );
END
GO

-- 6) History tables
IF OBJECT_ID('dbo.prj_attribute_history', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.prj_attribute_history (
        history_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        source_id BIGINT NOT NULL,
        prj_id NVARCHAR(100) NOT NULL,
        payload NVARCHAR(MAX) NOT NULL,
        version_no INT NOT NULL,
        changed_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        changed_by NVARCHAR(255) NOT NULL DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        change_type NVARCHAR(20) NOT NULL
    );
END
GO

IF OBJECT_ID('dbo.prj_attr_business_logic_history', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.prj_attr_business_logic_history (
        history_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        source_id BIGINT NOT NULL,
        prj_id NVARCHAR(100) NOT NULL,
        payload NVARCHAR(MAX) NOT NULL,
        version_no INT NOT NULL,
        changed_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        changed_by NVARCHAR(255) NOT NULL DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        change_type NVARCHAR(20) NOT NULL
    );
END
GO

IF OBJECT_ID('dbo.prj_attr_business_logic_scope_history', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.prj_attr_business_logic_scope_history (
        history_id BIGINT IDENTITY(1,1) PRIMARY KEY,
        source_id BIGINT NOT NULL,
        prj_id NVARCHAR(100) NOT NULL,
        payload NVARCHAR(MAX) NOT NULL,
        version_no INT NOT NULL,
        changed_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
        changed_by NVARCHAR(255) NOT NULL DEFAULT (COALESCE(ORIGINAL_LOGIN(), 'sysuser')),
        change_type NVARCHAR(20) NOT NULL
    );
END
GO
