# Data Dictionary Management - Enterprise Admin App

Production-ready three-tier Python web application for Data Dictionary management with:
- FastAPI backend (async, layered architecture)
- React frontend (editable grids, upload/download, delta visualization)
- SQL Server data layer (master, audit, history)
- Excel ingestion and template export
- Audit trail and history/version tracking
- Dockerized deployment
- Pytest + Allure testing support

## Planned Structure

- `backend/` FastAPI app (API, services, repositories, models, schemas)
- `frontend/` React app (dashboard, tabs, grid UX)
- `database/` SQL scripts for schema/indexing/seed
- `infra/` Docker and deployment assets
- `docs/` architecture, API, implementation/deployment guides

## Step-by-Step: Run the Application


python -m venv .venv 


### Prerequisites
1. Install **Docker Desktop** (Windows/Mac) or Docker Engine + Compose plugin (Linux).
2. Ensure Docker is running.
3. Verify commands:
   - `docker --version`
   - `docker compose version`

### 1) Create `.env` from template
From project root:
- PowerShell:
  - `Copy-Item .env.example .env`
- CMD:
  - `copy .env.example .env`

Then edit `.env` and set at least:
- `SQLSERVER_SERVER`
- `SQLSERVER_DATABASE`
- any other environment-specific values

> Note: Current backend scaffold can start without active DB operations, but these should be set for upcoming DB-integrated features.

### 2) Build and start containers
Run from project root:
- `docker compose up --build`

If your machine only supports legacy standalone compose:
- `docker-compose up --build`

### 3) Verify services
- Frontend: `http://localhost:3000`
- Backend: `http://localhost:8000`
- Swagger: `http://localhost:8000/docs`
- Health: `http://localhost:8000/health`

### 4) Stop services
- `docker compose down`
(or `docker-compose down` for legacy)

### 5) Rebuild after code changes
- `docker compose up --build`

### 6) Run in detached mode (optional)
- `docker compose up --build -d`
- Check logs:
  - `docker compose logs -f backend`
  - `docker compose logs -f frontend`

### 7) Troubleshooting
#### Error: `docker-compose` is not recognized
Use:
- `docker compose up --build`

This is Compose v2 plugin syntax (standard with Docker Desktop).

#### Port already in use
If 3000 or 8000 is occupied:
- Update port mapping in `docker-compose.yml`
- Re-run: `docker compose up --build`

#### `.env` not found
Create it from template:
- `Copy-Item .env.example .env` (PowerShell)
- `copy .env.example .env` (CMD)
