from fastapi import APIRouter

from app.api.v1.routes import audit, dictionary, environment, prompts, upload


api_router = APIRouter()
api_router.include_router(environment.router, prefix="/environment", tags=["Environment"])
api_router.include_router(dictionary.router, prefix="/dictionary", tags=["Data Dictionary"])
api_router.include_router(upload.router, prefix="/upload", tags=["Upload and Delta"])
api_router.include_router(audit.router, prefix="/audit", tags=["Audit History"])
api_router.include_router(prompts.router, prefix="/prompts", tags=["Prompts Library"])
