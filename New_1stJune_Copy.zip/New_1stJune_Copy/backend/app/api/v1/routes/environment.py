from fastapi import APIRouter, Header

from app.core.config import get_settings


router = APIRouter()
settings = get_settings()


@router.get("/options")
async def get_environment_options() -> dict:
    return {
        "default_environment": settings.default_environment,
        "available_environments": settings.available_environments_list,
    }


@router.get("/context")
async def get_environment_context(
    x_environment: str = Header(default="DEV", alias="X-Environment"),
    x_user: str = Header(default="sysuser", alias="X-User"),
) -> dict:
    selected = x_environment if x_environment in settings.available_environments_list else settings.default_environment
    return {
        "selected_environment": selected,
        "db_server": settings.sqlserver_server,
        "db_name": settings.sqlserver_database,
        "api_base": settings.api_prefix,
        "logged_in_user": x_user,
    }
