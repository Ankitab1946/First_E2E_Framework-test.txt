from functools import lru_cache
from typing import List

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Data Dictionary Admin App"
    app_env: str = "dev"
    api_prefix: str = "/api/v1"
    log_level: str = "INFO"
    allowed_origins: str = "http://localhost:3000"

    default_environment: str = "DEV"
    available_environments: str = "DEV,UAT,PROD"

    sqlserver_driver: str = "ODBC Driver 17 for SQL Server"
    sqlserver_server: str = ""
    sqlserver_database: str = ""
    sqlserver_trusted_connection: str = "yes"
    sqlserver_encrypt: str = "no"
    sqlserver_trust_server_certificate: str = "yes"
    sqlserver_username: str = ""
    sqlserver_password: str = ""

    excel_template_version: str = "1.0.0"
    max_upload_file_mb: int = 20

    s3_enabled: bool = False
    s3_bucket_name: str = ""
    s3_region: str = "us-east-1"
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""

    @property
    def available_environments_list(self) -> List[str]:
        return [x.strip() for x in self.available_environments.split(",") if x.strip()]

    @property
    def allowed_origins_list(self) -> List[str]:
        return [x.strip() for x in self.allowed_origins.split(",") if x.strip()]

    @property
    def sqlalchemy_database_url(self) -> str:
        if self.sqlserver_username and self.sqlserver_password:
            return (
                f"mssql+pyodbc://{self.sqlserver_username}:{self.sqlserver_password}"
                f"@{self.sqlserver_server}/{self.sqlserver_database}"
                f"?driver={self.sqlserver_driver.replace(' ', '+')}"
                f"&Encrypt={self.sqlserver_encrypt}"
                f"&TrustServerCertificate={self.sqlserver_trust_server_certificate}"
            )
        return (
            f"mssql+pyodbc://@{self.sqlserver_server}/{self.sqlserver_database}"
            f"?driver={self.sqlserver_driver.replace(' ', '+')}"
            f"&Trusted_Connection={self.sqlserver_trusted_connection}"
            f"&Encrypt={self.sqlserver_encrypt}"
            f"&TrustServerCertificate={self.sqlserver_trust_server_certificate}"
        )

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, value: str) -> str:
        return value.upper()


@lru_cache
def get_settings() -> Settings:
    return Settings()
