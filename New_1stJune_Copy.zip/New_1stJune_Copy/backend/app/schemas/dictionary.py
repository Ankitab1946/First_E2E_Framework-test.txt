from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class DictionaryBase(BaseModel):
    prj_id: str = Field(..., min_length=1, max_length=100)
    prj_attribute_name: str = Field(..., min_length=1, max_length=255)
    prj_attribute_description: Optional[str] = None
    prj_physical_attribute_name: Optional[str] = None
    editable: Optional[bool] = None
    percentage_ratio: Optional[str] = None
    calculation_logic: Optional[str] = None
    where_in_financial_statement: Optional[str] = None
    required_by_corporates: Optional[bool] = None
    required_by_banks: Optional[bool] = None
    required_by_insurance: Optional[bool] = None
    required_by_downstream: Optional[bool] = None
    version_update: Optional[str] = None
    release_scope: Optional[str] = None
    mapping_type: Optional[str] = None
    calculation_in_prj: Optional[str] = None
    editable_in_historicals: Optional[bool] = None
    sign_flipping: Optional[str] = None
    gc_template_attribute_name: Optional[str] = None
    sp_standardisation_attribute_name: Optional[str] = None
    sp_standardisation_dataitem_id: Optional[str] = None
    sp_as_reported_dataitem_id: Optional[str] = None
    calculation_logic_details: Optional[str] = None
    updates: Optional[str] = None
    updated_on: Optional[datetime] = None
    zeus_attribute: Optional[str] = None
    zeus_table_name: Optional[str] = None
    zeus_description: Optional[str] = None
    comments: Optional[str] = None
    snl_dataitemid: Optional[str] = None
    scanned_calculated: Optional[str] = None
    portfolio_sector: Optional[str] = None


class DictionaryCreate(DictionaryBase):
    pass


class DictionaryUpdate(BaseModel):
    prj_attribute_description: Optional[str] = None
    prj_physical_attribute_name: Optional[str] = None
    editable: Optional[bool] = None
    percentage_ratio: Optional[str] = None
    calculation_logic: Optional[str] = None
    where_in_financial_statement: Optional[str] = None
    required_by_corporates: Optional[bool] = None
    required_by_banks: Optional[bool] = None
    required_by_insurance: Optional[bool] = None
    required_by_downstream: Optional[bool] = None
    version_update: Optional[str] = None
    release_scope: Optional[str] = None
    mapping_type: Optional[str] = None
    calculation_in_prj: Optional[str] = None
    editable_in_historicals: Optional[bool] = None
    sign_flipping: Optional[str] = None
    gc_template_attribute_name: Optional[str] = None
    sp_standardisation_attribute_name: Optional[str] = None
    sp_standardisation_dataitem_id: Optional[str] = None
    sp_as_reported_dataitem_id: Optional[str] = None
    calculation_logic_details: Optional[str] = None
    updates: Optional[str] = None
    updated_on: Optional[datetime] = None
    zeus_attribute: Optional[str] = None
    zeus_table_name: Optional[str] = None
    zeus_description: Optional[str] = None
    comments: Optional[str] = None
    snl_dataitemid: Optional[str] = None
    scanned_calculated: Optional[str] = None
    portfolio_sector: Optional[str] = None


class DictionaryOut(DictionaryBase):
    id: int
    is_active: bool
    is_deleted: bool
    record_version: int
    created_at: datetime
    updated_at: datetime
    created_by: str
    updated_by: str

    class Config:
        from_attributes = True
