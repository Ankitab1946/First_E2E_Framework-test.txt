import os
from io import BytesIO
import pandas as pd
import streamlit as st

from app.core.config import get_settings
from app.services.dictionary_service import DictionaryService
from app.services.delta_service import DeltaService
from app.services.excel_service import ExcelService
from app.services.finalization_service import FinalizationService
from app.utils.excel_mapping import BOOLEAN_FIELDS, MASTER_FIELDS


st.set_page_config(page_title="Data Dictionary Admin", layout="wide")
settings = get_settings()


def current_user() -> str:
    return os.getenv("USERNAME") or os.getenv("USER") or settings.default_user


def records_to_df(records: list[dict]) -> pd.DataFrame:
    if not records:
        return pd.DataFrame(columns=MASTER_FIELDS)
    df = pd.DataFrame(records)
    for field in MASTER_FIELDS:
        if field not in df.columns:
            df[field] = None
    base_cols = MASTER_FIELDS + [c for c in ["delta_type", "changed_fields", "is_active", "version_no"] if c in df.columns]
    return df[base_cols]


def df_to_records(df: pd.DataFrame) -> list[dict]:
    cleaned = df.where(pd.notnull(df), None).to_dict(orient="records")
    return cleaned


def get_column_config():
    config = {}
    for field in BOOLEAN_FIELDS:
        config[field] = st.column_config.CheckboxColumn(field)
    if "delta_type":
        config["delta_type"] = st.column_config.SelectboxColumn("delta_type", options=["NEW", "UPDATED", "DELETED"])
    return config


def init_state():
    defaults = {
        "latest_records": [],
        "editable_records": [],
        "delta_records": [],
        "has_changes": False,
        "source_module": "NONE",
        "last_result": None,
    }
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


init_state()
dictionary_service = DictionaryService()
excel_service = ExcelService()
delta_service = DeltaService()
finalization_service = FinalizationService()

st.title("Data Dictionary Management Admin")
st.caption("Python-only implementation using Streamlit + SQLAlchemy + SQL Server")

with st.sidebar:
    st.subheader("Runtime")
    st.write(f"Environment: `{settings.app_env}`")
    st.write(f"Database writes: `{'ON' if settings.enable_db else 'OFF / simulated'}`")
    st.write(f"Current user: `{current_user()}`")
    if st.button("Refresh Latest Data"):
        st.session_state.latest_records = dictionary_service.get_latest_records()
        st.session_state.editable_records = dictionary_service.get_all_records()
        st.success("Data refreshed")

if not st.session_state.latest_records:
    st.session_state.latest_records = dictionary_service.get_latest_records()
if not st.session_state.editable_records:
    st.session_state.editable_records = dictionary_service.get_all_records()

tabs = st.tabs(["View Latest", "Edit Latest", "Upload and Edit", "Finalize and Upload", "Audit / Help"])

with tabs[0]:
    st.header("View Latest")
    records = st.session_state.latest_records
    df = records_to_df(records)

    c1, c2, c3 = st.columns([1, 1, 4])
    with c1:
        stream = excel_service.generate_template(records, settings.excel_template_version)
        st.download_button(
            "Download Latest Excel",
            data=stream.getvalue(),
            file_name="data_dictionary_template.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    with c2:
        csv = df.to_csv(index=False).encode("utf-8")
        st.download_button("Export CSV", csv, "data_dictionary_latest.csv", "text/csv")

    search = st.text_input("Search latest records", key="latest_search")
    if search:
        mask = df.astype(str).apply(lambda col: col.str.contains(search, case=False, na=False)).any(axis=1)
        df = df[mask]

    st.dataframe(df, use_container_width=True, height=520)

with tabs[1]:
    st.header("Edit Latest")
    st.info("Existing PRJ_ID should not be changed. For new rows, add a new PRJ_ID and mark delta_type as NEW.")
    edit_df = records_to_df(st.session_state.editable_records)
    if "delta_type" not in edit_df.columns:
        edit_df["delta_type"] = "UPDATED"

    edited_df = st.data_editor(
        edit_df,
        num_rows="dynamic",
        use_container_width=True,
        height=560,
        column_config=get_column_config(),
        key="edit_latest_grid",
    )

    c1, c2 = st.columns([1, 5])
    with c1:
        if st.button("Stage UI Changes", type="primary"):
            staged = df_to_records(edited_df)
            st.session_state.delta_records = [r for r in staged if r.get("prj_id")]
            st.session_state.has_changes = True
            st.session_state.source_module = "EDIT_LATEST"
            st.success("UI changes staged for finalization")
    with c2:
        st.warning("Before final upload, review staged rows in the Finalize and Upload tab.")

with tabs[2]:
    st.header("Upload and Edit")
    uploaded_file = st.file_uploader("Upload predefined Data Dictionary Excel file", type=["xlsx"])

    if uploaded_file is not None:
        try:
            uploaded_records = excel_service.parse_uploaded_file(uploaded_file.getvalue())
            db_records = st.session_state.latest_records
            deltas = delta_service.compare(db_records, uploaded_records)
            st.session_state.delta_records = deltas
            st.session_state.has_changes = len(deltas) > 0
            st.session_state.source_module = "UPLOAD_AND_EDIT"

            st.success(f"Upload validated. {len(uploaded_records)} rows parsed. {len(deltas)} delta rows detected.")
        except Exception as exc:
            st.error(f"Upload validation failed: {exc}")

    delta_df = records_to_df(st.session_state.delta_records)
    if not delta_df.empty:
        st.subheader("Delta Grid")
        counts = delta_df["delta_type"].value_counts().to_dict() if "delta_type" in delta_df else {}
        st.write({"NEW": counts.get("NEW", 0), "UPDATED": counts.get("UPDATED", 0), "DELETED": counts.get("DELETED", 0)})
        edited_delta_df = st.data_editor(
            delta_df,
            num_rows="dynamic",
            use_container_width=True,
            height=560,
            column_config=get_column_config(),
            key="delta_grid",
        )
        if st.button("Stage Delta Changes", type="primary"):
            st.session_state.delta_records = [r for r in df_to_records(edited_delta_df) if r.get("prj_id")]
            st.session_state.has_changes = True
            st.success("Delta changes staged for finalization")
    else:
        st.info("No delta records available yet. Upload Excel to compare with latest data.")

with tabs[3]:
    st.header("Finalize and Upload")
    staged = st.session_state.delta_records
    st.write(f"Source module: `{st.session_state.source_module}`")
    st.write(f"Staged records: `{len(staged)}`")

    if staged:
        st.dataframe(records_to_df(staged), use_container_width=True, height=420)

    if not st.session_state.has_changes:
        st.warning("Finalize is disabled because no changes are staged.")
    else:
        confirm = st.checkbox("I confirm that I want to update database tables")
        if st.button("Yes Upload", type="primary", disabled=not confirm):
            try:
                result = finalization_service.finalize(
                    changes=staged,
                    user_id=current_user(),
                    source_module=st.session_state.source_module,
                )
                st.session_state.last_result = result
                st.session_state.has_changes = False
                st.success(f"Finalization completed. Batch ID: {result['batch_id']}")
                st.json(result)
            except Exception as exc:
                st.error(f"Finalization failed: {exc}")

with tabs[4]:
    st.header("Audit / Help")
    st.markdown(
        """
        This Streamlit version keeps the full workflow in Python:

        1. View latest records from SQL Server or sample data.
        2. Download the predefined Excel template with row 3 headers and row 4 onward data.
        3. Edit latest records directly in the Streamlit grid.
        4. Upload Excel, validate structure, compare against latest data, and detect NEW / UPDATED / DELETED rows.
        5. Finalize staged rows into master and three target tables.

        Set `ENABLE_DB=true` in `.env` to perform actual SQL Server writes. With `ENABLE_DB=false`, finalization is simulated for local UI testing.
        """
    )
    if st.session_state.last_result:
        st.subheader("Last Finalization Result")
        st.json(st.session_state.last_result)
