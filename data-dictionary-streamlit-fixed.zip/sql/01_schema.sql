USE PRJ_DB;
GO

CREATE INDEX ix_master_dictionary_prj_id ON dbo.master_dictionary(prj_id);
CREATE INDEX ix_master_dictionary_active ON dbo.master_dictionary(is_active);
CREATE INDEX ix_audit_log_batch_id ON dbo.audit_log(batch_id);
CREATE INDEX ix_audit_log_prj_id ON dbo.audit_log(prj_id);
GO
