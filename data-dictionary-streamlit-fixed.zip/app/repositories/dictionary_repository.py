from sqlalchemy.orm import Session
from app.models.master_dictionary import MasterDictionary
from app.utils.excel_mapping import MASTER_FIELDS


class DictionaryRepository:
    def get_latest(self, db: Session) -> list[dict]:
        rows = db.query(MasterDictionary).filter(MasterDictionary.is_active == True).all()  # noqa: E712
        return [self.to_dict(row) for row in rows]

    def get_all(self, db: Session) -> list[dict]:
        rows = db.query(MasterDictionary).all()
        return [self.to_dict(row) for row in rows]

    def get_by_prj_id(self, db: Session, prj_id: str):
        return db.query(MasterDictionary).filter(MasterDictionary.prj_id == prj_id).one_or_none()

    def upsert_master(self, db: Session, record: dict, user_id: str) -> str:
        existing = self.get_by_prj_id(db, record["prj_id"])
        if existing is None:
            entity = MasterDictionary(**{k: record.get(k) for k in MASTER_FIELDS})
            entity.created_by = user_id
            entity.updated_by = user_id
            entity.is_active = True
            db.add(entity)
            return "INSERT"
        for field in MASTER_FIELDS:
            setattr(existing, field, record.get(field))
        existing.updated_by = user_id
        existing.version_no = (existing.version_no or 1) + 1
        existing.is_active = True
        return "UPDATE"

    def soft_delete(self, db: Session, prj_id: str, user_id: str) -> None:
        entity = self.get_by_prj_id(db, prj_id)
        if entity:
            entity.is_active = False
            entity.updated_by = user_id
            entity.version_no = (entity.version_no or 1) + 1

    def to_dict(self, entity: MasterDictionary) -> dict:
        data = {field: getattr(entity, field, None) for field in MASTER_FIELDS}
        data.update({
            "is_active": entity.is_active,
            "version_no": entity.version_no,
            "created_at": entity.created_at,
            "updated_at": entity.updated_at,
            "created_by": entity.created_by,
            "updated_by": entity.updated_by,
        })
        return data
