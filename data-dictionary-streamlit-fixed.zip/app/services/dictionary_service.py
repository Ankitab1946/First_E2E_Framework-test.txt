from app.core.config import get_settings
from app.core.database import get_session_factory
from app.repositories.dictionary_repository import DictionaryRepository
from app.utils.sample_data import get_sample_records


class DictionaryService:
    def __init__(self):
        self.settings = get_settings()
        self.repository = DictionaryRepository()

    def get_latest_records(self) -> list[dict]:
        if not self.settings.enable_db:
            return get_sample_records()
        SessionLocal = get_session_factory()
        with SessionLocal() as db:
            return self.repository.get_latest(db)

    def get_all_records(self) -> list[dict]:
        if not self.settings.enable_db:
            return get_sample_records()
        SessionLocal = get_session_factory()
        with SessionLocal() as db:
            return self.repository.get_all(db)
