import json
from datetime import datetime, timezone
from uuid import uuid4
from app.core.config import get_settings
from app.core.database import get_session_factory
from app.models.audit import AuditLog
from app.repositories.dictionary_repository import DictionaryRepository
from app.repositories.target_repository import TargetRepository


class FinalizationService:
    def __init__(self):
        self.settings = get_settings()
        self.dictionary_repo = DictionaryRepository()
        self.target_repo = TargetRepository()

    def finalize(self, changes: list[dict], user_id: str, source_module: str) -> dict:
        batch_id = str(uuid4())
        if not changes:
            return {"status": "NO_CHANGES", "batch_id": batch_id, "records_processed": 0}

        if not self.settings.enable_db:
            return {
                "status": "SIMULATED_SUCCESS",
                "batch_id": batch_id,
                "records_processed": len(changes),
                "message": "ENABLE_DB=false, so no database write was performed.",
            }

        SessionLocal = get_session_factory()
        with SessionLocal() as db:
            try:
                for change in changes:
                    delta_type = change.get("delta_type", "UPDATED")
                    prj_id = change["prj_id"]
                    existing = self.dictionary_repo.get_by_prj_id(db, prj_id)
                    old_value = self.dictionary_repo.to_dict(existing) if existing else None

                    if delta_type == "DELETED":
                        self.dictionary_repo.soft_delete(db, prj_id, user_id)
                        self.target_repo.soft_delete_all(db, prj_id, user_id)
                        action = "DELETE"
                    else:
                        action = self.dictionary_repo.upsert_master(db, change, user_id)
                        self.target_repo.upsert_all(db, change, user_id)

                    audit = AuditLog(
                        batch_id=batch_id,
                        prj_id=prj_id,
                        table_name="ALL_TARGET_TABLES",
                        action_type=action,
                        source_module=source_module,
                        old_value=json.dumps(old_value, default=str) if old_value else None,
                        new_value=json.dumps(change, default=str),
                        changed_by=user_id,
                    )
                    db.add(audit)
                db.commit()
                return {"status": "SUCCESS", "batch_id": batch_id, "records_processed": len(changes), "finalized_at": datetime.now(timezone.utc).isoformat()}
            except Exception:
                db.rollback()
                raise
