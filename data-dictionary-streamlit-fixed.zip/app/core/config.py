from functools import lru_cache
from pydantic_settings import BaseSettings
from urllib.parse import quote_plus


class Settings(BaseSettings):
    app_name: str = "Data Dictionary Streamlit Admin"
    app_env: str = "local"
    app_debug: bool = False

    # SQL Server Configuration
    sqlserver_host: str = "localhost"
    sqlserver_port: int = 1433
    sqlserver_database: str = "PRJ_DB"

    # Windows Authentication
    sqlserver_use_windows_auth: bool = True

    # Optional SQL Authentication
    sqlserver_user: str = ""
    sqlserver_password: str = ""

    sqlserver_driver: str = "ODBC Driver 17 for SQL Server"
    sqlserver_trust_cert: str = "yes"

    excel_template_version: str = "1.0"
    max_upload_size_mb: int = 20
    default_user: str = "sysuser"
    enable_db: bool = False

    @property
    def database_url(self) -> str:
        driver = quote_plus(self.sqlserver_driver)

        if self.sqlserver_use_windows_auth:
            return (
                f"mssql+pyodbc://@{self.sqlserver_host}:{self.sqlserver_port}/"
                f"{self.sqlserver_database}"
                f"?driver={driver}"
                f"&trusted_connection=yes"
                f"&TrustServerCertificate={self.sqlserver_trust_cert}"
            )

        return (
            f"mssql+pyodbc://{self.sqlserver_user}:{self.sqlserver_password}"
            f"@{self.sqlserver_host}:{self.sqlserver_port}/{self.sqlserver_database}"
            f"?driver={driver}&TrustServerCertificate={self.sqlserver_trust_cert}"
        )

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()
