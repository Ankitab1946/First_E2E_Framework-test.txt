/* Review existing legacy and target objects before running database scripts. */
SELECT
    s.name AS schema_name,
    o.name AS object_name,
    o.type_desc,
    o.create_date,
    o.modify_date
FROM sys.objects o
JOIN sys.schemas s ON s.schema_id = o.schema_id
WHERE o.name IN (
    N'prj_attribute',
    N'prj_attribute_logc_test',
    N'prj_attr_business_logic',
    N'prj_ui_display_config_test',
    N'prj_attribute_master_test',
    N'prj_portfolio_reference_test',
    N'prj_attribute_portfolio_scope_test',
    N'prj_attribute_business_rules_test',
    N'prj_scanning_prompt_reference_test',
    N'audit_table_test',
    N'ug_portfolio_rerenece'
)
ORDER BY o.name;

SELECT
    fk.name AS foreign_key_name,
    OBJECT_SCHEMA_NAME(fk.parent_object_id) + N'.' + OBJECT_NAME(fk.parent_object_id) AS child_table,
    OBJECT_SCHEMA_NAME(fk.referenced_object_id) + N'.' + OBJECT_NAME(fk.referenced_object_id) AS parent_table
FROM sys.foreign_keys fk
WHERE OBJECT_NAME(fk.parent_object_id) IN (
    N'prj_attribute', N'prj_attribute_logc_test', N'prj_attr_business_logic', N'prj_ui_display_config_test'
)
OR OBJECT_NAME(fk.referenced_object_id) IN (
    N'prj_attribute', N'prj_attribute_logc_test', N'prj_attr_business_logic', N'prj_ui_display_config_test'
)
ORDER BY child_table, foreign_key_name;
