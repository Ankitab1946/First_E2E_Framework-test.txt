/*
  Data Dictionary Admin App - legacy table retirement.

  Scope:
    dbo.prj_attribute
    dbo.prj_attribute_logc_test
    dbo.prj_attr_business_logic
    dbo.prj_ui_display_config_test

  This script removes ONLY the superseded legacy tables and all foreign keys
  that reference or belong to them. It does not affect the six operational
  tables used by the current Data Dictionary Admin App.

  IMPORTANT: Run 000_preflight_existing_objects.sql first. This operation is
  destructive for the four legacy tables and their data.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @LegacyTables TABLE (table_name sysname NOT NULL PRIMARY KEY);
INSERT INTO @LegacyTables (table_name)
VALUES
    (N'prj_attribute'),
    (N'prj_attribute_logc_test'),
    (N'prj_attr_business_logic'),
    (N'prj_ui_display_config_test');

BEGIN TRY
    BEGIN TRANSACTION;

    DECLARE @sql nvarchar(max) = N'';

    /* Drop every FK where either the child or parent is one of the retired tables. */
    SELECT @sql = @sql +
        N'ALTER TABLE ' + QUOTENAME(OBJECT_SCHEMA_NAME(fk.parent_object_id)) + N'.' + QUOTENAME(OBJECT_NAME(fk.parent_object_id)) +
        N' DROP CONSTRAINT ' + QUOTENAME(fk.name) + N';' + CHAR(13) + CHAR(10)
    FROM sys.foreign_keys fk
    WHERE OBJECT_NAME(fk.parent_object_id) IN (SELECT table_name FROM @LegacyTables)
       OR OBJECT_NAME(fk.referenced_object_id) IN (SELECT table_name FROM @LegacyTables);

    IF @sql <> N''
        EXEC sys.sp_executesql @sql;

    /* Drop tables in dependency-safe order. */
    IF OBJECT_ID(N'dbo.prj_ui_display_config_test', N'U') IS NOT NULL
        DROP TABLE dbo.prj_ui_display_config_test;

    IF OBJECT_ID(N'dbo.prj_attr_business_logic', N'U') IS NOT NULL
        DROP TABLE dbo.prj_attr_business_logic;

    IF OBJECT_ID(N'dbo.prj_attribute_logc_test', N'U') IS NOT NULL
        DROP TABLE dbo.prj_attribute_logc_test;

    IF OBJECT_ID(N'dbo.prj_attribute', N'U') IS NOT NULL
        DROP TABLE dbo.prj_attribute;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
