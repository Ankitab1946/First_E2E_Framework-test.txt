#!/usr/bin/env bash
python -m poetry run pytest
