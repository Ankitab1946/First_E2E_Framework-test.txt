#!/usr/bin/env bash
python -m poetry run python -m uvicorn DataDictionaryAdminApp.api.swagger_app:app --host 0.0.0.0 --port 8502 --reload
