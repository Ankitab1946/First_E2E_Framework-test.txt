#!/usr/bin/env bash
python -m poetry run streamlit run DataDictionaryAdminApp/src/DataDictionaryAdminApp/streamlit_app.py
