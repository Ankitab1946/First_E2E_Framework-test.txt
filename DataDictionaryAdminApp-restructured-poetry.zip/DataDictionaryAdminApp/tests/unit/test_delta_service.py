from DataDictionaryAdminApp.service.delta_service import DeltaService


def test_detects_new_record():
    db_records = [{"prj_id": "PRJ001", "prj_attribute_name": "Revenue"}]
    upload_records = [
        {"prj_id": "PRJ001", "prj_attribute_name": "Revenue"},
        {"prj_id": "PRJ002", "prj_attribute_name": "EBITDA"},
    ]
    result = DeltaService().compare(db_records, upload_records)
    assert len(result) == 1
    assert result[0]["delta_type"] == "NEW"


def test_detects_updated_record():
    db_records = [{"prj_id": "PRJ001", "prj_attribute_name": "Revenue"}]
    upload_records = [{"prj_id": "PRJ001", "prj_attribute_name": "Total Revenue"}]
    result = DeltaService().compare(db_records, upload_records)
    assert len(result) == 1
    assert result[0]["delta_type"] == "UPDATED"
    assert "prj_attribute_name" in result[0]["changed_fields"]


def test_detects_deleted_record():
    db_records = [{"prj_id": "PRJ001", "prj_attribute_name": "Revenue"}]
    upload_records = []
    result = DeltaService().compare(db_records, upload_records)
    assert len(result) == 1
    assert result[0]["delta_type"] == "DELETED"
