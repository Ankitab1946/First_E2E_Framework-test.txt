# Data Dictionary Admin App

Production-oriented three-tier Python application for managing PRJ data-dictionary and prompt records.

## Architecture
- **Presentation:** Streamlit (`streamlit_app.py`)
- **Application/API:** FastAPI (`api/`)
- **Business/Repository/Data:** service, repository, SQL Server models
- **Storage:** SQL Server and S3-compatible object storage

## Run locally
```bash
copy .env.example .env
poetry install
poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --reload --port 8503
poetry run streamlit run src/DataDictionaryAdminApp/streamlit_app.py --server.port 8501
```

Swagger: `http://localhost:8503/docs`  
UI: `http://localhost:8501`

## Bootstrap database
Run `src/DataDictionaryAdminApp/sql/001_create_tables.sql` in the target SQL Server database. It creates only the six requested operational tables and assumes `prj_data_source` already exists.

## Tests
```bash
poetry run pytest --alluredir=allure-results
allure serve allure-results
```

## Environment configuration
Copy `.env.example` to `.env`. The Streamlit sidebar sends the selected environment to the API using the `X-App-Environment` header. The API resolves `ENV_<ENV>_SQLSERVER_*` first, then falls back to default `SQLSERVER_*` values.

For internal S3-compatible storage, set `BUCKET_NAME`, `HOST`, `ACCESS_KEY_ID`, and `SECRET_KEY`. `HOST` must contain only the service endpoint and port, never a bucket or folder path. Keep `S3_USE_SSL=false` and `S3_VERIFY_SSL=false` for internal endpoints that use a self-signed certificate chain.

## Database bootstrap
Run `src/DataDictionaryAdminApp/sql/000_preflight_existing_objects.sql` to inspect the six application-managed tables, then run `src/DataDictionaryAdminApp/sql/001_create_tables.sql`. The script is idempotent and does not drop existing records.

The application manages only these six tables:

- `prj_attribute_master_test`
- `prj_portfolio_reference_test`
- `prj_attribute_portfolio_scope_test`
- `prj_attribute_business_rules_test`
- `prj_scanning_prompt_reference_test`
- `audit_table_test`

`prj_data_source` is read only and is used strictly as an existing source lookup table.

## Swagger route groups (v2.1.0)

The application exposes the following independent FastAPI route groups under `/api/v1`:

- `/data-dictionary`
- `/master-upload`
- `/prompts`
- `/prompt-upload`
- `/portfolio-reference`
- `/lookups`
- `/audit`
- `/history`
- `/s3`
- `/admin`
- `/system`

Swagger UI is available at `/docs` when the API is running.


## Resolving `API error (404): Not found`

The Streamlit UI now normalizes `API_BASE_URL` automatically. You may configure either `http://localhost:8503` or `http://localhost:8503/api/v1`; the UI will use `http://localhost:8503/api/v1`. Start both processes from the same extracted project folder:

```powershell
poetry run python -m DataDictionaryAdminApp.api
poetry run streamlit run src\DataDictionaryAdminApp\streamlit_app.py --server.port 8501
```

Verify the active API build before opening Streamlit:

```text
http://localhost:8503/api/v1
http://localhost:8503/api/v1/health
http://localhost:8503/api/v1/system/environment
```

If `/api/v1` does not return the `route_groups` response, stop old `uvicorn` / Python processes and start the command above from this package.


## 404 troubleshooting built into this release
The Streamlit client now retries the supported route aliases when a configured route returns HTTP 404. The sidebar reads `.env` by searching from the Streamlit file upward to the project root. Keep `API_BASE_URL=http://localhost:8503/api/v1` in `.env`, start FastAPI with `poetry run python -m DataDictionaryAdminApp.api`, then start Streamlit from the same project root.


## Database schema prerequisite
Before using **View Latest Data Dictionary**, run `src/DataDictionaryAdminApp/sql/001_create_tables.sql` in the database configured for the selected environment. The application uses only the six approved Data Dictionary tables. If the schema is missing or incomplete, the grid will remain available and display a clear warning instead of returning HTTP 500.

## Existing database tables: important
`001_create_tables.sql` is an idempotent **schema reconciliation** script. Run it against the exact database shown in the Streamlit sidebar. If any final table existed from an older app version, the script adds missing final-schema columns rather than assuming the old definition is compatible.

Then run `src/DataDictionaryAdminApp/sql/003_validate_final_schema.sql`. It reports the exact missing object/column and confirms `DB_NAME()` and `@@SERVERNAME`, which must match the sidebar environment.


## SQL Server diagnostic
After starting the API, open `http://localhost:8503/api/v1/system/database-diagnostic`. It must report the expected server and database.


## Role access
The Streamlit sidebar includes an Admin/User role selector. Admin can execute Master Dictionary upload/compare/finalize and S3 export. User sees these controls disabled. API endpoints also require `X-App-Role: Admin`.


Prompt Management schema revision: `display_order` is retained; the `examples` column is removed from `prj_scanning_prompt_reference_test`.

## Docker and Internal Cloud Deployment

The deployment package now provides separate production containers for FastAPI and Streamlit.

### Local Docker Compose

```bash
copy .env.example .env
docker compose up --build
```

- UI: `http://localhost:8501`
- Swagger: `http://localhost:8503/docs`

The UI container calls FastAPI through the internal Compose service URL, not `localhost`.

### Kubernetes / Internal Cloud

A Helm chart is available in `deploy/helm/data-dictionary-admin`. It deploys API and UI as separate scalable workloads with readiness/liveness probes and optional Ingress. See `deploy/helm/data-dictionary-admin/README.md`.

### Important: Windows Authentication in a Linux container

The app continues to support the existing `SQLSERVER_WINDOWS_AUTH=true` setting. In an internal-cloud Linux workload, SQL Server Integrated Authentication also requires an approved domain/Kerberos workload identity, valid SPNs/network access, and a valid Kerberos ticket or keytab. The required ODBC Driver 18 and Kerberos client libraries are included in the image. This infrastructure identity setup must be supplied by the internal-cloud/platform team.

## Help charts

User workflow charts and troubleshooting guidance are available in `docs/HELP_GUIDE.md` and in the Streamlit **Help** tab.

## Docker and Internal Cloud Deployment

The deployment package now provides separate production containers for FastAPI and Streamlit.

### Local Docker Compose

```bash
copy .env.example .env
docker compose up --build
```

- UI: `http://localhost:8501`
- Swagger: `http://localhost:8503/docs`

The UI container calls FastAPI through the internal Compose service URL, not `localhost`.

### Kubernetes / Internal Cloud

A Helm chart is available in `deploy/helm/data-dictionary-admin`. It deploys API and UI as separate scalable workloads with readiness/liveness probes and optional Ingress. See `deploy/helm/data-dictionary-admin/README.md`.

### Important: Windows Authentication in a Linux container

The app continues to support the existing `SQLSERVER_WINDOWS_AUTH=true` setting. In an internal-cloud Linux workload, SQL Server Integrated Authentication also requires an approved domain/Kerberos workload identity, valid SPNs/network access, and a valid Kerberos ticket or keytab. The required ODBC Driver 18 and Kerberos client libraries are included in the image. This infrastructure identity setup must be supplied by the internal-cloud/platform team.

## Help charts

User workflow charts and troubleshooting guidance are available in `docs/HELP_GUIDE.md` and in the Streamlit **Help** tab.
