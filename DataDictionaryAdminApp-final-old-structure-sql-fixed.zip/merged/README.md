# Data Dictionary Admin App

Production-oriented three-tier Python application for managing PRJ data-dictionary and prompt records.

## Architecture
- **Presentation:** Streamlit (`streamlit_app.py`)
- **Application/API:** FastAPI (`api/`)
- **Business/Repository/Data:** service, repository, SQL Server models
- **Storage:** SQL Server and S3-compatible object storage

## Run locally
```bash
copy .env.example .env
poetry install
poetry run uvicorn DataDictionaryAdminApp.api.swagger_app:app --reload --port 8502
poetry run streamlit run src/DataDictionaryAdminApp/streamlit_app.py --server.port 8501
```

Swagger: `http://localhost:8502/docs`  
UI: `http://localhost:8501`

## Bootstrap database
Run `src/DataDictionaryAdminApp/sql/001_create_tables.sql` in the target SQL Server database. It creates only the six requested operational tables and assumes `prj_data_source` already exists.

## Tests
```bash
poetry run pytest --alluredir=allure-results
allure serve allure-results
```

## Environment configuration
Copy `.env.example` to `.env`. The Streamlit sidebar sends the selected environment to the API using the `X-App-Environment` header. The API resolves `ENV_<ENV>_SQLSERVER_*` first, then falls back to default `SQLSERVER_*` values.

For internal S3-compatible storage, set `BUCKET_NAME`, `HOST`, `ACCESS_KEY_ID`, and `SECRET_KEY`. `HOST` must contain only the service endpoint and port, never a bucket or folder path. Keep `S3_USE_SSL=false` and `S3_VERIFY_SSL=false` for internal endpoints that use a self-signed certificate chain.

## Database bootstrap and legacy-object safety
Run `src/DataDictionaryAdminApp/sql/001_create_tables.sql`. It is idempotent: it does not drop tables or existing data, and all new constraints/indexes use the `ddam` naming prefix to avoid collisions with legacy objects such as `ug_portfolio_rerenece`.

If SQL Server still reports a legacy-object conflict, first run `src/DataDictionaryAdminApp/sql/000_preflight_existing_objects.sql` and share its result. Do not manually drop a legacy object until its dependency is confirmed.
