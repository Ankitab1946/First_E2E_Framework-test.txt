from fastapi import FastAPI
from DataDictionaryAdminApp.api.routers import data_dictionary, audit, system, lookups

app=FastAPI(
    title='Data Dictionary Admin API',
    version='2.0.0',
    description='API-first administration for the six approved Data Dictionary tables: master, portfolio reference, scope, business rule, prompts and audit.'
)
app.include_router(data_dictionary.router,prefix='/api/v1')
app.include_router(audit.router,prefix='/api/v1')
app.include_router(system.router,prefix='/api/v1')
app.include_router(lookups.router,prefix='/api/v1')
@app.get('/health',tags=['System'])
def health(): return {'status':'UP'}
