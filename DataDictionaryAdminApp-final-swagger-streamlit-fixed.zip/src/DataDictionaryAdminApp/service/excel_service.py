from io import BytesIO
from datetime import datetime
import pandas as pd
from openpyxl import Workbook
from openpyxl.worksheet.datavalidation import DataValidation

class ExcelService:
    master_columns=['PRJ ID','PRJ Attribute Name','PRJ Attribute Description','PRJ Physical Attribute Name','Editable?','Calculated or Reported?','Percentage(%) / Ratio(X)','Calculation Logic','Where in financial statement is this generally collected from ?','Required by corporates?','Required by banks ?','Required by insurance?','Required by Downstream?','Version Update','Mapping Type (calculated/CAPIQ sourced/Manual Updates/Out of Scope)','Calculated in CFV? (Y/N)','Editable in Historicals screen in UCRS-CFV?(Y/N)','Sign Flipping (multiply by)','GC Template attribute name','S&P Standradisation dataitem id','S&P As-Reported dataitem ID / logic','Calculation Logic Details','Updates','Updated ON','Zeus attribute','Zeus table name','Zeus Description','Commnets','SNL dataitemid','Scanned/Calculated']
    def read_prompt_workbook(self, content, sheet_name): return pd.read_excel(BytesIO(content), sheet_name=sheet_name)
    def sheets(self,content): return pd.ExcelFile(BytesIO(content)).sheet_names
    def build_latest(self, rows):
        wb=Workbook(); ws=wb.active; ws.title='PRJ Data Dictionary Mapping'; ws['A1']='Data Dictionary Export'; ws['A2']=f'Generated: {datetime.utcnow().isoformat()}Z'
        ws.append(self.master_columns)
        for r in rows: ws.append([getattr(r,'prj_id',None),getattr(r,'prj_attribute_name',None),getattr(r,'prj_attribute_description',None),getattr(r,'prj_physical_attribute_name',None),None,getattr(r,'calculated_or_reported',None),None,getattr(r,'calculation_logic',None),getattr(r,'where_in_financial_statement',None),None,None,None,None,getattr(r,'version_update',None),getattr(r,'mapping_type',None),getattr(r,'calculated_in_cfv',None),getattr(r,'editable_in_historicals',None),getattr(r,'sign_flipping_value',None),None,getattr(r,'sp_standardisation_dataitem_id',None),getattr(r,'sp_as_reported_dataitem_logic',None),getattr(r,'calculation_logic_details',None),None,None,None,None,None,None,None,None])
        dv=DataValidation(type='list', formula1='"Y,N"'); ws.add_data_validation(dv); dv.add(f'J4:M1048576')
        for col in ws.columns: ws.column_dimensions[col[0].column_letter].width=24
        out=BytesIO(); wb.save(out); return out.getvalue()
