#!/usr/bin/env bash
set -euo pipefail

poetry run uvicorn app.api.swagger_app:app --host 0.0.0.0 --port 8502 --reload
