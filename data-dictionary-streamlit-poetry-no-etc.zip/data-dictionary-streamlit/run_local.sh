#!/usr/bin/env bash
set -euo pipefail

cp -n .env.example .env || true
poetry install
poetry run streamlit run src/streamlit_app.py
