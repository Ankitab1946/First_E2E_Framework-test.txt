@echo off
if not exist .env copy .env.example .env
poetry install
poetry run streamlit run src\streamlit_app.py
